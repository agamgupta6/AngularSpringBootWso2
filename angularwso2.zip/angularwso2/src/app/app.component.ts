import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as jwt_decode from 'jwt-decode';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  username = '';
  password = '' ;
  loginsuccess: boolean;
  loginerror: boolean;
  userinfo: any;
  constructor(private http: HttpClient) {
  }

  login() {
    const credential = btoa(this.username + ':' + this.password);
    this.http.post('http://localhost:8080/authenticate', {'customsectoken': credential}).subscribe(
      response => {

        // tslint:disable-next-line:no-unused-expression
       if (response['responseCode'] === 200) {
        this.userinfo  = jwt_decode(response['id_token']);
        this.loginsuccess = true;
        this.loginerror = false;
       } else {
        this.loginerror = true;
        this.loginsuccess = false;
       }
      }, error => {
        this.loginerror = true;
        this.loginsuccess = false;
      }
  );
  }

  logout() {
    this.loginsuccess = false;
    this.username = '';
    this.password = '';
    this.userinfo = '';
  }

}
