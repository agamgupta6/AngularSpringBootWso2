package com.pichincha.loginapp.entity;

public class AuthenticationRequest {

String customsectoken;

public String getCustomsectoken() {
	return customsectoken;
}

public void setCustomsectoken(String customsectoken) {
	this.customsectoken = customsectoken;
}


}
