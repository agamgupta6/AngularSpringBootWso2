package com.pichincha.loginapp.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.pichincha.loginapp.entity.AuthenticationRequest;
import com.pichincha.loginapp.entity.AuthenticationResponse;
import com.pichincha.loginapp.service.LoginService;

import okhttp3.Response;

@RestController
public class LoginController {
	
	@Autowired
	LoginService loginService;
	
	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping("/authenticate")
	@ResponseBody
	AuthenticationResponse  authenticateWithPassword(@RequestBody AuthenticationRequest authenticationRequest ) throws IOException {
		AuthenticationResponse authnticationResponse;
		Response response  = loginService.authenticate(authenticationRequest);
		if(response.code() == 302 && 
				response.header("location").indexOf("code=")!=-1){
				Map<String, String> queryMap = splitQuery(response.header("location"));
				authnticationResponse = loginService.getToken(queryMap);
		} else{
			authnticationResponse = new AuthenticationResponse();
			authnticationResponse.setResponseCode(401);
		}
		return authnticationResponse;
	}
	
	public static Map<String, String> splitQuery(String location) throws UnsupportedEncodingException, MalformedURLException {
		URL url = new URL(location);
	    Map<String, String> query_pairs = new LinkedHashMap<String, String>();
	    String query = url.getQuery();
	    String[] pairs = query.split("&");
	    for (String pair : pairs) {
	        int idx = pair.indexOf("=");
	        query_pairs.put(URLDecoder.decode(pair.substring(0, idx), "UTF-8"), URLDecoder.decode(pair.substring(idx + 1), "UTF-8"));
	    }
	    return query_pairs;
	}
	
}
