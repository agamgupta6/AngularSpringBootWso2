package com.pichincha.loginapp.service;

import java.io.IOException;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pichincha.loginapp.entity.AuthenticationRequest;
import com.pichincha.loginapp.entity.AuthenticationResponse;

import okhttp3.Call;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

@Service
public class LoginService {

	@Value("${client_id}")
	   private String client_id;
	@Value("${response_type}")
	   private String response_type;
	@Value("${redirect_uri}")
	   private String redirect_uri;
	@Value("${scope}")
	   private String scope;
	@Value("${prompt}")
	   private String prompt;
	@Value("${client_secret}")
	   private String client_secret;
	@Value("${grant_type}")
	   private String grant_type;
	@Value("${wso2.auth.url}")
	   private String wso2AuthUrl;
	@Value("${wso2.token.url}")
	   private String wso2TokenUrl;
	
	
	
	public Response authenticate(AuthenticationRequest authenticationRequest) throws IOException{
		OkHttpClient client = new OkHttpClient().newBuilder()
			      .followRedirects(false)
			      .build();
		
		RequestBody formBody = new FormBody.Builder()
			      .add("client_id", client_id)
			      .add("customsectoken", authenticationRequest.getCustomsectoken())
			      .add("prompt", prompt)
			      .add("redirect_uri", redirect_uri)
			      .add("response_type", response_type)
			      .add("scope", scope)
			      .add("state", UUID.randomUUID().toString())
			      .build();
			 
			    Request request = new Request.Builder()
			      .url(wso2AuthUrl)
			      .post(formBody)
			      .build();
			 
			    Call call = client.newCall(request);
			    Response response = call.execute();
			    System.out.println(response.header("location"));
			    return response;
	}
	
	
	public AuthenticationResponse getToken(Map<String, String> queryMap) throws IOException{
		
		AuthenticationResponse authenticationResponse;
		OkHttpClient client = new OkHttpClient().newBuilder()
			      .followRedirects(false)
			      .build();
		
		
		RequestBody formBody = new FormBody.Builder()
			      .add("client_id", client_id)
			      .add("client_secret", client_secret)
			      .add("grant_type", grant_type)
			      .add("redirect_uri", redirect_uri)
			      .add("code", queryMap.get("code"))
			      .build();
			 
			    Request request = new Request.Builder()
			      .url(wso2TokenUrl)
			      .post(formBody)
			      .build();
			 
			    Call call = client.newCall(request);
			    Response response = call.execute();
			    if(response.code()==200){
			    	ObjectMapper mapper = new ObjectMapper();
				     authenticationResponse = mapper.readValue(response.body().string(), AuthenticationResponse.class);
				     authenticationResponse.setResponseCode(response.code());
			    }else {
			    	authenticationResponse = new AuthenticationResponse();
			    	authenticationResponse.setResponseCode(401);
			    }
			    
			    return authenticationResponse;
	}
	
}
