package com.no.mob.account.service

import com.no.mob.account.common.BusinessException
import com.no.mob.account.converter.AccountResponseConverter
import com.no.mob.account.entity.Account
import com.no.mob.account.entity.AccountView
import com.no.mob.account.entity.ExternalPaymentCard
import com.no.mob.account.entity.ProductConfiguration
import com.no.mob.account.entity.VirtualCardDetails
import com.no.mob.account.model.AccountRequestDto
import com.no.mob.account.model.CardType
import com.no.mob.account.model.PayeeAccountDetailsDtoResult
import com.no.mob.account.model.PaymentAmountRequestDto
import com.no.mob.account.repo.AccountRepo
import com.no.mob.account.repo.AccountViewRepo
import com.no.mob.account.repo.ExternalCardRepo
import com.no.mob.account.repo.VirtualCardRepo
import com.no.mob.account.utils.AccountHelper
import com.no.mob.account.utils.AccountNumbergenerationService
import com.no.mob.account.utils.AccountNumbergenerationServiceImpl
import com.no.mob.account.utils.VirtualCardHelper
import com.no.mob.account.repo.ProductConfigurationRepo

import spock.lang.Specification

class AccountServiceImplSpec extends Specification{
	def "debit account not found"() {
		given:
		PaymentAmountRequestDto paymentAmountRequestDto = new PaymentAmountRequestDto()
		paymentAmountRequestDto.setAccountNo("1234567")
		paymentAmountRequestDto.setAmount(BigDecimal.TEN)


		Account sourcePaymentDetails = new Account()
		sourcePaymentDetails.setAccountId(1L)
		sourcePaymentDetails.setAccountNo("1234567")
		sourcePaymentDetails.setBalance(BigDecimal.valueOf(100000L))
		sourcePaymentDetails.setCreatedDt(new Date())
		sourcePaymentDetails.setCustomerId(1L)
		sourcePaymentDetails.setIbanNo("NO9386011234567")
		//sourcePaymentDetails.setIsActive('Y');
		sourcePaymentDetails.setVirtualCardDetails(new VirtualCardDetails())
		def accountDetailRepo = Mock(AccountRepo.class)

		accountDetailRepo.findByAccountNo(_)>>Optional.empty()

		accountDetailRepo.save(_)>>sourcePaymentDetails

		AccountService accountService = new AccountServiceImpl()
		accountService.accountDetailRepo = accountDetailRepo
		when:
		accountService.debitBalance("98765432",paymentAmountRequestDto)

		then:
		BusinessException e = thrown()
		e.getErrorDetails().getErrorCode() == "424"
		e.getErrorDetails().getErrorMsgKey() == "Account does not exist"
	}


	def "debit success"() {
		given:
		PaymentAmountRequestDto paymentAmountRequestDto = new PaymentAmountRequestDto()
		paymentAmountRequestDto.setAccountNo("1234567")
		paymentAmountRequestDto.setAmount(BigDecimal.TEN)


		Account sourcePaymentDetails = new Account()
		sourcePaymentDetails.setAccountId(1L)
		sourcePaymentDetails.setAccountNo("1234567")
		sourcePaymentDetails.setBalance(BigDecimal.valueOf(100000L))
		sourcePaymentDetails.setCreatedDt(new Date())
		sourcePaymentDetails.setCustomerId(1L)
		sourcePaymentDetails.setIbanNo("NO9386011234567")
		//sourcePaymentDetails.setIsActive('Y');
		sourcePaymentDetails.setVirtualCardDetails(new VirtualCardDetails())
		def accountDetailRepo = Mock(AccountRepo.class)

		accountDetailRepo.findByAccountNo(_)>>Optional.ofNullable(sourcePaymentDetails)

		accountDetailRepo.save(_)>>sourcePaymentDetails

		AccountService accountService = new AccountServiceImpl()
		accountService.accountDetailRepo = accountDetailRepo
		when:
		accountService.debitBalance("9876432",paymentAmountRequestDto)

		then:
		sourcePaymentDetails.getBalance()==BigDecimal.valueOf(99990L)
	}

	def "credit success"() {
		given:
		PaymentAmountRequestDto paymentAmountRequestDto = new PaymentAmountRequestDto()
		paymentAmountRequestDto.setAccountNo("1234567")
		paymentAmountRequestDto.setAmount(BigDecimal.TEN)


		Account targetAccountDetails = new Account()
		targetAccountDetails.setAccountId(1L)
		targetAccountDetails.setAccountNo("1234567")
		targetAccountDetails.setBalance(BigDecimal.valueOf(100000L))
		targetAccountDetails.setCreatedDt(new Date())
		targetAccountDetails.setCustomerId(1L)
		targetAccountDetails.setIbanNo("NO9386011234567")
		//sourcePaymentDetails.setIsActive('Y');
		targetAccountDetails.setVirtualCardDetails(new VirtualCardDetails())
		def accountDetailRepo = Mock(AccountRepo.class)

		accountDetailRepo.findByAccountNo(_)>>Optional.ofNullable(targetAccountDetails)

		accountDetailRepo.save(_)>>targetAccountDetails

		AccountService accountService = new AccountServiceImpl()
		accountService.accountDetailRepo = accountDetailRepo
		when:
		accountService.updateBalance("9876432",paymentAmountRequestDto)

		then:
		targetAccountDetails.getBalance()==BigDecimal.valueOf(100010L)
	}

	def "credit account not found"() {
		given:
		PaymentAmountRequestDto paymentAmountRequestDto = new PaymentAmountRequestDto()
		paymentAmountRequestDto.setAccountNo("1234567")
		paymentAmountRequestDto.setAmount(BigDecimal.TEN)


		Account sourcePaymentDetails = new Account()
		sourcePaymentDetails.setAccountId(1L)
		sourcePaymentDetails.setAccountNo("1234567")
		sourcePaymentDetails.setBalance(BigDecimal.valueOf(100000L))
		sourcePaymentDetails.setCreatedDt(new Date())
		sourcePaymentDetails.setCustomerId(1L)
		sourcePaymentDetails.setIbanNo("NO9386011234567")
		//sourcePaymentDetails.setIsActive('Y');
		sourcePaymentDetails.setVirtualCardDetails(new VirtualCardDetails())
		def accountDetailRepo = Mock(AccountRepo.class)

		accountDetailRepo.findByAccountNo(_)>>Optional.empty()

		accountDetailRepo.save(_)>>sourcePaymentDetails

		AccountService accountService = new AccountServiceImpl()
		accountService.accountDetailRepo = accountDetailRepo
		when:
		accountService.updateBalance("9876432",paymentAmountRequestDto)

		then:
		BusinessException e = thrown()
		e.getErrorDetails().getErrorCode() == "423"
		e.getErrorDetails().getErrorMsgKey() == "Account does not exist"
	}


	def "create account"() {
		given:
		AccountRequestDto createAccountDto = new AccountRequestDto()
		createAccountDto.setMobileNumber("98765432")
		createAccountDto.setCountryCode("NO")


		Account accountDetails = new Account()
		accountDetails.setAccountId(132321L)
		accountDetails.setAccountNo("12345678901")
		accountDetails.setBalance(BigDecimal.valueOf(100000L))
		accountDetails.setCreatedDt(new Date())
		accountDetails.setCustomerId(1L)
		accountDetails.setIbanNo("NO9386011234567")
		//sourcePaymentDetails.setIsActive('Y');
		accountDetails.setVirtualCardDetails(new VirtualCardDetails())

		AccountView accountView = new AccountView()
		accountView.setMobileNo("98765432")
		accountView.setCustomerId(1L)
		accountView.setStatusId(1)


		VirtualCardDetails vcardDetails =new VirtualCardDetails()
		vcardDetails.setVCardId(1L)

		def accountDetailRepo = Mock(AccountRepo.class)
		def accountViewRepo = Mock(AccountViewRepo.class)
		def virtualCardRepo = Mock(VirtualCardRepo.class)
		def productConfigurationRepo = Mock(ProductConfigurationRepo.class)
		def accountNumberGenerationService = Mock(AccountNumbergenerationService)

		VirtualCardHelper virtualCardHelper = Mock(VirtualCardHelper.class);
		virtualCardHelper.createCardDetails(_, _)>>vcardDetails

		accountDetailRepo.findByCustomerId(_)>>Optional.empty()
		accountDetailRepo.save(_)>>>[accountDetails, accountDetails]
		accountViewRepo.findByMobileNo(_)>>Optional.ofNullable(accountView)
		virtualCardRepo.save(_)>>vcardDetails
		
		accountNumberGenerationService.getAccountNumber(_) >>> ["4116616116","481191991919"]
		
		ProductConfiguration pconfig = new ProductConfiguration()
		pconfig.setAccountNo(8611L)
		pconfig.setCardNo(46616161616464L)
		productConfigurationRepo.fetchProductConfig()>> pconfig
		
		def accountHelper = Mock(AccountHelper)

		AccountService accountService = new AccountServiceImpl()
		accountService.accountDetailRepo = accountDetailRepo
		accountService.accountViewRepo = accountViewRepo
		accountService.accountNumberGenerationService = accountNumberGenerationService
		accountService.virtualCardRepo = virtualCardRepo
		accountService.productConfigurationRepo = productConfigurationRepo
		accountService.ibanCheckdigit=93;
		accountService.bankIdentifierNumber=492557;
		accountService.visaCardType=4;
		accountService.accountHelper = accountHelper
		when:
		accountService.createAccount(createAccountDto,"1234")

		then:
		vcardDetails.getVCardId()==1L
	}


	def "create account customer not found"() {
		given:
		AccountRequestDto createAccountDto = new AccountRequestDto()
		createAccountDto.setMobileNumber("98765432")
		createAccountDto.setCountryCode("NO")


		Account accountDetails = new Account()
		accountDetails.setAccountId(1L)
		accountDetails.setAccountNo("123456789")
		accountDetails.setBalance(BigDecimal.valueOf(100000L))
		accountDetails.setCreatedDt(new Date())
		accountDetails.setCustomerId(1L)
		accountDetails.setIbanNo("NO9386011234567")
		//sourcePaymentDetails.setIsActive('Y');
		accountDetails.setVirtualCardDetails(new VirtualCardDetails())

		AccountNumbergenerationService accountNumberGenerationService = new AccountNumbergenerationServiceImpl()

		AccountView accountView = new AccountView()
		accountView.setMobileNo("98765432")
		accountView.setCustomerId(1L)
		accountView.setStatusId(1)

		def accountDetailRepo = Mock(AccountRepo.class)
		def accountViewRepo = Mock(AccountViewRepo.class)
		//GroovyMock(VirtualCardHelperImpl, global: true)
		//VirtualCardHelperImpl.createCardDetails(_, _)>>accountDetails

		accountDetailRepo.findByCustomerId(_)>>Optional.empty()
		accountDetailRepo.save(_)>>>[accountDetails, accountDetails]
		accountViewRepo.findByMobileNo(_)>>Optional.empty()

		AccountService accountService = new AccountServiceImpl()
		accountService.accountDetailRepo = accountDetailRepo
		accountService.accountViewRepo = accountViewRepo
		accountService.accountNumberGenerationService = accountNumberGenerationService
		accountService.ibanCheckdigit=93;
		accountService.bankIdentifierNumber=492557;
		accountService.visaCardType=4;
		when:
		accountService.createAccount(createAccountDto,"1234")

		then:
		BusinessException e = thrown()
		e.getErrorDetails().getErrorCode() == "422"
		e.getErrorDetails().getErrorMsgKey() == "Customer not found.!"

	}


	def "create account account already exists"() {
		given:
		AccountRequestDto createAccountDto = new AccountRequestDto()
		createAccountDto.setMobileNumber("98765432")
		createAccountDto.setCountryCode("NO")


		Account accountDetails = new Account()
		accountDetails.setAccountId(1L)
		accountDetails.setAccountNo("123456789")
		accountDetails.setBalance(BigDecimal.valueOf(100000L))
		accountDetails.setCreatedDt(new Date())
		accountDetails.setCustomerId(1L)
		accountDetails.setIbanNo("NO9386011234567")
		//sourcePaymentDetails.setIsActive('Y');
		accountDetails.setVirtualCardDetails(new VirtualCardDetails())

		AccountNumbergenerationService accountNumberGenerationService = new AccountNumbergenerationServiceImpl()

		AccountView accountView = new AccountView()
		accountView.setMobileNo("98765432")
		accountView.setCustomerId(1L)
		accountView.setStatusId(1)

		def accountDetailRepo = Mock(AccountRepo.class)
		def accountViewRepo = Mock(AccountViewRepo.class)
		//GroovyMock(VirtualCardHelperImpl, global: true)
	//	VirtualCardHelperImpl.createCardDetails(_, _)>>accountDetails

		accountDetailRepo.findByCustomerId(_)>>Optional.ofNullable(accountDetails)
		accountDetailRepo.save(_)>>>[accountDetails, accountDetails]
		accountViewRepo.findByMobileNo(_)>>Optional.ofNullable(accountView)

		AccountService accountService = new AccountServiceImpl()
		accountService.accountDetailRepo = accountDetailRepo
		accountService.accountViewRepo = accountViewRepo
		accountService.accountNumberGenerationService = accountNumberGenerationService
		when:
		accountService.createAccount(createAccountDto,"1234")

		then:
		BusinessException e = thrown()
		e.getErrorDetails().getErrorCode() == "409"
		e.getErrorDetails().getErrorMsgKey() == "Account already exists."

	}


	def "fetch account"() {
		given:

		Account accountDetails = new Account()
		accountDetails.setAccountId(1L)
		accountDetails.setAccountNo("123456789")
		accountDetails.setBalance(BigDecimal.valueOf(100000L))
		accountDetails.setCreatedDt(new Date())
		accountDetails.setCustomerId(1L)
		accountDetails.setIbanNo("NO9386011234567")
		//sourcePaymentDetails.setIsActive('Y');



		AccountView accountView = new AccountView()
		accountView.setMobileNo("98765432")
		accountView.setCustomerId(1L)
		accountView.setStatusId(1)

		VirtualCardDetails vcardDetails =new VirtualCardDetails()
		vcardDetails.setVCardId(1L)
		vcardDetails.setIssuerNm(CardType.VISA)
		vcardDetails.setCardIssueTs(new Date())
		vcardDetails.setExpiryDt(new Date())

		accountDetails.setVirtualCardDetails(vcardDetails)


		def accountDetailRepo = Mock(AccountRepo.class)
		def accountViewRepo = Mock(AccountViewRepo.class)
		ExternalCardRepo externalCardRepo = Mock(ExternalCardRepo.class)
		ExternalPaymentCard card = new ExternalPaymentCard()
		card.setCustomerId(1L)
		List<ExternalPaymentCard> cards = new ArrayList<>()
		externalCardRepo.findByCustomerId(_) >> cards
		accountDetailRepo.findByVirtualCardDetailsCustomerId(_)>>Optional.ofNullable(accountDetails)
		accountViewRepo.findByMobileNo(_)>>Optional.ofNullable(accountView)

		AccountService accountService = new AccountServiceImpl()
		accountService.accountDetailRepo = accountDetailRepo
		accountService.accountViewRepo = accountViewRepo
		accountService.externalCardRepo = externalCardRepo
		
		when:
		accountService.fetchAccountCardDetails("98765432")

		then:
		accountDetails.getAccountId()==1L
	}


	def "fetch account customer does not exist"() {
		given:

		Account accountDetails = new Account()
		accountDetails.setAccountId(1L)
		accountDetails.setAccountNo("123456789")
		accountDetails.setBalance(BigDecimal.valueOf(100000L))
		accountDetails.setCreatedDt(new Date())
		accountDetails.setCustomerId(1L)
		accountDetails.setIbanNo("NO9386011234567")
		//sourcePaymentDetails.setIsActive('Y');
		accountDetails.setVirtualCardDetails(new VirtualCardDetails())


		AccountView accountView = new AccountView()
		accountView.setMobileNo("98765432")
		accountView.setCustomerId(1L)
		accountView.setStatusId(1)

		def accountDetailRepo = Mock(AccountRepo.class)
		def accountViewRepo = Mock(AccountViewRepo.class)

		accountDetailRepo.findByVirtualCardDetailsCustomerId(_)>>Optional.ofNullable(accountDetails)
		accountViewRepo.findByMobileNo(_)>>Optional.empty()

		AccountService accountService = new AccountServiceImpl()
		accountService.accountDetailRepo = accountDetailRepo
		accountService.accountViewRepo = accountViewRepo

		when:
		accountService.fetchAccountCardDetails("98765432")

		then:
		BusinessException e = thrown()
		e.getErrorDetails().getErrorCode() == "420"
		e.getErrorDetails().getErrorMsgKey() == "Customer not found.!"
	}


	def "fetch account email not verified"() {
		given:

		Account accountDetails = new Account()
		accountDetails.setAccountId(1L)
		accountDetails.setAccountNo("123456789")
		accountDetails.setBalance(BigDecimal.valueOf(100000L))
		accountDetails.setCreatedDt(new Date())
		accountDetails.setCustomerId(1L)
		accountDetails.setIbanNo("NO9386011234567")
		//sourcePaymentDetails.setIsActive('Y');
		accountDetails.setVirtualCardDetails(new VirtualCardDetails())


		AccountView accountView = new AccountView()
		accountView.setMobileNo("98765432")
		accountView.setCustomerId(1L)
		accountView.setStatusId(3)

		def accountDetailRepo = Mock(AccountRepo.class)
		def accountViewRepo = Mock(AccountViewRepo.class)

		accountDetailRepo.findByVirtualCardDetailsCustomerId(_)>>Optional.ofNullable(accountDetails)
		accountViewRepo.findByMobileNo(_)>>Optional.ofNullable(accountView)

		AccountService accountService = new AccountServiceImpl()
		accountService.accountDetailRepo = accountDetailRepo
		accountService.accountViewRepo = accountViewRepo

		//VirtualCardHelperImpl.metaClass.static.createCardDetails = {return new VirtualCardDetails()};
		when:
		accountService.fetchAccountCardDetails("98765432")

		then:
		BusinessException e = thrown()
		e.getErrorDetails().getErrorCode() == "421"
		e.getErrorDetails().getErrorMsgKey() == "Email not verified"
	}


	def "fetch account account does not exist"() {
		given:

		Account accountDetails = new Account()
		accountDetails.setAccountId(1L)
		accountDetails.setAccountNo("123456789")
		accountDetails.setBalance(BigDecimal.valueOf(100000L))
		accountDetails.setCreatedDt(new Date())
		accountDetails.setCustomerId(1L)
		accountDetails.setIbanNo("NO9386011234567")
		//sourcePaymentDetails.setIsActive('Y');
		accountDetails.setVirtualCardDetails(new VirtualCardDetails())


		AccountView accountView = new AccountView()
		accountView.setMobileNo("98765432")
		accountView.setCustomerId(1L)
		accountView.setStatusId(1)

		def accountDetailRepo = Mock(AccountRepo.class)
		def accountViewRepo = Mock(AccountViewRepo.class)

		accountDetailRepo.findByVirtualCardDetailsCustomerId(_)>>Optional.empty()
		accountViewRepo.findByMobileNo(_)>>Optional.ofNullable(accountView)

		AccountService accountService = new AccountServiceImpl()
		accountService.accountDetailRepo = accountDetailRepo
		accountService.accountViewRepo = accountViewRepo

		//VirtualCardHelperImpl.metaClass.static.createCardDetails = {return new VirtualCardDetails()};
		when:
		accountService.fetchAccountCardDetails("98765432")

		then:
		BusinessException e = thrown()
		e.getErrorDetails().getErrorCode() == "422"
		e.getErrorDetails().getErrorMsgKey() == "Account does not exist"
	}

	def "fetch account account details using qrcode"() {

		VirtualCardDetails vcardDetails =new VirtualCardDetails()
		vcardDetails.setVCardId(1L)
		vcardDetails.setIssuerNm(CardType.VISA)
		vcardDetails.setCardIssueTs(new Date())
		vcardDetails.setExpiryDt(new Date())

		Account accountDetails = new Account()
		accountDetails.setAccountId(1L)
		accountDetails.setAccountNo("123456789")
		accountDetails.setBalance(BigDecimal.valueOf(100000L))
		accountDetails.setCreatedDt(new Date())
		accountDetails.setCustomerId(1L)
		accountDetails.setIbanNo("NO9386011234567")
		accountDetails.setVirtualCardDetails(vcardDetails)

		AccountView accountView = new AccountView()
		accountView.setMobileNo("98765432")
		accountView.setCustomerId(1L)
		accountView.setStatusId(1)

		PayeeAccountDetailsDtoResult payeeAccountDetail = new PayeeAccountDetailsDtoResult();
		payeeAccountDetail.setAccountNumber("123456543212344");
		payeeAccountDetail.setSwiftCode("fdsfd");
		payeeAccountDetail.setCountryCode("NO");
		payeeAccountDetail.setMobileNumber("9876543210");
		payeeAccountDetail.setPayeeName("jon snow");

		def accountDetailRepo = Mock(AccountRepo.class)
		def accountViewRepo = Mock(AccountViewRepo.class)

		accountDetailRepo.findByQrCode(_)>>Optional.ofNullable(accountDetails)
		accountViewRepo.findByCustomerId(_)>>Optional.ofNullable(accountView)


		AccountService accountService = new AccountServiceImpl()
		accountService.accountDetailRepo = accountDetailRepo
		accountService.accountViewRepo = accountViewRepo

		when:
		accountService.fetchAccountDEtailsByQrCode("12343","9876543210")

		then:
		payeeAccountDetail
	}

	def "fetch account details by payee number"() {

		given:
		String payeeNumber = "985647"

		AccountRepo accountDetailRepo = Mock(AccountRepo.class)
		AccountViewRepo accountViewRepo = Mock(AccountViewRepo.class)

		AccountView accountView = new AccountView()
		accountView.setMobileNo("98765432")
		accountView.setCustomerId(1L)
		accountView.setStatusId(1)

		accountViewRepo.findByMobileNo(_)>>Optional.ofNullable(accountView)

		VirtualCardDetails vcardDetails =new VirtualCardDetails()
		vcardDetails.setVCardId(1L)
		vcardDetails.setIssuerNm(CardType.VISA)
		vcardDetails.setCardIssueTs(new Date())
		vcardDetails.setExpiryDt(new Date())

		Account accountDetails = new Account()
		accountDetails.setAccountId(1L)
		accountDetails.setAccountNo("123456789")
		accountDetails.setBalance(BigDecimal.valueOf(100000L))
		accountDetails.setCreatedDt(new Date())
		accountDetails.setCustomerId(1L)
		accountDetails.setIbanNo("NO9386011234567")
		accountDetails.setVirtualCardDetails(vcardDetails)

		accountDetailRepo.findByCustomerId(_) >> Optional.ofNullable(accountDetails)

		AccountService accountService = new AccountServiceImpl()
		accountService.accountDetailRepo = accountDetailRepo
		accountService.accountViewRepo = accountViewRepo

		when:
		PayeeAccountDetailsDtoResult payeeAccountDetailsDtoResult = accountService.fetchPayeeAccountDetails(payeeNumber)

		then:
		payeeAccountDetailsDtoResult.getAccountNumber().equals("123456789") == true
	}
}
