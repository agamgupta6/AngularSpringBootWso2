package com.no.mob.account.controller

import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity

import com.no.mob.account.common.GenericResponse
import com.no.mob.account.entity.Account
import com.no.mob.account.entity.VirtualCardDetails
import com.no.mob.account.model.AccountDetailsResponseDtoResult
import com.no.mob.account.model.AccountRequestDto
import com.no.mob.account.model.PayeeAccountDetailsDtoResult
import com.no.mob.account.model.PaymentAmountRequestDto
import com.no.mob.account.service.AccountService

import spock.lang.Specification

class AccountApiControllerSpec extends Specification{


	def "debit account controller"() {
		given:
		String AuthCode="abcde"
		PaymentAmountRequestDto paymentAmountRequestDto = new PaymentAmountRequestDto()
		paymentAmountRequestDto.setAccountNo("1234567")
		paymentAmountRequestDto.setAmount(BigDecimal.TEN)


		Account sourcePaymentDetails = new Account()
		sourcePaymentDetails.setAccountId(1L)
		sourcePaymentDetails.setAccountNo("1234567")
		sourcePaymentDetails.setBalance(BigDecimal.valueOf(100000L))
		sourcePaymentDetails.setCreatedDt(new Date())
		sourcePaymentDetails.setCustomerId(1L)
		sourcePaymentDetails.setIbanNo("NO9386011234567")
		//sourcePaymentDetails.setIsActive('Y');
		sourcePaymentDetails.setVirtualCardDetails(new VirtualCardDetails())

		AccountService accountService = Mock(AccountService.class)

		accountService.debitBalance(_) >> {}

		AccountApiController accountApiController = new AccountApiController();
		accountApiController.accountService = accountService
		when:
		ResponseEntity<GenericResponse> response = accountApiController.debitBalance("98765432", AuthCode,paymentAmountRequestDto)

		then:

		response.status == HttpStatus.OK
		//	response.body.getResponseInfo().getResponseCode() == "200"

	}


	def "credit account controller"() {
		given:
		String AuthCode="abcde"
		PaymentAmountRequestDto paymentAmountRequestDto = new PaymentAmountRequestDto()
		paymentAmountRequestDto.setAccountNo("1234567")
		paymentAmountRequestDto.setAmount(BigDecimal.TEN)


		Account sourcePaymentDetails = new Account()
		sourcePaymentDetails.setAccountId(1L)
		sourcePaymentDetails.setAccountNo("1234567")
		sourcePaymentDetails.setBalance(BigDecimal.valueOf(100000L))
		sourcePaymentDetails.setCreatedDt(new Date())
		sourcePaymentDetails.setCustomerId(1L)
		sourcePaymentDetails.setIbanNo("NO9386011234567")
		//sourcePaymentDetails.setIsActive('Y');
		sourcePaymentDetails.setVirtualCardDetails(new VirtualCardDetails())

		AccountService accountService = Mock(AccountService.class)

		accountService.updateBalance(_) >> {}

		AccountApiController accountApiController = new AccountApiController();
		accountApiController.accountService = accountService
		when:
		ResponseEntity<GenericResponse> response = accountApiController.updateBalance("98765432", AuthCode,paymentAmountRequestDto)

		then:

		response.status == HttpStatus.OK
		response.body.getResponseInfo().getResponseCode() == "200"

	}


	def "create account controller"() {
		given:
		AccountRequestDto createAccountDto = new AccountRequestDto()
		createAccountDto.setMobileNumber("98765432")
		createAccountDto.setCountryCode("NO")


		Account sourcePaymentDetails = new Account()
		sourcePaymentDetails.setAccountId(1L)
		sourcePaymentDetails.setAccountNo("1234567")
		sourcePaymentDetails.setBalance(BigDecimal.valueOf(100000L))
		sourcePaymentDetails.setCreatedDt(new Date())
		sourcePaymentDetails.setCustomerId(1L)
		sourcePaymentDetails.setIbanNo("NO9386011234567")
		//sourcePaymentDetails.setIsActive('Y');
		sourcePaymentDetails.setVirtualCardDetails(new VirtualCardDetails())

		AccountService accountService = Mock(AccountService.class)

		accountService.createAccount(_) >> {}

		AccountApiController accountApiController = new AccountApiController();
		accountApiController.accountService = accountService
		when:
		ResponseEntity<GenericResponse> response = accountApiController.accountCreatePost(createAccountDto, "98765432", "abc")

		then:

		response.status == HttpStatus.OK
		response.body.getResponseInfo().getResponseCode() == "200"

	}


	def "fetch account details controller"() {
		given:

		Account sourcePaymentDetails = new Account()
		sourcePaymentDetails.setAccountId(1L)
		sourcePaymentDetails.setAccountNo("1234567")
		sourcePaymentDetails.setBalance(BigDecimal.valueOf(100000L))
		sourcePaymentDetails.setCreatedDt(new Date())
		sourcePaymentDetails.setCustomerId(1L)
		sourcePaymentDetails.setIbanNo("NO9386011234567")
		//sourcePaymentDetails.setIsActive('Y');
		sourcePaymentDetails.setVirtualCardDetails(new VirtualCardDetails())

		AccountService accountService = Mock(AccountService.class)


		AccountDetailsResponseDtoResult accountDetailsResponseDtoResult = new AccountDetailsResponseDtoResult()
		accountDetailsResponseDtoResult.setAccountNumber("1234567")
		accountDetailsResponseDtoResult.setBalanceAmount("1000")
		accountDetailsResponseDtoResult.setBankName("bankName")
		accountDetailsResponseDtoResult.setCardCVV(123)
		accountDetailsResponseDtoResult.setCardHolderName("cardHolderName")
		accountDetailsResponseDtoResult.setCardNumber("1234567890123456")
		accountDetailsResponseDtoResult.setCardScheme("VISA")
		accountDetailsResponseDtoResult.setCustomerId("1")
		//accountDetailsResponseDtoResult.setStatusId('1')
		accountDetailsResponseDtoResult.setValidFrom("01/2018")
		accountDetailsResponseDtoResult.setValidTo("12/2025")
		accountService.fetchAccountCardDetails(_) >> accountDetailsResponseDtoResult

		AccountApiController accountApiController = new AccountApiController();
		accountApiController.accountService = accountService
		when:
		ResponseEntity<GenericResponse> response = accountApiController.accountGetDetailsGet("98765432", "abc")

		then:

		response.status == HttpStatus.OK
		response.body.getResponseInfo().getResponseCode() == "200"

	}

	def "fetch account details by qrcode"() {
		
		PayeeAccountDetailsDtoResult payeeAccountDetail = new PayeeAccountDetailsDtoResult();
		payeeAccountDetail.setAccountNumber("123456543212344");
		payeeAccountDetail.setSwiftCode("fdsfd");
		payeeAccountDetail.setCountryCode("NO");
		payeeAccountDetail.setMobileNumber("9876543210");
		payeeAccountDetail.setPayeeName("jon snow");
		
		
	
		
		AccountApiController accountApiController = new AccountApiController();
		AccountService accountService = Mock(AccountService.class)
		accountApiController.accountService = accountService
		accountService.fetchAccountDEtailsByQrCode(_,_) >> payeeAccountDetail
		when:
		ResponseEntity<GenericResponse> response = accountApiController.accountGetAccountDetailsByQrCode("qrcode", "9876543210", "accessToke")
		then:
		response.status == HttpStatus.OK
		response.body.getResponseInfo().getResponseCode() == "200"

	}

	def "fetch account details by payee number"() {

		given:
		String payeeNumber = "985647"
		String mobileNumber = "8956471230"
		String accessToken = "854623"
		PayeeAccountDetailsDtoResult payeeAccountDetailsDto = new PayeeAccountDetailsDtoResult();
		payeeAccountDetailsDto.setAccountNumber("123456543212344");
		payeeAccountDetailsDto.setSwiftCode("fdsfd");
		payeeAccountDetailsDto.setCountryCode("NO");
		payeeAccountDetailsDto.setMobileNumber("9876543210");
		payeeAccountDetailsDto.setPayeeName("jon snow");
		payeeAccountDetailsDto.setQrCode("jon snow");

		AccountApiController accountApiController = new AccountApiController();
		AccountService accountService = Mock(AccountService.class)
		accountApiController.accountService = accountService
		accountService.fetchPayeeAccountDetails(_) >> payeeAccountDetailsDto
		when:
		ResponseEntity<GenericResponse> response = accountApiController.accountGetAccountDetailsPayeeNumberPost(payeeNumber, mobileNumber, accessToken)
		then:
		response.status == HttpStatus.OK
		response.body.getResponseInfo().getResponseCode() == "200"

	}

}
