package com.no.mob.account.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.no.mob.account.utils.AccountNumberFormatter;

import lombok.Getter;
import lombok.Setter;

/**
 * AccountDetailsResponseDtoResult
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2017-12-13T05:36:31.653Z")

@JsonInclude(Include.NON_NULL)
@Getter
@Setter
public class AccountDetailsResponseDtoResult {
	
	@JsonProperty("accountNumber")
	private String accountNumber = null;

	@JsonProperty("balanceAmount")
	private String balanceAmount = null;
	
	@JsonProperty("bankName")
	private String bankName = null;
	
	@JsonProperty("cardNumber")
	private String cardNumber = null;

	@JsonProperty("cardScheme")
	private String cardScheme = null;

	@JsonProperty("CVV")
	private int cardCVV;

	@JsonProperty("validFrom")
	private String validFrom;
	
	@JsonProperty("validTo")
	private String validTo;

	@JsonProperty("customerId")
	private String customerId = null;

	@JsonProperty("cardHolderName")
	private String cardHolderName = null;
	
	@JsonProperty("countryCode")
	private String countryCode = null;
	
	@JsonProperty("qrCode")
	private String qrCode = null;

	@JsonIgnore
	private int statusId;

	@JsonProperty("imgUrl")
	private String imgUrl;
	
	@JsonProperty("mobileNo")
	private String mobileNo;
	
	@JsonProperty("externalCards")
	private List<ExternalCardsDto> externalCardsDto;
	
	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = AccountNumberFormatter.getFormattedNumber(accountNumber);
	}
	

}
