package com.no.mob.account.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.no.mob.account.common.BusinessException;

public class DateFormatterUtil {

	private static final String DATE_FORMAT_DD_MM_YYYY = "dd/MM/yyyy";
	private static Logger log = LoggerFactory.getLogger(DateFormatterUtil.class);

	public static Date parseStringToDate(String date) {
		
		try {
			return new SimpleDateFormat(DATE_FORMAT_DD_MM_YYYY).parse(date);
		} catch (ParseException e) {
			log.error("Exception occured while parsing date with error : {}", e.getMessage());
			throw new BusinessException("406", "Invalid Expiry Date");
		}
		
	}

}
