package com.no.mob.account.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "TB_ACCOUNT_DETAILS")
public class Account implements Serializable {

	private static final long serialVersionUID = 1L;	
	
	@Id
	@SequenceGenerator(name="seq",sequenceName="account_details_account_id_seq", schema="acct", allocationSize = 1)
	@GeneratedValue(generator="seq",strategy=GenerationType.SEQUENCE)
	@Column(name = "ACCOUNT_ID", columnDefinition = "NUMERIC(12,0)", nullable = false) 
	private Long accountId;
	
	@Column(name = "IBAN_NO")
	private String ibanNo ;
	
	@Column(name = "ACCOUNT_NO")
	private String accountNo;

	@Column(name = "CUSTOMER_ID", columnDefinition = "NUMERIC(12,0)")
	private Long customerId;

	@Column(name = "ACCOUNT_CREATED_TS", columnDefinition = "DATE")
	private Date createdDt;

	@Column(name = "ACTIVE_IN")
	private char isActive;
	
	@Column(name = "QR_CODE")
	private String qrCode;

	@Column(name = "BALANCE_AM", columnDefinition = "NUMERIC(12,2)")
	private BigDecimal balance;
	
	@Column(name = "PRODUCT_CD", columnDefinition = "NUMERIC(10,0)")
	private Long productCd;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="CUSTOMER_ID",insertable = false, updatable = false, referencedColumnName="CUSTOMER_ID")
	private VirtualCardDetails virtualCardDetails;

}
