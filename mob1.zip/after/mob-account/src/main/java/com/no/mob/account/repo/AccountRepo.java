package com.no.mob.account.repo;

import java.math.BigDecimal;
import java.util.Optional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.no.mob.account.entity.Account;

@Repository
public interface AccountRepo extends CrudRepository<Account, Long> {

	public Optional<Account> findByCustomerId(Long customerId);
	
	public Account findByCustomerIdAndAccountNo(Long customerId, String accountNo);
	
	public Optional<Account> findByVirtualCardDetailsCustomerId(Long customerId);

	public Optional<Account> findByAccountNo(String accountNo);

	@Modifying(clearAutomatically = true)
	@Query(value = "update acct.TB_ACCOUNT_DETAILS a set a.BALANCE_AM = :balance where a.ACCOUNT_ID = :acctNo", nativeQuery = true)
	public void updateAccountBalance(@Param("balance") BigDecimal balance, @Param("acctNo") long acctNo);

	public Optional<Account> findByQrCode(String qrCode);
	
	public Optional<Account> findByVirtualCardDetailsVCardNo(String vCardNo);

}
