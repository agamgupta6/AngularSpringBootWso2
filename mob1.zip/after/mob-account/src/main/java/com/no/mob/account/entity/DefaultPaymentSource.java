package com.no.mob.account.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Data
@Table(name = "TB_PAYMENT_SOURCE_DETAILS")
@Entity
public class DefaultPaymentSource {

	@Id
	@SequenceGenerator(name="seq",sequenceName="default_payment_card_seq", schema="acct", allocationSize = 1)
	@GeneratedValue(generator = "seq", strategy = GenerationType.SEQUENCE)
	@Column(name = "ID", columnDefinition = "NUMERIC(12,0)", nullable = false)
	private Long id;
	
	@Column(name="PAYMENT_SOURCE")
	private String paymentSource;
	
	@Column(name = "CUSTOMER_ID", columnDefinition = "NUMERIC(12,0)", nullable = false)
	private Long customerId;
	
	@Column(name = "MCC_CODE")
	private String mccCode;
	
	@Column(name="IS_DEFAULT")
	private char isDefault;

}
