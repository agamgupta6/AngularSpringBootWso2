package com.no.mob.account.service;

import java.math.BigDecimal;

import com.no.mob.account.model.AccountDetailsResponseDtoResult;
import com.no.mob.account.model.AccountRequestDto;
import com.no.mob.account.model.PayeeAccountDetailsDtoResult;
import com.no.mob.account.model.PaymentAmountRequestDto;
import com.no.mob.account.model.VCardDetailsDTO;

public interface AccountService {

	/**
	 * 
	 * @param accountRequestDto
	 */
	public void createAccount(AccountRequestDto accountRequestDto,String accessToken);
	
	public AccountDetailsResponseDtoResult fetchAccountCardDetails(String mobileNumber);

	public BigDecimal updateBalance(String mobileNumber, PaymentAmountRequestDto paymentAmountRequestDto);

	public BigDecimal debitBalance(String mobileNumber, PaymentAmountRequestDto paymentAmountRequestDto);

	public PayeeAccountDetailsDtoResult fetchPayeeAccountDetails(String payeeNumber);
	
	public PayeeAccountDetailsDtoResult fetchAccountDEtailsByQrCode(String qrCode, String mobileNumber);

	public void validateVirtualCard(VCardDetailsDTO vCardDetails);

}
