package com.no.mob.account.common;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResponseInfo {

	private String responseCode = "200";
	
	private String responseMessage = "SUCCESS";
}	
