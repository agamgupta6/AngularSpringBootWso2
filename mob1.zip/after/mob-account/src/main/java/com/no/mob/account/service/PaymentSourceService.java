package com.no.mob.account.service;

import com.no.mob.account.model.DefaultPaymentSourceDto;

public interface PaymentSourceService {

	public void makeDefaultPaymentSource(DefaultPaymentSourceDto defaultPaymentSourceDto, String mobileNumber);

}
