package com.no.mob.account.common;

public interface BaseErrorResult {
}
