package com.no.mob.account.common;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class ResponseConverter {
	private ResponseConverter() {
	}

	/**
	 * @param response
	 * @return GenericResponse This method prepare generic response for success
	 *         cases
	 */
	public static ResponseEntity<GenericResponse> formResponse() {
		GenericResponse response = new GenericResponse();
		response.setResponseInfo(new ResponseInfo());
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	/**
	 * @param errorDetails
	 * @return GenericResponse This method prepare generic response for failure
	 *         cases
	 */
	public static ResponseEntity<GenericResponse> formGenericErrorResponse(
			ErrorDetails errorDetails) {
		GenericErrorResponse genericErrorResponse = new GenericErrorResponse();
		ResponseInfo responseInfo = new ResponseInfo();
		HttpStatus status;
		if (null != errorDetails) {
			responseInfo.setResponseCode(errorDetails.getErrorCode());
			responseInfo.setResponseMessage(errorDetails.getErrorMsgKey());
			genericErrorResponse.setResponseInfo(responseInfo);
			status = HttpStatus.valueOf(Integer.valueOf(errorDetails.getErrorCode()));
		} else {
			status = HttpStatus.INTERNAL_SERVER_ERROR;
		}
		return new ResponseEntity<>(genericErrorResponse, status);
	}

	/**
	 * Creates a generic response structure with input object.
	 * 
	 * @param response
	 * @return
	 */
	public static ResponseEntity<GenericResponse> formResponse(Object response) {
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setResponseInfo(new ResponseInfo());
		genericResponse.setResult(response);
		return new ResponseEntity<>(genericResponse,
				HttpStatus.OK);
	}
}
