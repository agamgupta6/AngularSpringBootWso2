package com.no.mob.account.repo;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.no.mob.account.entity.AccountView;

public interface AccountViewRepo extends CrudRepository<AccountView,Long> {

	public Optional<AccountView> findByMobileNo(String mobileNo);

	public Optional<AccountView> findByCustomerId(Long string);
	
}
