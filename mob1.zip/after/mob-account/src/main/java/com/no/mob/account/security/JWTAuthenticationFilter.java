package com.no.mob.account.security;

import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.no.mob.account.common.CommonUtils;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;

@Component
public class JWTAuthenticationFilter {
	
	@Value("${mob.create.token.code}")
    private String tokenCode;

	public String genetareSecret(String key) {
		return CommonUtils.hashEmail(key, tokenCode);
	}

	public boolean validateToken(String jwt, String identifier) {
		Boolean isValid = false;
		Claims claim = Jwts.parser()
				.setSigningKey(genetareSecret(identifier).getBytes())
				.parseClaimsJws(jwt).getBody();
		if ((claim.getExpiration().compareTo(new Date(System.currentTimeMillis()))) == 1 &&
				claim.getSubject().equalsIgnoreCase(identifier)) {
			isValid = true;
		}
		return isValid;
	}

}
