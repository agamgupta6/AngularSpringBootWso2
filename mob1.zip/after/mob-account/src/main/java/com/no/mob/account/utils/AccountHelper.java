package com.no.mob.account.utils;

import java.math.BigDecimal;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.no.mob.account.model.CreditRequestDto;
import com.no.mob.account.model.PaymentSourceRequestDto;
import com.no.mob.account.model.PaymentTransferRequestDto;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class AccountHelper {

	private static final String JSON_EXCEPTION_OCCURED = "JSONException occured :{}";
	@Autowired
	RestTemplate restTemplate;
	
	public void creditBalance(String creditAccountUri, String mobileNumber, String token,CreditRequestDto creditRequestDto,BigDecimal amount) {
		HttpHeaders httpHeaders = setCommonHttpHeaders(mobileNumber, token);
		JSONObject json = new JSONObject();
		try {
			json.put("amount", amount);
			json.put("accountNo", creditRequestDto.getAccountNo());
		} catch (JSONException e) {
			log.error(JSON_EXCEPTION_OCCURED,e);
		}
		HttpEntity<String> httpEntity = new HttpEntity<>(json.toString(), httpHeaders);
		restTemplate.postForObject(creditAccountUri, httpEntity, String.class);
	}

	private HttpHeaders setCommonHttpHeaders(String mobileNumber, String token) {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.set("Content-Type", "application/json");
		httpHeaders.set("Authorization", token);
		httpHeaders.set("mobile_number", mobileNumber);
		return httpHeaders;
	}
	
	public void saveTransaction(String paymentTransactionUri,String mobileNo,String token, PaymentTransferRequestDto paymentTransferRequestDto) {
		HttpHeaders httpHeaders = setCommonHttpHeaders(mobileNo, token);

		JSONObject json = new JSONObject();
		try {
			json.put("amount", paymentTransferRequestDto.getAmount());
			json.put("accountId", paymentTransferRequestDto.getAccountId());
			json.put("transactionText", paymentTransferRequestDto.getTransactionTxt());
			json.put("senderId", paymentTransferRequestDto.getSenderId());
			json.put("countryCode", paymentTransferRequestDto.getCountryCode());
			json.put("receiverId", paymentTransferRequestDto.getReceiverId());
		} catch (JSONException e) {
			log.error(JSON_EXCEPTION_OCCURED,e);
		}
		HttpEntity<String> httpEntity = new HttpEntity<>(json.toString(), httpHeaders);
		restTemplate.postForObject(paymentTransactionUri, httpEntity, String.class);
	}

	public void savePaymentSource(String paymentSourceUri, String mobileNumber, String accessToken,PaymentSourceRequestDto paymentSource) {
		HttpHeaders httpHeaders = setCommonHttpHeaders(mobileNumber, accessToken);

		JSONObject json = new JSONObject();
		try {
			json.put("cardNumber", paymentSource.getCardNumber());
			json.put("customerId", paymentSource.getCustomerId());
		} catch (JSONException e) {
			log.error(JSON_EXCEPTION_OCCURED,e);
		}
		HttpEntity<String> httpEntity = new HttpEntity<>(json.toString(), httpHeaders);
		restTemplate.postForObject(paymentSourceUri, httpEntity, String.class);
	}

	public void createCustomerConcent(String customerConcentUri,String mobileNumber,String accessToken) {
		HttpHeaders httpHeaders = setCommonHttpHeaders(mobileNumber, accessToken);
		HttpEntity<String> httpEntity = new HttpEntity<>(httpHeaders);
		restTemplate.postForObject(customerConcentUri, httpEntity, String.class);
	}
	
}
