package com.no.mob.account.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "TB_EXTERNAL_PAYMENT_CARD")
@Data
public class ExternalPaymentCard implements Serializable {

private static final long serialVersionUID = 1L;	
	
	@Id
	@SequenceGenerator(name="seq",sequenceName="external_payment_card_seq", schema="acct", allocationSize = 1)
	@GeneratedValue(generator="seq",strategy=GenerationType.SEQUENCE)
	@Column(name = "PAYMENT_CARD_ID", columnDefinition = "NUMERIC(12,0)", nullable = false) 
	private Long paymentCardId;
	
	@Column(name = "CARD_NUMBER")
	private String cardNumber ;
	
	@Column(name = "CARD_NAME")
	private String cardName;

	@Column(name = "VALID_TO")
	private String validTo;
	
	@Column(name = "CUSTOMER_ID", columnDefinition = "NUMERIC(12,0)")
	private Long customerId;
	
	@Column(name="ACTIVE_IN")	
	private char activeIn;
	
	@Column(name="CARD_SCHEME")
	private String cardScheme;
	
	@Column(name="CREATED_DT")
	private Date createdDt;
	
	@Column(name="UPDATED_DT")
	private Date updatedDt;
	
	@Column(name="CREATED_BY")
	private String createdBy;
	
	@Column(name= "UPDATED_BY")
	private String updatedBy;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="CUSTOMER_ID",insertable = false, updatable = false, referencedColumnName="CUSTOMER_ID")
	private VirtualCardDetails virtualCardDetails;

}
