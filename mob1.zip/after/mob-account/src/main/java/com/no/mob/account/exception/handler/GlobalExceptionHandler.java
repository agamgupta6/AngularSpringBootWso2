package com.no.mob.account.exception.handler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.no.mob.account.common.BusinessException;
import com.no.mob.account.common.ErrorDetails;
import com.no.mob.account.common.GenericResponse;
import com.no.mob.account.common.ResponseConverter;
import com.no.mob.account.common.ResponseInfo;

@ControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(BusinessException.class)
	public ResponseEntity<GenericResponse> defaultErrorHandler(BusinessException e) {
		ErrorDetails errorDetails = e.getErrorDetails();
		return ResponseConverter.formGenericErrorResponse(errorDetails);
	}
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<GenericResponse> methodArgumentNotValid(MethodArgumentNotValidException e) {
		GenericResponse genericResponse = new GenericResponse();
		ResponseInfo responseInfo = new ResponseInfo();
		responseInfo.setResponseCode("400");
		responseInfo.setResponseMessage(e.getMessage());
		genericResponse.setResponseInfo(responseInfo);
		return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
	}
}
