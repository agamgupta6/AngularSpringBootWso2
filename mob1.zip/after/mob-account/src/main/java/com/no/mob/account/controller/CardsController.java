package com.no.mob.account.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.no.mob.account.common.GenericResponse;
import com.no.mob.account.model.DefaultPaymentSourceDto;
import com.no.mob.account.model.ExternalCardsDto;
import com.no.mob.account.service.CardService;
import com.no.mob.account.service.PaymentSourceService;

import io.swagger.annotations.ApiParam;

@Controller
public class CardsController {

	@Autowired
	private CardService cardService;
	
	@Autowired
	private PaymentSourceService paymentSourceService;

	@PostMapping(value = "/addExternalPaymentCard", produces = { "application/json" })
	public ResponseEntity<GenericResponse> addExternalCard(
			@ApiParam(value = "") @RequestHeader(value = "mobile_number", required = true) String mobileNumber,
			@ApiParam(value = "") @RequestHeader(value = "Authorization", required = false) String accessToken,
			@RequestBody ExternalCardsDto cardsDto) {

		cardService.addExternalCard(cardsDto, mobileNumber);

		return new ResponseEntity<>(new GenericResponse(), HttpStatus.OK);
	}

	@PostMapping(value = "/makeDefaultPaymentSource", produces = { "application/json" })
	public ResponseEntity<GenericResponse> makeDefaultPaymentSource(
			@ApiParam(value = "") @RequestHeader(value = "mobile_number", required = true) String mobileNumber,
			@ApiParam(value = "") @RequestHeader(value = "Authorization", required = false) String accessToken,
			@RequestBody DefaultPaymentSourceDto defaultPaymentSourceDto) {

		paymentSourceService.makeDefaultPaymentSource(defaultPaymentSourceDto, mobileNumber);

		return new ResponseEntity<>(new GenericResponse(), HttpStatus.OK);
	}

	@DeleteMapping(value = "/deleteCard", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<GenericResponse> deleteCard(
			@RequestHeader(value = "mobile_number", required = true) String mobileNumber,
			@RequestHeader(value = "Authorization", required = false) String accessToken,
			@RequestBody @Validated ExternalCardsDto externalCardsDto) {

		cardService.deleteCard(externalCardsDto.getCardNumber(), mobileNumber);
		return new ResponseEntity<>(HttpStatus.OK);
	}

}
