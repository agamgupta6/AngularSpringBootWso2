package com.no.mob.account.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

import lombok.Getter;
import lombok.Setter;

@Entity
@Immutable
@Getter
@Setter
@Table(name="vw_accnt_details")
public class AccountView implements Serializable {


	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="CUSTOMER_ID", columnDefinition = "NUMERIC(12,0)")
	private Long customerId;
	
	@Column(name="MOBILE_NO")
	private String mobileNo;
	
	@Column(name="STATUS_ID")
	private int statusId;
	
	@Column(name="FIRST_NM")
	private String firstName;
	
	@Column(name="LAST_NM")
	private String lastName;
	
	@Column(name="COUNTRY_CD")
	private String countryCode;
	
	@Column(name="CURRENCY")
	private String currency;
	
	@Column(name="PHOTO_URL_TX")
	private String customerImg;
}
