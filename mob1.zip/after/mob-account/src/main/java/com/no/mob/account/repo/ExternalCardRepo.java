package com.no.mob.account.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.no.mob.account.entity.ExternalPaymentCard;

public interface ExternalCardRepo extends CrudRepository<ExternalPaymentCard, Long> {
	
	public List<ExternalPaymentCard> findByCustomerId(Long customerId);
	
	
	@Query(value = "select * from acct.TB_EXTERNAL_PAYMENT_CARD where customer_id= :customerId and active_in = :activeIn", nativeQuery =true )
	public List<ExternalPaymentCard> fetchCardDetailsByCustomerIdAndActiveIn(@Param("customerId") Long customerId, @Param("activeIn") char isActiveIn);
	
	public Optional<ExternalPaymentCard> findByCardNumber(String cardno);

	public Optional<ExternalPaymentCard> findByCardNumberAndCustomerId(String paymentSource, Long customerId);

}
