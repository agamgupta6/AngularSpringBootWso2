package com.no.mob.account.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "TB_PRODUCT_CONFIGURATION")
public class ProductConfiguration {
	
	@Id
	@SequenceGenerator(name="seq",sequenceName="tb_product_id_seq", schema="acct", allocationSize = 1)
	@GeneratedValue(generator="seq",strategy=GenerationType.SEQUENCE)
	@Column(name = "PRODUCT_CD",columnDefinition = "NUMERIC(10,0)" ,nullable = false)
	private Long productCd;
	
	@Column(name = "PRODUCT_NM")
	private String productName;
	
	@Column(name= "CURRENCY")
	private String currency;
	
	@Column(name = "COUNTRY_CD")
	private String countryCd;
	
	@Column(name = "DESCRIPTION")
	private String description;
	
	@Column(name = "ISALLOWMULTIPLEACCOUNTS")
	private String isAllowMultipleAccounts;
	
	@Column(name = "INTEREST")
	private int interest;
	
	@Column(name = "INTEREST_IN_DAYS")
	private int intersetInDays;
	
	@Column(name = "CREDITED_INTEREST")
	private String creditedInterest;
	
	@Column(name = "SYNC_IN_DAYS_COUNT")
	private int syncInDaysCount;
	
	@Column(name = "ISINTERNATIONALTRANSFERALLOWED")
	private int isInternationalTransferAllowed;
	
	@Column(name = "PRODUCT_FEE")
	private int productFee;
	
	@Column(name ="FEE_DEDUCTED")
	private int feeDeducted;
	
	@Column(name = "ACCOUNT_NO",columnDefinition = "NUMERIC(12,0)")
	private Long accountNo;
	
	@Column(name = "CARD_NO", columnDefinition = "NUMERIC(12,0)")
	private Long cardNo;
	
	@Column(name = "CARD_TYPE")
	private String cardType;
	    

}
