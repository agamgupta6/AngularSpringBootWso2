package com.no.mob.account.utils;

import org.springframework.stereotype.Service;

@Service
public class AccountNumbergenerationServiceImpl implements AccountNumbergenerationService {
	
	public String getAccountNumber(String checkValue) {
		int sum = 0;
		boolean oddValue = true;
		for (int i = checkValue.length() - 1; i >= 0; i--) {
			int n = Integer.parseInt(checkValue.substring(i, i + 1));
			if (oddValue) {
				n *= 2;
				if (n > 9) {
					n = (n % 10) + 1;
				}
			}
			sum += n;
			oddValue = !oddValue;
		}
		return checkValue+String.valueOf((sum*9)%10);
	
	}
}
