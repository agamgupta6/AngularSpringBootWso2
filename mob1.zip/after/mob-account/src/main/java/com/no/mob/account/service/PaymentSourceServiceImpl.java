package com.no.mob.account.service;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.no.mob.account.common.BusinessException;
import com.no.mob.account.entity.Account;
import com.no.mob.account.entity.AccountView;
import com.no.mob.account.entity.DefaultPaymentSource;
import com.no.mob.account.entity.ExternalPaymentCard;
import com.no.mob.account.model.DefaultPaymentSourceDto;
import com.no.mob.account.repo.AccountRepo;
import com.no.mob.account.repo.AccountViewRepo;
import com.no.mob.account.repo.DefaultPaymentSourceRepo;
import com.no.mob.account.repo.ExternalCardRepo;
import com.no.mob.account.repo.MccCodeRepo;

@Service
public class PaymentSourceServiceImpl implements PaymentSourceService {

	@Autowired
	private AccountRepo accountRepo;

	@Autowired
	private AccountViewRepo accountViewRepo;

	@Autowired
	private ExternalCardRepo externalCardsRepo;

	@Autowired
	private DefaultPaymentSourceRepo defaultPaymentSourceRepo;

	@Autowired
	private MccCodeRepo mccCodeRepo;

	private Logger log = LoggerFactory.getLogger(this.getClass());

	/*
	 * @Value("${fetch.mcc.values.uri}") private String findMccCodesUri;
	 */

	@Override
	public void makeDefaultPaymentSource(DefaultPaymentSourceDto defaultPaymentSourceDto, String mobileNumber) {

		AccountView accountView = accountViewRepo.findByMobileNo(mobileNumber)
				.orElseThrow(() -> new BusinessException("404", "Customer Details Not Found"));

		validatePaymentSource(defaultPaymentSourceDto, accountView);

		List<String> mccCodes = mccCodeRepo.fetchMccCodes().stream().map(x -> String.valueOf(x.getMccCd()))
				.collect(Collectors.toList());

		log.info("Mcc Codes {}", mccCodes);

		defaultPaymentSourceDto.getPreferences().stream().filter(preference -> mccCodes.contains(preference))
				.forEach(preference -> {

					List<DefaultPaymentSource> defaultPaymentSources = defaultPaymentSourceRepo
							.findByCustomerIdAndMccCode(accountView.getCustomerId(), preference);

					if (!defaultPaymentSources.isEmpty()) {
						defaultPaymentSources.stream().forEach(defaultPaymentSource -> {
							if (defaultPaymentSource.getPaymentSource().equals(preference)) {
								defaultPaymentSource.setIsDefault('Y');
								defaultPaymentSourceRepo.save(defaultPaymentSource);
							} else {
								defaultPaymentSource.setIsDefault('N');
								defaultPaymentSourceRepo.save(defaultPaymentSource);
								log.info("default payment sources empty");
								DefaultPaymentSource defaultPaymentSourceNew = new DefaultPaymentSource();
								defaultPaymentSourceNew.setCustomerId(accountView.getCustomerId());
								defaultPaymentSourceNew.setIsDefault('Y');
								defaultPaymentSourceNew.setMccCode(preference);
								defaultPaymentSourceNew.setPaymentSource(defaultPaymentSourceDto.getPaymentSource());
								defaultPaymentSourceRepo.save(defaultPaymentSourceNew);
							}
						});
					} else {

						log.info("default payment sources empty");
						DefaultPaymentSource defaultPaymentSource = new DefaultPaymentSource();
						defaultPaymentSource.setCustomerId(accountView.getCustomerId());
						defaultPaymentSource.setIsDefault('Y');
						defaultPaymentSource.setMccCode(preference);
						defaultPaymentSource.setPaymentSource(defaultPaymentSourceDto.getPaymentSource());
						defaultPaymentSourceRepo.save(defaultPaymentSource);
					}
				});
	}

	private void validatePaymentSource(DefaultPaymentSourceDto defaultPaymentSourceDto, AccountView accountView) {

		final Account accountDetails = accountRepo.findByCustomerIdAndAccountNo(accountView.getCustomerId(),
				defaultPaymentSourceDto.getPaymentSource());

		if (accountDetails == null) {
			ExternalPaymentCard externalPaymentCard = externalCardsRepo
					.findByCardNumberAndCustomerId(defaultPaymentSourceDto.getPaymentSource(),
							accountView.getCustomerId())
					.orElseThrow(() -> new BusinessException("404", "Payment Source Invalid"));

			if (defaultPaymentSourceDto.getCardName() != null) {
				externalPaymentCard.setCardName(defaultPaymentSourceDto.getCardName());
				externalPaymentCard.setUpdatedBy("SYSTEM");
				externalPaymentCard.setUpdatedDt(new Date());
				externalCardsRepo.save(externalPaymentCard);
			}
		}
	}

}
