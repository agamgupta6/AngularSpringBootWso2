package com.no.mob.account.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.no.mob.account.model.CardType;
import com.no.mob.account.model.Status;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="TB_VCARD_DETAILS")
@Getter
@Setter
public class VirtualCardDetails implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@SequenceGenerator(name="seq",sequenceName="vcard_details_vcard_id_seq", schema="acct", allocationSize = 1)
	@GeneratedValue(generator="seq",strategy=GenerationType.SEQUENCE)
	@Column(name="VCARD_ID", columnDefinition = "NUMERIC(12,0)")
	private Long vCardId;
	@Column(name="VCARD_NO")	
	private String vCardNo;
	@Column(name="CUSTOMER_ID", columnDefinition = "NUMERIC(12,0)")	
	private Long customerId;
	@Column(name="CARD_ISSUE_TS")	
	private Date cardIssueTs;
	@Column(name="DISPLAY_NM")	
	private String displayNm;
	@Column(name="EXPIRY_DT")	
	private Date expiryDt;
	@Column(name="ISSUER_NM")	
	private CardType issuerNm;
	@Column(name="ACTIVE_IN")	
	private Status activeIn;
	@Column(name="CARD_CVV")
	private int cardCVV;

}
