package com.no.mob.account.model;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class PaymentTransferRequestDto {

	private long accountId;
	private BigDecimal amount;
	private long senderId;
	private String countryCode;
	private String transactionTxt;
	private long receiverId;
	
}
