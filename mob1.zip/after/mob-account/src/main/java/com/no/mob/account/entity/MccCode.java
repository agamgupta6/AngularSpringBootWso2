package com.no.mob.account.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

import lombok.Data;

@Data
@Entity
@Immutable
@Table(name = "vw_mcc_details")
public class MccCode {

	@Id
	@Column(name="ID", columnDefinition = "NUMERIC(8,0)")
	private int id;
	
	@Column(name="MCC_CD", columnDefinition = "NUMERIC(12,0")
	private long mccCd;
	
	@Column(name="CATEGORY_TYPE")
	private String categoryType;
}
