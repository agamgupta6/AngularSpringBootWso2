package com.no.mob.account.repo;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.no.mob.account.entity.MccCode;

public interface MccCodeRepo extends CrudRepository<MccCode, Long>{
	
	@Query(value = "select * from acct.vw_mcc_details mcc", nativeQuery=true)
	public List<MccCode> fetchMccCodes();

}
