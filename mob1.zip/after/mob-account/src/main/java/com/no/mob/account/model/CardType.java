package com.no.mob.account.model;

public enum CardType {
VISA;
}
