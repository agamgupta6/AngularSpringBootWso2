package com.no.mob.account.service;

import java.math.BigDecimal;
import java.security.GeneralSecurityException;
import java.security.Key;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.no.mob.account.common.BusinessException;
import com.no.mob.account.converter.AccountResponseConverter;
import com.no.mob.account.entity.Account;
import com.no.mob.account.entity.AccountView;
import com.no.mob.account.entity.DefaultPaymentSource;
import com.no.mob.account.entity.ExternalPaymentCard;
import com.no.mob.account.entity.ProductConfiguration;
import com.no.mob.account.entity.VirtualCardDetails;
import com.no.mob.account.model.AccountDetailsResponseDtoResult;
import com.no.mob.account.model.AccountRequestDto;
import com.no.mob.account.model.CreditRequestDto;
import com.no.mob.account.model.ExternalCardsDto;
import com.no.mob.account.model.PayeeAccountDetailsDtoResult;
import com.no.mob.account.model.PaymentAmountRequestDto;
import com.no.mob.account.model.PaymentSourceRequestDto;
import com.no.mob.account.model.PaymentTransferRequestDto;
import com.no.mob.account.model.VCardDetailsDTO;
import com.no.mob.account.repo.AccountRepo;
import com.no.mob.account.repo.AccountViewRepo;
import com.no.mob.account.repo.DefaultPaymentSourceRepo;
import com.no.mob.account.repo.ExternalCardRepo;
import com.no.mob.account.repo.ProductConfigurationRepo;
import com.no.mob.account.repo.VirtualCardRepo;
import com.no.mob.account.utils.AccountHelper;
import com.no.mob.account.utils.AccountNumbergenerationService;
import com.no.mob.account.utils.CurrencyConverter;
import com.no.mob.account.utils.VirtualCardHelper;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AccountServiceImpl implements AccountService {

	private static final String ACCOUNT_DOES_NOT_EXIST = "Account does not exist";
	private static final String CUSTOMER_NOT_FOUND = "Customer not found.!";
	private static final int ACTIVE_STATUS = 1;
	private static final byte[] keyValue = new byte[] { 'T', 'h', 'e', 'B', 'e', 's', 't', 'S', 'e', 'c', 'r', 'e', 't',
			'K', 'e', 'y' };
	private static final String AES = "aes";

	@Autowired
	AccountRepo accountDetailRepo;

	@Autowired
	private AccountViewRepo accountViewRepo;

	@Autowired
	private VirtualCardRepo virtualCardRepo;

	@Autowired
	AccountNumbergenerationService accountNumberGenerationService;

	@Autowired
	private AccountHelper accountHelper;

	@Autowired
	private ExternalCardRepo externalCardRepo;

	@Autowired
	private CurrencyConverter currencyConverter;

	@Autowired
	private ProductConfigurationRepo productConfigurationRepo;
	
	@Autowired
	private DefaultPaymentSourceRepo defaultPaymentSourceRepo;

	@Value("${account.iban.checkdigit}")
	private String ibanCheckdigit;

	@Value("${account.creation.conversion.flag:false}")
	private boolean createConversionFlag;

	@Value("${account.bank.identifier.number}")
	private String bankIdentifierNumber;
	@Value("${account.bank.MII.digit}")
	private String visaCardType;
	@Value("${mob.gift.offer.eligible}")
	private boolean mobgiftOfferEligible;
	@Value("${mob.gift.balance}")
	private BigDecimal mobGiftBalance;
	@Value("${mob.default.balance}")
	private BigDecimal mobDefaultBalance;
	@Value("${credit.account.uri}")
	private String creditAccountUri = null;
	@Value("${mob.country.code}")
	private String mobCountryCode;
	@Value("${mob.payment.transaction.uri}")
	private String paymentTransactionUri;
	@Value("${mob.payment.source.uri}")
	private String paymentSourceUri;
	@Value("${customer.concent.uri}")
	private String customerConcentUri;

	@Override
	public void createAccount(AccountRequestDto accountRequestDto, String accessToken) {
		String bankIdentifier = null;
		String cardNum = null;
		AccountView accountView = accountViewRepo.findByMobileNo(accountRequestDto.getMobileNumber())
				.orElseThrow(() -> new BusinessException("422", CUSTOMER_NOT_FOUND));
		if (accountDetailRepo.findByCustomerId(accountView.getCustomerId()).isPresent()) {
			throw new BusinessException("409", "Account already exists.");
		}
		Account accountDetailEntity = new Account();
		accountDetailEntity.setCustomerId(accountView.getCustomerId());
		accountDetailEntity.setIsActive('Y');
		accountDetailEntity.setCreatedDt(new Date());
		accountDetailEntity.setBalance(BigDecimal.ZERO);
		try {
			accountDetailEntity.setQrCode(createQrCode(accountRequestDto.getMobileNumber()).replaceAll("/", "a"));
		} catch (Exception e) {
			log.error("Exception occured while generating qr code");
		}
		accountDetailEntity = accountDetailRepo.save(accountDetailEntity);
		ProductConfiguration pConfig = productConfigurationRepo.fetchProductConfig();
		if (null != pConfig) {
			bankIdentifier = pConfig.getAccountNo().toString();
			cardNum = pConfig.getCardNo().toString();
			accountDetailEntity.setProductCd(pConfig.getProductCd());
		}
		String optimizedAccount = String.format("%6s", accountDetailEntity.getAccountId()).replace(' ', '0');
		String accntNum = accountNumberGenerationService.getAccountNumber(bankIdentifier + optimizedAccount);
		accountDetailEntity.setAccountNo(accntNum);
		String ibanNum = accountRequestDto.getCountryCode() + ibanCheckdigit + accntNum;
		accountDetailEntity.setIbanNo(ibanNum);
		accountDetailRepo.save(accountDetailEntity);
		log.debug("<><><> after second save <><><><>" + accountDetailEntity.getAccountId());

		String vCardNum = cardNum + accntNum.substring(3);
		vCardNum = accountNumberGenerationService.getAccountNumber(vCardNum);

		virtualCardRepo.save(VirtualCardHelper.createCardDetails(accountDetailEntity, vCardNum));

		saveFabbyBankAccount(accountView, accessToken, accountRequestDto.getMobileNumber());

		BigDecimal amountToCredit = mobDefaultBalance;
		if (createConversionFlag) {
			if (accountRequestDto.getIsKycEnabled()) {
				amountToCredit = mobGiftBalance;

				if (checkCurrencyCheckRequired(accountRequestDto.getCountryCode(), mobCountryCode)) {
					amountToCredit = currencyConverter.convertRequestedAmount(mobGiftBalance, mobCountryCode,
							accountRequestDto.getCountryCode());
				}
			} else {
				if (checkCurrencyCheckRequired(accountRequestDto.getCountryCode(), mobCountryCode)) {
					amountToCredit = currencyConverter.convertRequestedAmount(mobDefaultBalance, mobCountryCode,
							accountRequestDto.getCountryCode());
				}

			}
		}
		log.info("Amount to credit During creation -->" + amountToCredit);

		PaymentTransferRequestDto paymentTransferRequestDto = new PaymentTransferRequestDto();

		CreditRequestDto creditRequestDto = new CreditRequestDto();
		creditRequestDto.setAccountNo(accountDetailEntity.getAccountNo());

		accountHelper.creditBalance(creditAccountUri, accountRequestDto.getMobileNumber(), accessToken,
				creditRequestDto, amountToCredit);
		// savetransaction
		paymentTransferRequestDto.setAmount(amountToCredit);
		paymentTransferRequestDto.setCountryCode(accountRequestDto.getCountryCode());
		paymentTransferRequestDto.setAccountId(accountDetailEntity.getAccountId());
		paymentTransferRequestDto.setSenderId(9999);
		paymentTransferRequestDto.setTransactionTxt("Initial Deposit");
		paymentTransferRequestDto.setReceiverId(accountView.getCustomerId());
		accountHelper.saveTransaction(paymentTransactionUri, accountRequestDto.getMobileNumber(), accessToken,
				paymentTransferRequestDto);
		accountHelper.createCustomerConcent(customerConcentUri, accountRequestDto.getMobileNumber(), accessToken);
	}

	public AccountDetailsResponseDtoResult fetchAccountCardDetails(String mobileNumber) {
		AccountView accountView = accountViewRepo.findByMobileNo(mobileNumber)
				.orElseThrow(() -> new BusinessException("420", CUSTOMER_NOT_FOUND));
		if (validateEmailVerification(accountView)) {
			throw new BusinessException("421", "Email not verified");
		}
		Account account = accountDetailRepo.findByVirtualCardDetailsCustomerId(accountView.getCustomerId())
				.orElseThrow(() -> new BusinessException("422", ACCOUNT_DOES_NOT_EXIST));

		log.info("Customer Id ={}", accountView.getCustomerId());
		List<ExternalPaymentCard> externalPaymentCards = externalCardRepo.fetchCardDetailsByCustomerIdAndActiveIn(accountView.getCustomerId(), 'Y');

		List<ExternalCardsDto> externalCardsDtos = externalPaymentCards.stream().map(card -> {
			List<DefaultPaymentSource> defaultPaymentSource = defaultPaymentSourceRepo.findByCustomerIdAndPaymentSource(account.getCustomerId(), card.getCardNumber());
			List<String> preferences = defaultPaymentSource.stream().filter(x-> x.getIsDefault()=='Y').map(source -> source.getMccCode()).collect(Collectors.toList());
			return new ExternalCardsDto(card.getCardNumber(), card.getCardName(),
					card.getValidTo(), null, card.getCardScheme(), preferences);
		}).collect(Collectors.toList());

		return AccountResponseConverter.formAccountDetailsResponse(account, accountView, mobileNumber, externalCardsDtos);
	}

	private boolean validateEmailVerification(AccountView accountView) {
		return ACTIVE_STATUS != accountView.getStatusId();
	}

	private String createQrCode(String mobileNumber) throws GeneralSecurityException {

		Key key = new SecretKeySpec(keyValue, AES);
		Cipher c = Cipher.getInstance(AES);
		c.init(Cipher.ENCRYPT_MODE, key);
		byte[] encVal = c.doFinal(mobileNumber.getBytes());
		return Base64.getEncoder().encodeToString(encVal);
	}

	@Override
	public BigDecimal updateBalance(String mobileNumber, PaymentAmountRequestDto paymentAmountRequestDto) {
		Account targetPaymentDetails = null;
		if (null != paymentAmountRequestDto.getAccountNo() || "" != paymentAmountRequestDto.getAccountNo()) {
			targetPaymentDetails = accountDetailRepo.findByAccountNo(paymentAmountRequestDto.getAccountNo())
					.orElseThrow(() -> new BusinessException("423", ACCOUNT_DOES_NOT_EXIST));
		} else {
			AccountView accountView = accountViewRepo.findByMobileNo(mobileNumber)
					.orElseThrow(() -> new BusinessException("430", "Account doesnot exist for given phone number"));
			targetPaymentDetails = accountDetailRepo.findByCustomerId(accountView.getCustomerId())
					.orElseThrow(() -> new BusinessException("423", ACCOUNT_DOES_NOT_EXIST));
		}
		targetPaymentDetails.setBalance(targetPaymentDetails.getBalance().add(paymentAmountRequestDto.getAmount()));
		accountDetailRepo.save(targetPaymentDetails);
		return targetPaymentDetails.getBalance().add(paymentAmountRequestDto.getAmount());
	}

	@Override
	public BigDecimal debitBalance(String mobileNumber, PaymentAmountRequestDto paymentAmountRequestDto) {
		Account targetPaymentDetails = null;
		if (null != paymentAmountRequestDto.getAccountNo() || "" != paymentAmountRequestDto.getAccountNo()) {
			targetPaymentDetails = accountDetailRepo.findByAccountNo(paymentAmountRequestDto.getAccountNo())
					.orElseThrow(() -> new BusinessException("424", ACCOUNT_DOES_NOT_EXIST));
		} else {
			AccountView accountView = accountViewRepo.findByMobileNo(mobileNumber)
					.orElseThrow(() -> new BusinessException("430", "Account doesnot exist for given phone number"));
			targetPaymentDetails = accountDetailRepo.findByCustomerId(accountView.getCustomerId())
					.orElseThrow(() -> new BusinessException("424", ACCOUNT_DOES_NOT_EXIST));
		}
		log.info("in service debit balance " + targetPaymentDetails.toString());
		if (paymentAmountRequestDto.getAmount().compareTo(targetPaymentDetails.getBalance()) > 0) {
			throw new BusinessException("426", "Insufficeint Funds");
		}
		targetPaymentDetails
				.setBalance(targetPaymentDetails.getBalance().subtract(paymentAmountRequestDto.getAmount()));
		accountDetailRepo.save(targetPaymentDetails);
		log.info("in service  return " + targetPaymentDetails.getAccountId());
		return targetPaymentDetails.getBalance().subtract(paymentAmountRequestDto.getAmount());

	}

	@Override
	public PayeeAccountDetailsDtoResult fetchPayeeAccountDetails(String payeeNumber) {
		PayeeAccountDetailsDtoResult payeeAccountDetail = new PayeeAccountDetailsDtoResult();

		AccountView accountView = accountViewRepo.findByMobileNo(payeeNumber).orElse(null);

		if (null != accountView) {
			accountDetailRepo.findByCustomerId(accountView.getCustomerId()).ifPresent(payeeAcct -> {
				payeeAccountDetail.setAccountNumber(payeeAcct.getAccountNo());
				payeeAccountDetail.setSwiftCode(payeeAcct.getIbanNo());
				payeeAccountDetail.setCountryCode(accountView.getCountryCode());
				payeeAccountDetail.setMobileNumber(payeeNumber);
				payeeAccountDetail.setPayeeName(accountView.getFirstName());
				payeeAccountDetail.setQrCode(payeeAcct.getQrCode());
			});
		}

		return payeeAccountDetail;
	}

	@Override
	public PayeeAccountDetailsDtoResult fetchAccountDEtailsByQrCode(String qrCode, String mobileNo) {
		Account account = accountDetailRepo.findByQrCode(qrCode.trim())
				.orElseThrow(() -> new BusinessException("425", "QR details Not found"));
		AccountView accountView = accountViewRepo.findByCustomerId(account.getCustomerId())
				.orElseThrow(() -> new BusinessException("420", CUSTOMER_NOT_FOUND));

		PayeeAccountDetailsDtoResult payeeAccountDetail = new PayeeAccountDetailsDtoResult();
		payeeAccountDetail.setAccountNumber(account.getAccountNo());
		payeeAccountDetail.setSwiftCode(account.getIbanNo());
		payeeAccountDetail.setCountryCode(accountView.getCountryCode());
		payeeAccountDetail.setMobileNumber(accountView.getMobileNo());
		payeeAccountDetail.setPayeeName(accountView.getFirstName());
		payeeAccountDetail.setQrCode(account.getQrCode());
		return payeeAccountDetail;
	}

	@Override
	public void validateVirtualCard(VCardDetailsDTO vCardDetails) {
		log.debug("card number: " + vCardDetails.getCardNo());
		Account acnt = accountDetailRepo.findByVirtualCardDetailsVCardNo(vCardDetails.getCardNo())
				.orElseThrow(() -> new BusinessException("406", "Cant find card with given number"));
		VirtualCardDetails virtualCardDetails = acnt.getVirtualCardDetails();
		if (virtualCardDetails.getCardCVV() != vCardDetails.getCvv()) {
			throw new BusinessException("406", "Invalid cvv");
		}

		if (virtualCardDetails.getExpiryDt().before(new Date())) {
			throw new BusinessException("406", "Virtual Card Expired");
		}
	}

	private boolean checkCurrencyCheckRequired(String sourceCountryCode, String countryCd) {
		return !sourceCountryCode.equals(countryCd);
	}

	private void saveFabbyBankAccount(AccountView accountView, String accessToken, String mobileNumber) {
		PaymentSourceRequestDto paymentSource = new PaymentSourceRequestDto();
		paymentSource.setCardNumber(Long.valueOf("4492557101000136"));
		paymentSource.setCustomerId(accountView.getCustomerId());
		accountHelper.savePaymentSource(paymentSourceUri, mobileNumber, accessToken, paymentSource);
	}

}
