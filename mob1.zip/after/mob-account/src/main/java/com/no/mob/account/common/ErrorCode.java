package com.no.mob.account.common;


public interface ErrorCode {

	
	String getCode();
	
	String getErrorKey();
}
