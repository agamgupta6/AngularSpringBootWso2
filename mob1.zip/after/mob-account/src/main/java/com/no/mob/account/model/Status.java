package com.no.mob.account.model;

public enum Status {
	ACTIVE(1), DEACTIVATED(0);
	
	private int value;

	private Status(int value) {
		this.value = value;
	}
	
	public int getStatus(){
		return this.value;
	}
}
