package com.no.mob.account.converter;

import java.text.SimpleDateFormat;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import com.no.mob.account.entity.Account;
import com.no.mob.account.entity.AccountView;
import com.no.mob.account.entity.VirtualCardDetails;
import com.no.mob.account.model.AccountDetailsResponseDtoResult;
import com.no.mob.account.model.ExternalCardsDto;

public class AccountResponseConverter {

	private static Logger log = LoggerFactory.getLogger(AccountResponseConverter.class);

	@Value("${mob.response.date.format:dd/mm/yyy}")
	private String dateFormat;

	@Value("${mob.bank.name}")
	private static String bankName;
	
	public static AccountDetailsResponseDtoResult formAccountDetailsResponse(Account account, AccountView accountView,
			String mobileNumber, List<ExternalCardsDto> externalCardsDtos) {
		log.info("Generating Account Response for mob No : {}, cardDetails: {}", mobileNumber,
				externalCardsDtos.toString());
		VirtualCardDetails virtualCardDetails = account.getVirtualCardDetails();
		AccountDetailsResponseDtoResult result = new AccountDetailsResponseDtoResult();
		result.setAccountNumber(account.getAccountNo());
		result.setBalanceAmount(account.getBalance().toString());
		result.setCountryCode(accountView.getCountryCode());
		result.setQrCode(account.getQrCode());
		result.setBankName(bankName);
		result.setCardNumber(virtualCardDetails.getVCardNo());
		result.setCardScheme(virtualCardDetails.getIssuerNm().toString());
		result.setMobileNo(mobileNumber);
		result.setCardHolderName(accountView.getFirstName() + " " + accountView.getLastName());
		result.setImgUrl(accountView.getCustomerImg());
		if (null != virtualCardDetails.getCardIssueTs()) {
			result.setValidFrom(
					new SimpleDateFormat("dd/MM/yyyy").format(virtualCardDetails.getCardIssueTs().getTime()));
		}
		if (null != virtualCardDetails.getExpiryDt()) {
			result.setValidTo(new SimpleDateFormat("dd/MM/yyyy").format(virtualCardDetails.getExpiryDt().getTime()));
		}
		result.setCardCVV(virtualCardDetails.getCardCVV());

		
		log.info("External Cards Result: {}", externalCardsDtos.toString());
		result.setExternalCardsDto(externalCardsDtos);
		return result;
	}

}
