package com.no.mob.account.repo;

import org.springframework.data.repository.CrudRepository;

import com.no.mob.account.entity.VirtualCardDetails;

public interface VirtualCardRepo extends CrudRepository<VirtualCardDetails, Long> {

	public VirtualCardDetails findByCustomerId(long l);

	public VirtualCardDetails findByVCardNo(String cardNo);

}
