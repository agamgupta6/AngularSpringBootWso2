package com.no.mob.account.utils;

import java.util.Calendar;
import java.util.Date;
import java.util.Random;

import com.no.mob.account.entity.Account;
import com.no.mob.account.entity.VirtualCardDetails;
import com.no.mob.account.model.CardType;
import com.no.mob.account.model.Status;


public class VirtualCardHelper {
	
	private static final Random random = new Random();
	
	private VirtualCardHelper() {
	    throw new IllegalAccessError("Utility class");
	  }

	
	public static VirtualCardDetails createCardDetails(Account account, String vCardNummber) {
		Date issueDt = new Date();
		VirtualCardDetails virtualCardDetails = new VirtualCardDetails();
		virtualCardDetails.setCustomerId(account.getCustomerId());		
		virtualCardDetails.setVCardNo(vCardNummber);
		virtualCardDetails.setCardIssueTs(issueDt);
		virtualCardDetails.setActiveIn(Status.ACTIVE);
		virtualCardDetails.setIssuerNm(CardType.VISA);
		virtualCardDetails.setExpiryDt(calculateExpiryDate(issueDt));
		virtualCardDetails.setCardCVV(generateCardCVV());
		return virtualCardDetails;
	}
	
	public static Date calculateExpiryDate(Date issueDt) {
		Calendar expDate = Calendar.getInstance();
		expDate.setTime(issueDt);
		expDate.add(Calendar.YEAR, 5);
		return expDate.getTime();
	}
	
	public static int generateCardCVV() {
		return random.nextInt(900) + 100;
		
	}	
	

}
