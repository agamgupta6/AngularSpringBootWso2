package com.no.mob.account.service;

import java.util.Date;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.no.mob.account.common.BusinessException;
import com.no.mob.account.entity.AccountView;
import com.no.mob.account.entity.ExternalPaymentCard;
import com.no.mob.account.model.DefaultPaymentSourceDto;
import com.no.mob.account.model.ExternalCardsDto;
import com.no.mob.account.repo.AccountViewRepo;
import com.no.mob.account.repo.ExternalCardRepo;

@Service
public class CardServiceImpl implements CardService {

	@Autowired
	private ExternalCardRepo cardRepo;

	@Autowired
	private AccountViewRepo accountViewRepo;

	@Autowired
	private PaymentSourceService paymentSourceService;

	private Logger log = LoggerFactory.getLogger(this.getClass());

	@Override
	@Transactional
	public void addExternalCard(ExternalCardsDto externalCardsDto, String mobileNo) {
		
		log.info("add external card with external card dto {}", externalCardsDto.toString());

		ExternalPaymentCard externalPaymentCard = new ExternalPaymentCard();
		BeanUtils.copyProperties(externalCardsDto, externalPaymentCard);

		AccountView accountView = accountViewRepo.findByMobileNo(mobileNo)
				.orElseThrow(() -> new BusinessException("404", "Customer does not exist"));

		cardRepo.findByCardNumber(externalCardsDto.getCardNumber()).ifPresent((card) -> {
			if (card.getActiveIn() == 'Y') {
				throw new BusinessException("302", "Card Already Exists..!");
			}
		});
		
		if(cardRepo.findByCustomerId(accountView.getCustomerId()).size() >= 10){
			throw new BusinessException("482", "Cannot add More than 10 Cards..!");
		}

		externalPaymentCard.setCustomerId(accountView.getCustomerId());
		externalPaymentCard.setActiveIn('Y');

		externalPaymentCard.setValidTo(externalCardsDto.getValidTo()); 
		
		externalPaymentCard.setCreatedBy("SYSTEM");
		externalPaymentCard.setCreatedDt(new Date());
		cardRepo.save(externalPaymentCard);

		DefaultPaymentSourceDto defaultPaymentSourceDto = new DefaultPaymentSourceDto();
		defaultPaymentSourceDto.setPaymentSource(externalCardsDto.getCardNumber());
		defaultPaymentSourceDto.setPreferences(externalCardsDto.getPreferences());
		paymentSourceService.makeDefaultPaymentSource(defaultPaymentSourceDto, mobileNo);

	}

	@Override
	public void deleteCard(String cardNumber, String mobileNo) {

		accountViewRepo.findByMobileNo(mobileNo)
				.orElseThrow(() -> new BusinessException("404", "Customer does not exist"));

		ExternalPaymentCard externalPaymentCard = cardRepo.findByCardNumber(cardNumber)
				.orElseThrow(() -> new BusinessException("404", "Card Not Found"));
		externalPaymentCard.setActiveIn('N');
		cardRepo.save(externalPaymentCard);
	}

}
