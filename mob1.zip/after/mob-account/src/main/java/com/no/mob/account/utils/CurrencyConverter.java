package com.no.mob.account.utils;

import java.math.BigDecimal;
import java.util.Currency;
import java.util.Locale;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class CurrencyConverter {
	
	private Logger log = LoggerFactory.getLogger(this.getClass());

	@Value("${currency.conversion.url}")
	private String url ;

	public BigDecimal convertRequestedAmount(BigDecimal amount, String countryCode, String targetCountryCode) {
			log.info("Entering currency conversion api with amount {} and country Codes {} and {}", amount, countryCode, targetCountryCode);
			String sourceCurrencyCd = CurrencyConverter.getCurrencyCode(countryCode);
			String targetCurrencyCd = CurrencyConverter.getCurrencyCode(targetCountryCode);
			String updatedUrl = url + sourceCurrencyCd + "_" + targetCurrencyCd;
			RestTemplate restTemplate = new RestTemplate(); 
			String myResponse = restTemplate.getForObject(updatedUrl, String.class);
			log.info("Currency conversion response = {}", myResponse);
			
			BigDecimal convertedAmount =new BigDecimal( new JSONObject(myResponse).getJSONObject("results")
					.getJSONObject(sourceCurrencyCd + "_" + targetCurrencyCd).get("val").toString());
			return convertedAmount.multiply(amount);
	}
	
	public static String getCurrencyCode(String countryCode) {
		return Currency.getInstance(new Locale("", countryCode)).getCurrencyCode();
	}
}
