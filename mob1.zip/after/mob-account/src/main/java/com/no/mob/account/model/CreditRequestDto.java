package com.no.mob.account.model;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CreditRequestDto {
	private BigDecimal amount;
	private String currency;
	private String accountNo;
}
