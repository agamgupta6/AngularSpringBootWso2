/**
 * 
 */
package com.no.mob.account.common;

import lombok.Getter;
import lombok.Setter;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * Generic response structure
 *
 */
@Getter
@Setter
@JsonInclude(value = Include.NON_NULL)
public class GenericErrorResponse extends GenericResponse {
	private static final String GENERIC_ERROR_MESSAGE = "Oops! Something went wrong";

	public GenericErrorResponse() {
		super.setResponseInfo(new ResponseInfo());
		super.getResponseInfo().setResponseCode("1000");
		super.getResponseInfo().setResponseMessage(GENERIC_ERROR_MESSAGE);
	}

}
