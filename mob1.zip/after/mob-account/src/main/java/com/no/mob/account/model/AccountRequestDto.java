package com.no.mob.account.model;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * AccountRequestDto
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2017-12-13T05:36:31.653Z")

public class AccountRequestDto   {
  @JsonProperty("mobile_number")
  private String mobileNumber = null;

  @JsonProperty("country_code")
  private String countryCode = null;
  
  @JsonProperty("is_kyc_enabled")
  private boolean isKycEnabled;

  public AccountRequestDto customerId(String mobileNumber) {
    this.mobileNumber = mobileNumber;
    return this;
  }
  
  @ApiModelProperty(value = "")
  public boolean getIsKycEnabled(){
	  return isKycEnabled;
  }
  
  public void setIsKycEnabled(boolean isKycEnabled){
	  this.isKycEnabled = isKycEnabled;
  }

   /**
   * Get customerId
   * @return customerId
  **/
  @ApiModelProperty(value = "")


  public String getMobileNumber() {
    return mobileNumber;
  }

  public void setMobileNumber(String mobileNumber) {
    this.mobileNumber = mobileNumber;
  }

  public AccountRequestDto countryCode(String countryCode) {
    this.countryCode = countryCode;
    return this;
  }

   /**
   * Get countryCode
   * @return countryCode
  **/
  @ApiModelProperty(value = "")


  public String getCountryCode() {
    return countryCode;
  }

  public void setCountryCode(String countryCode) {
    this.countryCode = countryCode;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AccountRequestDto accountRequestDto = (AccountRequestDto) o;
    return Objects.equals(this.mobileNumber, accountRequestDto.mobileNumber) &&
        Objects.equals(this.countryCode, accountRequestDto.countryCode);
  }

  @Override
  public int hashCode() {
    return Objects.hash(mobileNumber, countryCode);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AccountRequestDto {\n");
    
    sb.append("    customerId: ").append(toIndentedString(mobileNumber)).append("\n");
    sb.append("    countryCode: ").append(toIndentedString(countryCode)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

