package com.no.mob.account.utils;

public interface AccountNumbergenerationService {
	public String getAccountNumber(String accountId);
}