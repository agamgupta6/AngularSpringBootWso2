package com.no.mob.account.controller;

import java.math.BigDecimal;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.no.mob.account.common.BusinessException;
import com.no.mob.account.common.ErrorDetails;
import com.no.mob.account.common.GenericResponse;
import com.no.mob.account.common.ResponseConverter;
import com.no.mob.account.model.AccountDetailsResponseDtoResult;
import com.no.mob.account.model.AccountRequestDto;
import com.no.mob.account.model.PayeeAccountDetailsDtoResult;
import com.no.mob.account.model.PaymentAmountRequestDto;
import com.no.mob.account.model.VCardDetailsDTO;
import com.no.mob.account.service.AccountService;

import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class AccountApiController implements AccountApi {

	@Autowired
	private AccountService accountService;

	public ResponseEntity<GenericResponse> accountCreatePost(
			@ApiParam(value = "customer details", required = true) @Valid @RequestBody AccountRequestDto accountRequestDto,
			@ApiParam(value = "") @RequestHeader(value = "mobile_number", required = true) String mobileNumber,
			@ApiParam(value = "") @RequestHeader(value = "Authorization", required = false) String accessToken) {

		accountService.createAccount(accountRequestDto, accessToken);
		GenericResponse responseInfo = new GenericResponse();
		return new ResponseEntity<>(responseInfo, HttpStatus.OK);
	}

	public ResponseEntity<GenericResponse> accountGetDetailsGet(
			@ApiParam(value = "") @RequestHeader(value = "mobile_number", required = true) String mobileNumber,
			@ApiParam(value = "") @RequestHeader(value = "Authorization", required = false) String accessToken) {
		GenericResponse response = new GenericResponse();
		AccountDetailsResponseDtoResult accountDetailsResponseDto = accountService
				.fetchAccountCardDetails(mobileNumber);
		response.setResult(accountDetailsResponseDto);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<GenericResponse> updateBalance(
			@ApiParam(value = "") @RequestHeader(value = "mobile_number", required = true) String mobileNumber,
			@ApiParam(value = "") @RequestHeader(value = "Authorization", required = false) String accessToken,
			@RequestBody PaymentAmountRequestDto paymentAmountRequestDto) {
		GenericResponse response = new GenericResponse();
		BigDecimal balance = accountService.updateBalance(mobileNumber, paymentAmountRequestDto);
		response.setResult(balance);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<GenericResponse> debitBalance(
			@ApiParam(value = "") @RequestHeader(value = "mobile_number", required = true) String mobileNumber,
			@ApiParam(value = "") @RequestHeader(value = "Authorization", required = false) String accessToken,
			@RequestBody PaymentAmountRequestDto paymentAmountRequestDto) {
		log.info("test " + paymentAmountRequestDto.getAccountNo());
		GenericResponse response = new GenericResponse();
		BigDecimal balance = accountService.debitBalance(mobileNumber, paymentAmountRequestDto);
		response.setResult(balance);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	public ResponseEntity<GenericResponse> accountGetAccountDetailsPayeeNumberPost(
			@ApiParam(value = "", required = true) @PathVariable("payee_number") String payeeNumber,
			@ApiParam(value = "") @RequestHeader(value = "mobile_number", required = false) String mobileNumber,
			@ApiParam(value = "") @RequestHeader(value = "access_token", required = false) String accessToken) {

		GenericResponse response = new GenericResponse();
		PayeeAccountDetailsDtoResult payeeAccountDetailsDto = accountService.fetchPayeeAccountDetails(payeeNumber);
		response.setResult(payeeAccountDetailsDto);
		return new ResponseEntity<>(response, HttpStatus.OK);

	}

	@GetMapping(value = "/getAccountDetailsForQrCode/{qrCode}", produces = { "application/json" })
	public ResponseEntity<GenericResponse> accountGetAccountDetailsByQrCode(
			@ApiParam(value = "", required = true) @PathVariable("qrCode") String qrCode,
			@ApiParam(value = "") @RequestHeader(value = "mobile_number", required = false) String mobileNumber,
			@ApiParam(value = "") @RequestHeader(value = "access_token", required = false) String accessToken) {
		GenericResponse response = new GenericResponse();
		PayeeAccountDetailsDtoResult payeeAccountDetailsDto = accountService.fetchAccountDEtailsByQrCode(qrCode,
				mobileNumber);
		response.setResult(payeeAccountDetailsDto);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<GenericResponse> validateVirtualCard(
			@ApiParam(value = "") @RequestHeader(value = "mobile_number", required = true) String mobileNumber,
			@ApiParam(value = "") @RequestHeader(value = "Authorization", required = false) String accessToken,
			@RequestBody VCardDetailsDTO vCardDetails) {
		accountService.validateVirtualCard(vCardDetails);
		return new ResponseEntity<>(new GenericResponse(), HttpStatus.OK);
	}

	
}
