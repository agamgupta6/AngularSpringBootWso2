package com.no.mob.account.repo;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.no.mob.account.entity.ProductConfiguration;

public interface ProductConfigurationRepo extends CrudRepository<ProductConfiguration, Long> {
	
	@Query(value = "Select * from acct.tb_product_configuration", nativeQuery = true)
	public ProductConfiguration fetchProductConfig();

}
