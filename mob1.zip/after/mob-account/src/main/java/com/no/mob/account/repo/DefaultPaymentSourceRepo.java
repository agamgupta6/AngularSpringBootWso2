package com.no.mob.account.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.no.mob.account.entity.DefaultPaymentSource;

public interface DefaultPaymentSourceRepo extends CrudRepository<DefaultPaymentSource, Long> {

	List<DefaultPaymentSource> findByCustomerIdAndMccCode(Long customerId, String category);

	List<DefaultPaymentSource> findByCustomerIdAndPaymentSource(Long customerId, String paymentSource);
	
}
