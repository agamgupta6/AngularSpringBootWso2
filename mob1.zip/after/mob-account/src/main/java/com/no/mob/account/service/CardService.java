package com.no.mob.account.service;

import com.no.mob.account.model.ExternalCardsDto;

public interface CardService {
	
	public void addExternalCard(ExternalCardsDto externalCardsDto, String mobileNo);

	public void deleteCard(String cardNumber, String mobileNo);

}
