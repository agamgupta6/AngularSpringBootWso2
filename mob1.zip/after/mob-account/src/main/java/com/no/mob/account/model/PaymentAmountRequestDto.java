package com.no.mob.account.model;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class PaymentAmountRequestDto {

	private BigDecimal amount;
	private String accountNo;
}
