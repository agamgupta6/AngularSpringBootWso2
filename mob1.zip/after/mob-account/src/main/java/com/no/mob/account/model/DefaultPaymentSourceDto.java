package com.no.mob.account.model;

import java.util.List;

import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DefaultPaymentSourceDto {
	
	private String paymentSource;
	
	private String cardName;
	
	@NotNull(message = "preferences.invalid")
	private List<String> preferences;
	
	

}
