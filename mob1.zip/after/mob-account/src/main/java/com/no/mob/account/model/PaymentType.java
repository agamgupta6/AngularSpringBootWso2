package com.no.mob.account.model;

public enum PaymentType {
CARD,ACCOUNT;
}
