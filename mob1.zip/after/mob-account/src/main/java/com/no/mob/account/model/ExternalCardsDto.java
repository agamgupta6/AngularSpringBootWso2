package com.no.mob.account.model;

import java.util.List;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ExternalCardsDto {

	@NotEmpty(message="cardNumber.invalid")
	@Size(min=16, max=16, message= "cardNumber.invalid")
	private String cardNumber;
	
	private String cardName;
	
	private String validTo;
	
	private String cvv;
	
	private String cardScheme;
	
	List<String> preferences;
}
