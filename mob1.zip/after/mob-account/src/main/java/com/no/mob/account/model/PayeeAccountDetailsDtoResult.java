package com.no.mob.account.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

/**
 * PayeeAccountDetailsDtoResult
 */

@Getter
@Setter
public class PayeeAccountDetailsDtoResult {
	@JsonProperty("mobileNumber")
	private String mobileNumber = null;

	@JsonProperty("payeeName")
	private String payeeName = null;

	@JsonProperty("countryCode")
	private String countryCode = null;

	@JsonProperty("swiftCode")
	private String swiftCode = null;

	@JsonProperty("accountNumber")
	private String accountNumber = null;
	
	@JsonProperty("qrCode")
	private String qrCode= null;

}
