set client_encoding to 'UTF8';

DROP SCHEMA IF EXISTS account CASCADE;

CREATE SCHEMA acct
    AUTHORIZATION ${db.objects.owner};


-- Sequences

CREATE SEQUENCE acct.account_details_account_id_seq
    INCREMENT 1
    START ${db.account.sequence.start}
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE acct.account_details_account_id_seq
    OWNER TO ${db.objects.owner};

CREATE SEQUENCE acct.vcard_details_vcard_id_seq
    INCREMENT 1
    START ${db.vcard.sequence.start}
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE acct.vcard_details_vcard_id_seq
    OWNER TO ${db.objects.owner};

-- Table: acct.vcard_details

-- DROP TABLE acct.vcard_details;

CREATE TABLE acct.tb_vcard_details
(
    vcard_id numeric(12,0) NOT NULL DEFAULT nextval('acct.vcard_details_vcard_id_seq'::regclass),
    active_in integer,
    card_cvv integer,
    card_issue_ts timestamp without time zone,
    customer_id numeric(12,0),
    display_nm character varying(255) COLLATE pg_catalog."default",
    expiry_dt timestamp without time zone,
    issuer_nm integer,
    vcard_no character varying(255) COLLATE pg_catalog."default",
    CONSTRAINT vcard_details_pkey PRIMARY KEY (vcard_id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE acct.tb_vcard_details
    OWNER to ${db.objects.owner};


-- Table: acct.account_details

-- DROP TABLE acct.account_details;

CREATE TABLE acct.tb_account_details
(
    account_id numeric(12,0) NOT NULL DEFAULT nextval('acct.account_details_account_id_seq'::regclass),
    customer_id numeric(12,0) NOT NULL,
    account_no character varying(255) COLLATE pg_catalog."default",
    balance_am numeric(12,2),
    account_created_ts date,
    iban_no character varying(255) COLLATE pg_catalog."default",
    active_in character(1) COLLATE pg_catalog."default",
    CONSTRAINT account_details_pkey PRIMARY KEY (customer_id, account_id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE acct.tb_account_details
    OWNER to ${db.objects.owner};
	
-- View: acct.accnt_details

-- DROP VIEW acct.accnt_details;

CREATE OR REPLACE VIEW acct.vw_accnt_details AS
 SELECT tb_customer.customer_id,
    tb_customer.mobile_no,
    tb_customer.status_id,
    tb_customer.first_nm,
    tb_customer.COUNTRY_CD,
    tb_dialing_code.currency,
    tb_customer.last_nm,
    tb_customer.PHOTO_URL_TX
   FROM cust.tb_customer join cust.tb_dialing_code on tb_customer.country_cd = tb_dialing_code.country_cd;

ALTER VIEW acct.vw_accnt_details
    OWNER TO ${db.objects.owner};
