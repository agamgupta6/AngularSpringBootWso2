INSERT INTO acct.tb_account_details(
	customer_id, account_no, balance_am, account_created_ts, iban_no, active_in, qr_code)
	VALUES ('9999','86015000004','0.00',current_timestamp,null,'Y',null);