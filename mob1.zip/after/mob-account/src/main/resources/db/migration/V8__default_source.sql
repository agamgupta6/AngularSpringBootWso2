ALTER TABLE acct.tb_account_details ADD IS_DEFAULT character(1) COLLATE pg_catalog."default";

ALTER TABLE acct.TB_EXTERNAL_PAYMENT_CARD ADD IS_DEFAULT character(1) COLLATE pg_catalog."default";

