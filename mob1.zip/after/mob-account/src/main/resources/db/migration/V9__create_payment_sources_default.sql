ALTER TABLE acct.tb_account_details DROP COLUMN IS_DEFAULT;

ALTER TABLE acct.TB_EXTERNAL_PAYMENT_CARD DROP COLUMN IS_DEFAULT;

ALTER TABLE acct.TB_EXTERNAL_PAYMENT_CARD
ADD CONSTRAINT external_card_pkey PRIMARY KEY (PAYMENT_CARD_ID);

CREATE SEQUENCE acct.default_payment_card_seq
    INCREMENT 1
    START ${db.default.card.sequence.start}
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;
    
    ALTER SEQUENCE acct.default_payment_card_seq
    OWNER TO ${db.objects.owner};

CREATE TABLE acct.TB_PAYMENT_SOURCE_DETAILS
(
    ID numeric(12,0) NOT NULL DEFAULT nextval('acct.default_payment_card_seq'::regclass),
    PAYMENT_SOURCE character varying(255) COLLATE pg_catalog."default",
    CUSTOMER_ID numeric(12,0),
    IS_DEFAULT character(1) COLLATE pg_catalog."default",
    MCC_CODE character varying(255) COLLATE pg_catalog."default"
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE acct.TB_PAYMENT_SOURCE_DETAILS
    OWNER to ${db.objects.owner};