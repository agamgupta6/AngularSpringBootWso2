ALTER TABLE acct.tb_account_details
DROP CONSTRAINT account_details_pkey;

ALTER TABLE acct.tb_account_details
ADD CONSTRAINT account_details_pkey PRIMARY KEY (account_id);

