ALTER TABLE acct.tb_account_details ALTER COLUMN balance_am TYPE numeric(12,4);

CREATE SEQUENCE acct.account_interest_details_interest_id_seq
    INCREMENT 1
    START 100000
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

CREATE TABLE acct.tb_account_interest_details
(
	interest_id numeric(12,0) NOT NULL DEFAULT nextval('acct.account_interest_details_interest_id_seq'::regclass),
    account_id numeric(12,0) NOT NULL,
    interest_amount numeric(12,4),
    last_updated_on timestamp with time zone,
    CONSTRAINT account_interest_details_pkey PRIMARY KEY (interest_id)
);

ALTER TABLE acct.tb_account_details ADD product_cd numeric(10,0);

UPDATE acct.tb_account_details SET product_cd=10001;



