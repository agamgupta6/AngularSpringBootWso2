CREATE OR REPLACE VIEW acct.vw_mcc_details AS
select id, mcc_cd, category_type from payment.tb_mcc_code;

ALTER VIEW acct.vw_mcc_details
    OWNER TO ${db.objects.owner};
