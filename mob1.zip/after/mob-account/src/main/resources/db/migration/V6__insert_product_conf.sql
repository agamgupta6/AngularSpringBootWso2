
CREATE SEQUENCE acct.tb_product_id_seq
    INCREMENT 1
    START ${db.acct.product.id.sequence.start}
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE acct.tb_product_id_seq
    OWNER TO ${db.objects.owner};


CREATE TABLE acct.tb_product_configuration
(
    product_cd numeric(10,0) NOT NULL DEFAULT nextval('acct.tb_product_id_seq'::regclass),
    product_nm character varying(255) COLLATE pg_catalog."default",
    currency character varying(8) COLLATE pg_catalog."default",
	country_cd character varying(8) COLLATE pg_catalog."default",
	description character varying(255) COLLATE pg_catalog."default",
	isAllowMultipleAccounts character varying(1) COLLATE pg_catalog."default",
    interest integer,
	interest_in_days integer,
	credited_interest character varying(8) COLLATE pg_catalog."default",
	sync_in_days_count integer,
	isInternationalTransferAllowed integer,
	product_fee integer,
	fee_deducted integer,
	account_no numeric(12,0),
	card_no numeric(12,0),
	card_type character varying(8) COLLATE pg_catalog."default",
    PRIMARY KEY (product_cd)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE acct.tb_product_configuration
    OWNER to ${db.objects.owner};

INSERT INTO acct.tb_product_configuration(
  product_cd, product_nm, currency, country_cd, description, isAllowMultipleAccounts, interest, interest_in_days, credited_interest, sync_in_days_count, isInternationalTransferAllowed, product_fee,fee_deducted, account_no, card_no, card_type)
  VALUES (10001, 'DNB Mobile only Bank', 'NOK', 'NOR', 'Mobile only Bank offering for Nordic Banks and tuned it for DNB', 0, 10, 1, 'Quarter', 1, 1, 0,0,8601,4492557,'VISA');