CREATE SEQUENCE acct.external_payment_card_seq
    INCREMENT 1
    START ${db.external.card.sequence.start}
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;
    
    ALTER SEQUENCE acct.account_details_account_id_seq
    OWNER TO ${db.objects.owner};
    
    CREATE TABLE acct.TB_EXTERNAL_PAYMENT_CARD
(
    PAYMENT_CARD_ID numeric(12,0) NOT NULL DEFAULT nextval('acct.external_payment_card_seq'::regclass),
    CARD_NUMBER character varying(255) COLLATE pg_catalog."default",
    CARD_NAME character varying(255) COLLATE pg_catalog."default",
    VALID_TO timestamp without time zone,
    CUSTOMER_ID numeric(12,0),
    ACTIVE_IN character(1) COLLATE pg_catalog."default",
    CARD_SCHEME character varying(255) COLLATE pg_catalog."default"
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE acct.TB_EXTERNAL_PAYMENT_CARD
    OWNER to ${db.objects.owner};