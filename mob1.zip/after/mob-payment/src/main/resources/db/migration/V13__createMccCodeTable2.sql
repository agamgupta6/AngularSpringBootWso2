DROP TABLE payment.tb_mcc_code;


CREATE TABLE payment.tb_mcc_code
(
	id numeric(10,0) NOT NULL,
    mcc_cd numeric(10,0) NOT NULL ,
    category_type character varying(255),
    CONSTRAINT tb_mcc_code_pkey PRIMARY KEY (id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE payment.tb_mcc_code
    OWNER to ${db.objects.owner};

INSERT INTO payment.tb_mcc_code(id, mcc_cd, category_type) VALUES (1,1999,'P2P');
INSERT INTO payment.tb_mcc_code(id, mcc_cd, category_type) VALUES (2,7278,'Invoice');
INSERT INTO payment.tb_mcc_code(id, mcc_cd, category_type) VALUES (3,7278,'Startbloc');
INSERT INTO payment.tb_mcc_code(id, mcc_cd, category_type) VALUES (4,5812,'Aahar');
INSERT INTO payment.tb_mcc_code(id, mcc_cd, category_type) VALUES (5,5812,'MyCoffee');
INSERT INTO payment.tb_mcc_code(id, mcc_cd, category_type) VALUES (6,5699,'Style');

DELETE FROM payment.tb_merchant;

INSERT INTO payment.tb_merchant(
  merchant_id, merchant_nm, merchant_status, mcc_cd, created_dt, created_by, address_line1_tx, address_line2_tx, city_nm, postal_cd, country_cd, email_id, invoice_partner_id, account_no, logo_link_tx, qr_code)
  VALUES (10001, 'MyCoffee', 1, 5812, current_timestamp, 'System', 'Newyork', 'USA', 'Manhattan', '530021', 'US', '1234@gmail.com', '12342', '53012345671', 'https://s3-eu-west-1.amazonaws.com/mob-private-bckt-dev/merchant/offers/my+coffee%402x.png', 'dqwr742f=ghghdhg562');

INSERT INTO payment.tb_merchant(
  merchant_id, merchant_nm, merchant_status, mcc_cd, created_dt, created_by, address_line1_tx, address_line2_tx, city_nm, postal_cd, country_cd, email_id, invoice_partner_id, account_no, logo_link_tx, qr_code)
  VALUES (10002, 'Style', 1, 5699, current_timestamp, 'System', 'Chicago', 'USA', 'Manhattan', '530022', 'US', '1235@gmail.com', '12342', '53012345672', 'https://s3-eu-west-1.amazonaws.com/mob-private-bckt-dev/merchant/offers/style%402x.png', 'dqwr742f=ghghdhg561');

INSERT INTO payment.tb_merchant(
  merchant_id, merchant_nm, merchant_status, mcc_cd, created_dt, created_by, address_line1_tx, address_line2_tx, city_nm, postal_cd, country_cd, email_id, invoice_partner_id, account_no, logo_link_tx, qr_code)
  VALUES (10003, 'Aahar', 1, 5812, current_timestamp, 'System', 'Oslo', 'Norway', 'Manhattan', '530023', 'NO', 'aahar@gmail.com', '12342', '53012345673', 'https://s3-eu-west-1.amazonaws.com/mob-private-bckt-dev/merchant/offers/aahar%402x.png', 'kh828933');

INSERT INTO payment.tb_merchant(
  merchant_id, merchant_nm, merchant_status, mcc_cd, created_dt, created_by, address_line1_tx, address_line2_tx, city_nm, postal_cd, country_cd, email_id, invoice_partner_id, account_no, logo_link_tx, qr_code)
  VALUES (10004, 'Nike', 1, 1100005, current_timestamp, 'London', 'UK', 'USA', 'Manhattan', '530025', 'US', '1234@gmail.com', '12342', '53012345674', 'https://s3-eu-west-1.amazonaws.com/mob-private-bckt-dev/merchant/offers/Nike.png', 'dqwr742f=ghghdhg567');

	