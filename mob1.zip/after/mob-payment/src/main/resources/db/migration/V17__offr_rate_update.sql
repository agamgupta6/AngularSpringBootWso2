  update payment.tb_offer_details set rate = 100 where merchant_id = 10001;
  update payment.tb_offer_details set rate = 30 where merchant_id = 10002;
  update payment.tb_offer_details set rate = 20 where merchant_id = 10003;
  update payment.tb_offer_details set rate = 40 where merchant_id = 10004;
  
  update cust.tb_customer set first_nm = 'Initial credit from Fabby Bank' where customer_id =9999;