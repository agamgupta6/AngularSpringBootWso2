update payment.tb_offer_details set beacon_cd = 'DBD12345-6789-10AB-CDEF-123456789DBD200201' where offer_id = 10001;

update payment.tb_offer_details set beacon_cd = 'DBD12345-6789-10AB-CDEF-123456789DBD200202' where offer_id = 10002;

update payment.tb_offer_details set beacon_cd = 'DBD12345-6789-10AB-CDEF-123456789DBD200203' where offer_id = 10003;

INSERT INTO payment.tb_offer_details(
  offer_id, merchant_id, offer_nm, offer_desc, rate, beacon_cd, expiry_period)
  VALUES (10004, 10004, 'winter spring', '40% off', 20,'FAEC855E-EE68-50F4-A984-0C746B4D264C18', 10);