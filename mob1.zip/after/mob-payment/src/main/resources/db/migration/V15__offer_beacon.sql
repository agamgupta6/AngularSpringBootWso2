update payment.tb_offer_details set beacon_cd ='275BE34D-D874-5DDB-BB9A-7B0646F091A718' where merchant_id =10004;
