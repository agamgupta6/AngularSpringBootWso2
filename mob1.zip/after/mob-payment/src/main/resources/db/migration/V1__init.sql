set client_encoding to 'UTF8';

 -- payment schema
DROP SCHEMA IF EXISTS payment CASCADE;
CREATE SCHEMA payment
    AUTHORIZATION ${db.objects.owner};
 -- payment view
CREATE OR REPLACE VIEW payment.vw_customer_account_details AS
SELECT 
  cu.customer_id, 
  cu.mobile_no,
  cu.first_nm,
  cu.last_nm,
  cu.status_id,
  cu.country_cd,
  acc.account_no,
  acc.account_id,
  acc.balance_am, 
  acc.active_in,
  card.vcard_no
FROM cust.tb_customer cu 
JOIN acct.tb_account_details acc ON cu.customer_id = acc.customer_id
JOIN acct.tb_vcard_details card ON cu.customer_id = card.customer_id;

ALTER VIEW payment.vw_customer_account_details
    OWNER TO ${db.objects.owner};

-- transaction table

CREATE SEQUENCE payment.tb_payment_transaction_id_seq
    INCREMENT 1
    START ${db.payment.transaction.sequence.start}
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE payment.tb_payment_transaction_id_seq
    OWNER TO ${db.objects.owner};
    
CREATE TABLE payment.tb_Payment_Transaction
(
    TRANSACTION_ID numeric(12) NOT NULL DEFAULT nextval('payment.tb_payment_transaction_id_seq'::regclass),
    BANK_ACCOUNT_ID numeric(16),
    CARD_ID numeric(16),
    TRASANCTION_AM numeric(20, 2) NOT NULL,
    CREATED_DT timestamp with time zone NOT NULL,
    SENDER_ID numeric(20),
    PAYMENT_TYPE character varying NOT NULL,
    STATUS numeric NOT NULL,
    UPDATED_DT timestamp with time zone,
    COUNTRY_CODE character varying,
    TRANSACTION_TX character varying,
    RECEIVER_ID numeric(20),
    TRASANCTION_TYPE numeric(5),
    IBAN character varying,
    SWIFT character varying,
    PRIMARY KEY (TRANSACTION_ID)
);

ALTER TABLE payment.tb_Payment_Transaction
    OWNER TO ${db.objects.owner};
  
    
CREATE SEQUENCE payment.tb_payment_source_id_seq
    INCREMENT 1
    START ${db.payment.source.sequence.start}
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE payment.tb_payment_source_id_seq
    OWNER TO ${db.objects.owner};
    
-- payment source table --
CREATE TABLE payment.tb_payment_source
(
    PAYMENT_SOURCE_ID numeric(12) NOT NULL DEFAULT nextval('payment.tb_payment_source_id_seq'::regclass),
    CARD_NUMBER numeric(16),
    CARD_EXPIRY timestamp with time zone,
  CUSTOMER_ID numeric(12,0),
  ACTIVE_IN character(1),
  CREATED_DT timestamp with time zone NOT NULL,
  UPDATED_DT timestamp with time zone,
  PRIMARY KEY (PAYMENT_SOURCE_ID)
);

ALTER TABLE payment.tb_payment_source
    OWNER TO ${db.objects.owner};
    

-- Table: cust."tb_beneficiary_details"

-- DROP TABLE cust."tb_beneficiary_details";
CREATE SEQUENCE payment.tb_beneficiary_details_id_seq
    INCREMENT 1
    START ${db.beneficiary.details.sequence.start}
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE payment.tb_beneficiary_details_id_seq
    OWNER TO ${db.objects.owner};
CREATE TABLE payment.tb_beneficiary_details

(

    PAYEE_ID numeric(12,0) NOT NULL NOT NULL DEFAULT nextval('payment.tb_beneficiary_details_id_seq'::regclass),

    CUSTOMER_ID numeric(12,0),

    MOBILE_NUMBER character(255) COLLATE pg_catalog."default",

    COUNTRY_CODE character(100) COLLATE pg_catalog."default",

    ACCOUNT_NUMBER character(255) COLLATE pg_catalog."default",

    PAYEE_NAME character(255) COLLATE pg_catalog."default",

    SWIFT_CODE character(255) COLLATE pg_catalog."default",

    CONSTRAINT tb_beneficiary_details_pkey PRIMARY KEY (PAYEE_ID)

)

WITH (

    OIDS = FALSE

)

TABLESPACE pg_default;

ALTER TABLE payment.tb_beneficiary_details

    OWNER to ${db.objects.owner}; 
