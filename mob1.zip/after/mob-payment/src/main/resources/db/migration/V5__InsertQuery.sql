DELETE FROM payment.tb_merchant;
DELETE FROM payment.tb_offer_details;

INSERT INTO payment.tb_merchant(
  merchant_id, merchant_nm, merchant_status, mcc_cd, created_dt, created_by, address_line1_tx, address_line2_tx, city_nm, postal_cd, country_cd, email_id, invoice_partner_id, account_no, logo_link_tx, qr_code)
  VALUES (10001, 'Candere', 1, 1100001, current_timestamp, 'System', 'Newyork', 'USA', 'Manhattan', '530021', 'US', '1234@gmail.com', '12342', '53012345671', 'https://s3-eu-west-1.amazonaws.com/mob-private-bckt-dev/merchant/offers/Candere.png', 'dqwr742f=ghghdhg562');

INSERT INTO payment.tb_merchant(
  merchant_id, merchant_nm, merchant_status, mcc_cd, created_dt, created_by, address_line1_tx, address_line2_tx, city_nm, postal_cd, country_cd, email_id, invoice_partner_id, account_no, logo_link_tx, qr_code)
  VALUES (10002, 'McDonald', 1, 1100002, current_timestamp, 'System', 'Chicago', 'USA', 'Manhattan', '530022', 'US', '1235@gmail.com', '12342', '53012345672', 'https://s3-eu-west-1.amazonaws.com/mob-private-bckt-dev/merchant/offers/McDonald.png', 'dqwr742f=ghghdhg561');

INSERT INTO payment.tb_merchant(
  merchant_id, merchant_nm, merchant_status, mcc_cd, created_dt, created_by, address_line1_tx, address_line2_tx, city_nm, postal_cd, country_cd, email_id, invoice_partner_id, account_no, logo_link_tx, qr_code)
  VALUES (10003, 'Cleartrip', 1, 1100003, current_timestamp, 'System', 'Oslo', 'Norway', 'Manhattan', '530023', 'NO', 'pizzahut@gmail.com', '12342', '53012345673', 'https://s3-eu-west-1.amazonaws.com/mob-private-bckt-dev/merchant/offers/ClearTrip.png', 'kh828933');

INSERT INTO payment.tb_merchant(
  merchant_id, merchant_nm, merchant_status, mcc_cd, created_dt, created_by, address_line1_tx, address_line2_tx, city_nm, postal_cd, country_cd, email_id, invoice_partner_id, account_no, logo_link_tx, qr_code)
  VALUES (10004, 'Nike', 1, 1100005, current_timestamp, 'London', 'UK', 'USA', 'Manhattan', '530025', 'US', '1234@gmail.com', '12342', '53012345674', 'https://s3-eu-west-1.amazonaws.com/mob-private-bckt-dev/merchant/offers/Nike.png', 'dqwr742f=ghghdhg567');
  
  INSERT INTO payment.tb_offer_details(
  offer_id, merchant_id, offer_nm, offer_desc, rate, beacon_cd, expiry_period)
  VALUES (10001, 10001, 'winter spring', '40% off', 20,'abcdefsfsdvcxf', 30);
  
  INSERT INTO payment.tb_offer_details(
  offer_id, merchant_id, offer_nm, offer_desc, rate, beacon_cd, expiry_period)
  VALUES (10002, 10002, 'winter spring', '40% off', 20,'abcdefsfsdvcxf3', 15);
  
  INSERT INTO payment.tb_offer_details(
  offer_id, merchant_id, offer_nm, offer_desc, rate, beacon_cd, expiry_period)
  VALUES (10003, 10003, 'winter spring', '40% off', 20,'FAEC855E-EE68-50F4-A984-0C746B4D264C18', 10);

