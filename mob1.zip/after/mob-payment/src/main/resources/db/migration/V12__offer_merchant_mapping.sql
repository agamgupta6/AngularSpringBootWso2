DELETE FROM payment.tb_merchant;

INSERT INTO payment.tb_merchant(
  merchant_id, merchant_nm, merchant_status, mcc_cd, created_dt, created_by, address_line1_tx, address_line2_tx, city_nm, postal_cd, country_cd, email_id, invoice_partner_id, account_no, logo_link_tx, qr_code)
  VALUES (10001, 'MyCoffee', 1, 1100001, current_timestamp, 'System', 'Newyork', 'USA', 'Manhattan', '530021', 'US', '1234@gmail.com', '12342', '53012345671', 'https://s3-eu-west-1.amazonaws.com/mob-private-bckt-dev/merchant/offers/my+coffee%402x.png', 'dqwr742f=ghghdhg562');

INSERT INTO payment.tb_merchant(
  merchant_id, merchant_nm, merchant_status, mcc_cd, created_dt, created_by, address_line1_tx, address_line2_tx, city_nm, postal_cd, country_cd, email_id, invoice_partner_id, account_no, logo_link_tx, qr_code)
  VALUES (10002, 'Style', 1, 1100002, current_timestamp, 'System', 'Chicago', 'USA', 'Manhattan', '530022', 'US', '1235@gmail.com', '12342', '53012345672', 'https://s3-eu-west-1.amazonaws.com/mob-private-bckt-dev/merchant/offers/style%402x.png', 'dqwr742f=ghghdhg561');

INSERT INTO payment.tb_merchant(
  merchant_id, merchant_nm, merchant_status, mcc_cd, created_dt, created_by, address_line1_tx, address_line2_tx, city_nm, postal_cd, country_cd, email_id, invoice_partner_id, account_no, logo_link_tx, qr_code)
  VALUES (10003, 'Aahar', 1, 1100003, current_timestamp, 'System', 'Oslo', 'Norway', 'Manhattan', '530023', 'NO', 'aahar@gmail.com', '12342', '53012345673', 'https://s3-eu-west-1.amazonaws.com/mob-private-bckt-dev/merchant/offers/aahar%402x.png', 'kh828933');

INSERT INTO payment.tb_merchant(
  merchant_id, merchant_nm, merchant_status, mcc_cd, created_dt, created_by, address_line1_tx, address_line2_tx, city_nm, postal_cd, country_cd, email_id, invoice_partner_id, account_no, logo_link_tx, qr_code)
  VALUES (10004, 'Nike', 1, 1100005, current_timestamp, 'London', 'UK', 'USA', 'Manhattan', '530025', 'US', '1234@gmail.com', '12342', '53012345674', 'https://s3-eu-west-1.amazonaws.com/mob-private-bckt-dev/merchant/offers/Nike.png', 'dqwr742f=ghghdhg567');

DELETE FROM payment.tb_offer_details;

INSERT INTO payment.tb_offer_details(offer_id, merchant_id, offer_nm, offer_desc, rate, beacon_cd, expiry_period)
  VALUES (10001,10001,'Free Coffee to Kickstart the Innovation Day outside auditorium' , '100% off',0,'DBD12345-6789-10AB-CDEF-123456789DBD200201', 26);
  
INSERT INTO payment.tb_offer_details(offer_id, merchant_id, offer_nm, offer_desc, rate, beacon_cd, expiry_period)
  VALUES (10002,10002,'30% off on Style when you shop using MOB' , '30% off',1000,'DBD12345-6789-10AB-CDEF-123456789DBD200202', 26);
  
INSERT INTO payment.tb_offer_details(offer_id, merchant_id, offer_nm, offer_desc, rate, beacon_cd, expiry_period)
  VALUES (10003,10003,'20% off on Aahar when you shop using MOB' , '20% off',50,'DBD12345-6789-10AB-CDEF-123456789DBD200203', 26);
  
INSERT INTO payment.tb_offer_details(offer_id, merchant_id, offer_nm, offer_desc, rate, beacon_cd, expiry_period)
  VALUES (10004, 10004, 'winter spring', '40% off', 20,'FAEC855E-EE68-50F4-A984-0C746B4D264C18', 10);