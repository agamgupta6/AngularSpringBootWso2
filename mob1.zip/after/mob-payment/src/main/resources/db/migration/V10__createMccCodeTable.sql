
CREATE TABLE payment.tb_mcc_code
(
    mcc_cd numeric(10,0) NOT NULL ,
    category_type character varying(255),
    CONSTRAINT tb_mcc_code_pkey PRIMARY KEY (mcc_cd)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE payment.tb_mcc_code
    OWNER to ${db.objects.owner};
    
INSERT INTO payment.tb_mcc_code(mcc_cd, category_type) VALUES (12345,'Mob2Mob');
INSERT INTO payment.tb_mcc_code(mcc_cd, category_type) VALUES (12346,'Mob2Others');
INSERT INTO payment.tb_mcc_code(mcc_cd, category_type) VALUES (12347,'Invoice');
	