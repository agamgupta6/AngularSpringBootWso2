

CREATE TABLE payment.tb_beacon_offer_details
(
    customer_id numeric(12,0) NOT NULL,
	offer_id numeric(12,0) NOT NULL,
	merchant_id numeric(12,0) NOT NULL,
	merchant_nm character varying(255) COLLATE pg_catalog."default",
	merchant_logo character varying(255) COLLATE pg_catalog."default",
	merchant_account_no numeric(16,0),
	discount_rate numeric(12,0) NOT NULL,
	offer_expiry_dt date,
	status numeric NOT NULL,
	beacon_cd character varying(255) COLLATE pg_catalog."default",
    CONSTRAINT tb_beacon_offer_details_pkey PRIMARY KEY (customer_id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE payment.tb_beacon_offer_details
    OWNER to ${db.objects.owner};
