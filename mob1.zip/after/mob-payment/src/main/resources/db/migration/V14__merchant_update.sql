update payment.tb_merchant set merchant_nm ='Ehome',logo_link_tx='https://s3-eu-west-1.amazonaws.com/mob-private-bckt-dev/merchant/offers/ehome%402x.png' where merchant_id =10004;

alter table payment.tb_beacon_offer_details drop constraint tb_beacon_offer_details_pkey;
alter table payment.tb_beacon_offer_details add column customer_offer_id serial;
alter table payment.tb_beacon_offer_details add constraint tb_beacon_offer_details_pkey primary key (customer_offer_id);
  
  -- Table: payment.tb_customer_concent

-- DROP TABLE payment.tb_customer_concent;

CREATE SEQUENCE payment.customer_concent_id_seq
    INCREMENT 1
    START ${db.payment.transaction.sequence.start}
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE payment.customer_concent_id_seq
    OWNER TO ${db.objects.owner};

CREATE TABLE payment.tb_customer_concent
(
	concent_id numeric(12,0) NOT NULL,
    customer_id numeric(12,0) NOT NULL,
    merchant_id numeric(12,0) NOT NULL,
    merchant_nm character varying(255),
    merchant_logo character varying(255),
    concent boolean,
    CONSTRAINT tb_customer_concent_pkey PRIMARY KEY (concent_id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE payment.tb_customer_concent
    OWNER to ${db.objects.owner};
    
update payment.tb_offer_details set beacon_cd ='275be34d-d874-5ddb-bb9a-7b0646f091a718' where merchant_id =10004;