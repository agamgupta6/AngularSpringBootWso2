ALTER TABLE payment.tb_Payment_Transaction ADD MCC_CD character varying(255) COLLATE pg_catalog."default";

CREATE SEQUENCE payment.tb_merchant_id_seq
    INCREMENT 1
    START ${db.payment.merchant.sequence.start}
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE payment.tb_merchant_id_seq
    OWNER TO ${db.objects.owner};

    
CREATE SEQUENCE payment.tb_offer_id_seq
    INCREMENT 1
    START ${db.payment.offer.details.sequence.start}
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE payment.tb_offer_id_seq
    OWNER TO ${db.objects.owner};

CREATE TABLE payment.tb_merchant
(
    merchant_id numeric(12,0) NOT NULL DEFAULT nextval('payment.tb_merchant_id_seq'::regclass),
    merchant_nm character varying(255) COLLATE pg_catalog."default",
    merchant_status integer,
    mcc_cd integer,
    created_dt date,
    created_by character varying(255) COLLATE pg_catalog."default",
    address_line1_tx character varying(255) COLLATE pg_catalog."default",
    address_line2_tx character varying(255) COLLATE pg_catalog."default",
    city_nm character varying(255) COLLATE pg_catalog."default",
	postal_cd character varying(8) COLLATE pg_catalog."default",
    country_cd character varying(8) COLLATE pg_catalog."default",
    email_id character varying(255) COLLATE pg_catalog."default",
    invoice_partner_id character varying(255) COLLATE pg_catalog."default",
    account_no numeric(16,0),
	logo_link_tx character varying(255) COLLATE pg_catalog."default",
	qr_code character varying(255) COLLATE pg_catalog."default",
    CONSTRAINT tb_merchant_pkey PRIMARY KEY (merchant_id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE payment.tb_merchant
    OWNER to ${db.objects.owner};
	
	
CREATE TABLE payment.tb_offer_details
(
    offer_id numeric(12,0) NOT NULL DEFAULT nextval('payment.tb_offer_id_seq'::regclass),
	merchant_id numeric(12,0) NOT NULL,
	offer_nm character varying(255) COLLATE pg_catalog."default",
	offer_desc character varying(255) COLLATE pg_catalog."default",
	rate numeric(12,0) NOT NULL,
    CONSTRAINT tb_offerDetails_pkey PRIMARY KEY (offer_id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE payment.tb_offer_details
    OWNER to ${db.objects.owner};

ALTER TABLE payment.tb_Payment_Transaction ADD BALANCE_AM numeric(20, 2);    

ALTER TABLE payment.tb_offer_details ADD beacon_cd character varying(255) COLLATE pg_catalog."default"; 

ALTER TABLE payment.tb_offer_details ADD expiry_period numeric(8,0);
