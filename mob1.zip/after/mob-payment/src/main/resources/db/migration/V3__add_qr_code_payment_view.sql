CREATE OR REPLACE VIEW payment.vw_customer_account_details AS
SELECT 
  cu.customer_id, 
  cu.mobile_no,
  cu.first_nm,
  cu.last_nm,
  cu.status_id,
  cu.country_cd,
  acc.account_no,
  acc.account_id,
  acc.balance_am, 
  acc.active_in,
  card.vcard_no,
  acc.qr_code
FROM cust.tb_customer cu 
JOIN acct.tb_account_details acc ON cu.customer_id = acc.customer_id
JOIN acct.tb_vcard_details card ON cu.customer_id = card.customer_id;

ALTER VIEW payment.vw_customer_account_details
    OWNER TO ${db.objects.owner};