package com.no.mob.payment.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

/**
 * BeneficiaryDetailDto
 */

@Getter
@Setter
public class BeneficiaryDetailDto   {
  @JsonProperty("payeeName")
  private String payeeName = null;

  @JsonProperty("mobileNumber")
  private String mobileNumber = null;

  @JsonProperty("swiftCode")
  private String swiftCode = null;

  @JsonProperty("accountNumber")
  private String accountNumber = null;
  
  @JsonProperty("qrCode")
  private String qrCode = null;
  
  
}

