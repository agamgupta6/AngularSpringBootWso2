package com.no.mob.payment.suntech.model;

import lombok.Data;

@Data
public class SuntechResponseDto {
	private String entityName;
	private String entityCode;
	private String entityImage;
	private String entityUri;
}
