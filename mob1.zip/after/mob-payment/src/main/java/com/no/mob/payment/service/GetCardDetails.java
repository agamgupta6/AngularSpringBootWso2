package com.no.mob.payment.service;

import java.util.List;

import com.no.mob.payment.model.GetCardDetailsResponseDto;

public interface GetCardDetails {

	public List<GetCardDetailsResponseDto> getCardDetails(String mobileNumber);

}
