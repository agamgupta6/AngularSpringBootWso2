package com.no.mob.payment.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MerchantDetailsRequestDto {

	private String qrCode;
	private String beaconCode;
}
