package com.no.mob.payment.meniga.response;

import java.util.Date;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
@Setter
@Getter
public class Transactions {

	private String parentIdentifier;
	private int id;
	private int amount;
	private Object[] tags;
	private Object[] comments;
	private int categoryId;
	private String date;
	private String text;
	private Date originalDate;
	private Object data;
	private String originalText;
	private int originalAmopunt;
	private boolean isRead;
	private boolean isFlagged;
	private boolean hasUncertainCategorization;
	private int accountId;
	private int mcc;
	private List<DetectedCategories> detectedCategories;
	private String currency;
	private String amountInCurrency;
	private int dataFormat;
	private long merchantId;
	private List<ParsedData> parsedData;
	private int accuracy;
	private String bankId;
	private String insertTime;
	private boolean isMerchant;
	private boolean isUncleared;
	private int topicId;
	private String topicName;
	private String title;
	private String typeName;
	private String type;
}
