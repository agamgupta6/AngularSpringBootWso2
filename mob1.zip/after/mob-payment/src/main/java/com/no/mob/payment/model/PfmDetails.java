package com.no.mob.payment.model;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class PfmDetails {

	private String firstNm;
	private String lastNm;
	private String categoryType;
	private String date;
	private String amount;
	private String transferType;
	private String transactionId;
	
	public void setDate(long date) {
		 DateFormat df = new SimpleDateFormat("dd MMM yyyy  HH:mm:ss");
		    this.date = df.format(date);
	}
}
