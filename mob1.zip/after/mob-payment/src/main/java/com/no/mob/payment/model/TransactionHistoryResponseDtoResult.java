package com.no.mob.payment.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * TransactionHistoryResponseDtoResult
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2017-12-27T14:35:19.053Z")

public class TransactionHistoryResponseDtoResult   {
  @JsonProperty("transactions")
  private List<TransactionHistoryResponseDtoResultTransactions> transactions = null;

  
  public TransactionHistoryResponseDtoResult(){
	  this.transactions = new ArrayList<>();
	  
  }
  public TransactionHistoryResponseDtoResult transactions(List<TransactionHistoryResponseDtoResultTransactions> transactions) {
    this.transactions = transactions;
    return this;
  }

  public TransactionHistoryResponseDtoResult addTransactionsItem(TransactionHistoryResponseDtoResultTransactions transactionsItem) {
    if (this.transactions == null) {
      this.transactions = new ArrayList<TransactionHistoryResponseDtoResultTransactions>();
    }
    this.transactions.add(transactionsItem);
    return this;
  }

   /**
   * Get transactions
   * @return transactions
  **/
  @ApiModelProperty(value = "")

  @Valid

  public List<TransactionHistoryResponseDtoResultTransactions> getTransactions() {
    return transactions;
  }

  public void setTransactions(List<TransactionHistoryResponseDtoResultTransactions> transactions) {
    this.transactions = transactions;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TransactionHistoryResponseDtoResult transactionHistoryResponseDtoResult = (TransactionHistoryResponseDtoResult) o;
    return Objects.equals(this.transactions, transactionHistoryResponseDtoResult.transactions);
  }

  @Override
  public int hashCode() {
    return Objects.hash(transactions);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TransactionHistoryResponseDtoResult {\n");
    
    sb.append("    transactions: ").append(toIndentedString(transactions)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

