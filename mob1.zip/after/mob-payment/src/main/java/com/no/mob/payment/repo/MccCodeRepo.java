package com.no.mob.payment.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.no.mob.payment.entity.MccCode;

@Repository
public interface MccCodeRepo extends CrudRepository<MccCode, Long>{

	public MccCode findByCategoryType(String string);

}
