package com.no.mob.payment.service;

import com.no.mob.payment.model.MerchantPaymentTransferRequestDto;
import com.no.mob.payment.model.MerchantTransferServiceResponseDto;
import com.no.mob.payment.model.PaymentSourceRequestDto;
import com.no.mob.payment.model.PaymentTransferRequestDto;
import com.no.mob.payment.model.TransferServiceResponseDto;

public interface PaymentTransferService {

	public TransferServiceResponseDto makePayment(String mobileNo, PaymentTransferRequestDto paymentTransferRequestDto);

	public void saveTransaction(PaymentTransferRequestDto paymentTransferRequestDto);
	
	public void savePaymentSource(PaymentSourceRequestDto paymentSourceRequestDto);
	
	public MerchantTransferServiceResponseDto makeMerchantPayment(String mobileNo, MerchantPaymentTransferRequestDto merchantPaymentTransferRequestDto);

}
