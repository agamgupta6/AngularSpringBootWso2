package com.no.mob.payment.model;

public enum AccountStatus {
	ACTIVE('Y'), DEACTIVE('F');
	AccountStatus(char i) {

	}
}
