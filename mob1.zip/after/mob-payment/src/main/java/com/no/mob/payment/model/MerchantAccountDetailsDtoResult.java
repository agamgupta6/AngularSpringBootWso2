package com.no.mob.payment.model;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MerchantAccountDetailsDtoResult {

	private String merchantLogo;
	private String merchantId;
	private String merchantNm;
	private String accountNo;
	private BigDecimal discountRate;
	private String mcc;
}
