package com.no.mob.payment.exceptions;

import java.io.Serializable;

import com.no.mob.payment.common.ErrorDetails;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class BusinessException extends RuntimeException implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1459081259344750958L;
	
	private final ErrorDetails errorDetails;

	public BusinessException(String errorCode , String errorMsgKey) {
		super(errorCode);
		errorDetails = new ErrorDetails(errorCode, errorMsgKey);	}
	
}
