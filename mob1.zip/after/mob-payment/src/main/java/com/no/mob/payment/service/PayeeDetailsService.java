package com.no.mob.payment.service;

import org.springframework.stereotype.Service;

import com.no.mob.payment.model.BeneficiaryDetailsDtoResult;
import com.no.mob.payment.model.BeneficiaryRequestDto;

@Service
public interface PayeeDetailsService {
	
	void addPayeeDetails(BeneficiaryRequestDto beneficiaryRequestdto, String mobileNumber);

	BeneficiaryDetailsDtoResult fetchPayeeDetails(String mobileNumber);

}
