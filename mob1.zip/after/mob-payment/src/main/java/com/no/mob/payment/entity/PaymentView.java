package com.no.mob.payment.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
@Entity
@Table(name = "vw_customer_account_details")
public class PaymentView implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "CUSTOMER_ID")
	private Long customerId;
	@Column(name = "ACCOUNT_NO")
	private String accountNo;
	@Column(name= "ACCOUNT_ID")
	private Long accountId;
	@Column(name = "MOBILE_NO")
	private String mobileNo;
	@Column(name = "FIRST_NM")
	private String firstName;
	@Column(name = "LAST_NM")
	private String lastName;
	@Column(name = "ACTIVE_IN")
	private char accountStatus;
	@Column(name = "STATUS_ID")
	private String statusId;
	@Column(name = "COUNTRY_CD")
	private String countryCd;
	@Size(max = 7)
	@Column(name = "BALANCE_AM")
	private BigDecimal balanceAmount;
	@Column(name = "VCARD_NO")
	private String cardNo;
	@Column(name = "QR_CODE")
	private String qrCode;
	

}
