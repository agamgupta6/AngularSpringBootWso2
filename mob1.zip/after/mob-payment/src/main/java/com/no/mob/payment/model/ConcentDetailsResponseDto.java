package com.no.mob.payment.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ConcentDetailsResponseDto {
	private String merchantId;
	private String merchantLogoUrl;
	private String merchantNm;
	private Boolean concent; 
	private String mcc;

}
