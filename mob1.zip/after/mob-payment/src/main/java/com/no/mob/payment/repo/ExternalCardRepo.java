package com.no.mob.payment.repo;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.no.mob.payment.entity.ExternalPaymentCard;

@Repository
public interface ExternalCardRepo extends CrudRepository<ExternalPaymentCard, Long>{

	Optional<ExternalPaymentCard> findByCustomerIdAndCardNumber(Long customerId, String paymentSource);
	
	Optional<ExternalPaymentCard> findByPaymentCardId(Long paymentCardId);

}
