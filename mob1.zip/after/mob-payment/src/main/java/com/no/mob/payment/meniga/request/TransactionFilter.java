package com.no.mob.payment.meniga.request;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class TransactionFilter {

	private List<String> accountIdentifiers;
	private String periodFrom;
	private String periodTo;
	private String orderBy;
	private boolean ascendingOrder;

}
