package com.no.mob.payment.model;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class TransferServiceResponseDto {

	private String transactionId;
	private String logoUrl;
	private String type;
	private String category;
	private String status;
	private String date;
	private String name;
	private String amount;
	private String paymentSource;
	private String accountNumber;
	private int mmCd;
	
	public String getDate() {
		return date;
	}
	
	public void setDate(long date) {
		 DateFormat df = new SimpleDateFormat("dd MMM yyyy  HH:mm:ss");
		 this.date = df.format(date);
	}
	
	
}
