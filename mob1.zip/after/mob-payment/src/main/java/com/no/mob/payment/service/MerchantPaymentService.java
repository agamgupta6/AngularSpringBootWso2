package com.no.mob.payment.service;

import com.no.mob.payment.model.MerchantPaymentTransferRequestDto;
import com.no.mob.payment.model.MerchantTransferServiceResponseDto;

public interface MerchantPaymentService {
	public MerchantTransferServiceResponseDto makeMerchantPayment(String mobileNo,
			MerchantPaymentTransferRequestDto merchantPaymentTransferRequestDto);
}
