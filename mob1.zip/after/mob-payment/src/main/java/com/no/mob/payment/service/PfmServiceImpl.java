package com.no.mob.payment.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.no.mob.payment.common.CommonUtils;
import com.no.mob.payment.config.LoggingRequestInterceptor;
import com.no.mob.payment.entity.PaymentView;
import com.no.mob.payment.exceptions.BusinessException;
import com.no.mob.payment.meniga.request.Filter;
import com.no.mob.payment.meniga.request.Options;
import com.no.mob.payment.meniga.request.SeriesSelectors;
import com.no.mob.payment.meniga.request.TransactionFilter;
import com.no.mob.payment.meniga.request.TransactionSeriesRequest;
import com.no.mob.payment.meniga.response.CategoriesResponse;
import com.no.mob.payment.meniga.response.CategoryData;
import com.no.mob.payment.meniga.response.ParsedData;
import com.no.mob.payment.meniga.response.TransactionSeriesResponse;
import com.no.mob.payment.meniga.response.TransactionSeriesResponseDto;
import com.no.mob.payment.meniga.response.Transactions;
import com.no.mob.payment.model.CategoriesList;
import com.no.mob.payment.model.PfmDetails;
import com.no.mob.payment.model.PfmDetailsResponseDto;
import com.no.mob.payment.repo.PaymentViewRepo;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PfmServiceImpl implements PfmService {

	private static final String AUTHORIZATION = "Authorization";

	private static final String MENIGA_CATEGORIES_URL = "https://dnb.poc.meniga.io:9810/user/v1/categories/";

	@Autowired
	private PaymentViewRepo paymentViewRepo;

	@Value("${meniga.uri}")
	private String menigaUrl;

	RestTemplate restTemplate = new RestTemplate(new BufferingClientHttpRequestFactory(new SimpleClientHttpRequestFactory()));
	

	@Override
	public PfmDetailsResponseDto fetchPfmDetails(String mobileNumber, String targetDt) {

		List<ClientHttpRequestInterceptor> interceptors = new ArrayList<>();
		interceptors.add(new LoggingRequestInterceptor());
		restTemplate.setInterceptors(interceptors);
		
		PaymentView paymentView = paymentViewRepo.findByMobileNo(mobileNumber)
				.orElseThrow(() -> new BusinessException("404", "Account Details Not Found"));
		HttpHeaders headers = new HttpHeaders();
		headers.set(AUTHORIZATION, "Bearer uid:"+paymentView.getCustomerId());
		headers.set("Content-Type", "application/json");
		HttpEntity<TransactionSeriesRequest> request = new HttpEntity<>(
				createTransactionSeriesRequest(targetDt, paymentView.getAccountId()), headers);
		log.info("Request:" + request.getBody());
		ResponseEntity<TransactionSeriesResponseDto> result = restTemplate.exchange(
				menigaUrl + "/user/v1/transactions/series", HttpMethod.POST, request,
				TransactionSeriesResponseDto.class);
		log.info("result : "+result.getBody());
		if (result.hasBody()) {
			return createResponse(result.getBody());
		}
		return null;
	}

	private PfmDetailsResponseDto createResponse(TransactionSeriesResponseDto transactionSeriesResponseDto) {
		PfmDetailsResponseDto pfmDetailsResponseDto = new PfmDetailsResponseDto();
		List<CategoriesList> categoriesList = new ArrayList<>();
		List<PfmDetails> categoryTransactionList = new ArrayList<>();
		CategoriesList categories = new CategoriesList();
		HttpHeaders headers = new HttpHeaders();
		headers.set(AUTHORIZATION, "Bearer uid:9999");
		HttpEntity<HttpHeaders> entity = new HttpEntity<>(headers);
		ResponseEntity<CategoriesResponse> result = restTemplate
				.exchange(MENIGA_CATEGORIES_URL,HttpMethod.GET, entity, CategoriesResponse.class);

		populatePfmResponseDetails(transactionSeriesResponseDto, pfmDetailsResponseDto, categoriesList, categoryTransactionList,
				categories, result);
		return pfmDetailsResponseDto;
	}

	private void populatePfmResponseDetails(TransactionSeriesResponseDto transactionSeriesResponseDto,
			PfmDetailsResponseDto pfmDetailsResponseDto, List<CategoriesList> categoriesList,
			List<PfmDetails> categoryTransactionList, CategoriesList categories,
			ResponseEntity<CategoriesResponse> result) {
		if (null != transactionSeriesResponseDto && null != transactionSeriesResponseDto.getData()) {
			for (TransactionSeriesResponse data : transactionSeriesResponseDto.getData()) {
				Set<Integer> categoryIds = new HashSet<>();
				for (Transactions transactions : data.getTransactions()) {
					categoryIds.add(transactions.getCategoryId());
				}
				pfmDetailsResponseDto.setTotalAmount(String.valueOf(data.getValues().get(0).getNettoAmount()));
				populateCategoryList(categoriesList, categoryTransactionList, categories, result, data, categoryIds);
				pfmDetailsResponseDto.setCategoriesList(categoriesList);
			}
		}
	}

	private void populateCategoryList(List<CategoriesList> categoriesList, List<PfmDetails> categoryTransactionList,
			CategoriesList categories, ResponseEntity<CategoriesResponse> result, TransactionSeriesResponse data,
			Set<Integer> categoryIds) {
		for(Integer id:categoryIds){
			for (Transactions transactions : data.getTransactions()) {
				if (transactions.getCategoryId() == id)
					categories.setAmount(transactions.getAmount()+ categories.getAmount());
				PfmDetails pfmDetails = new PfmDetails();
				pfmDetails.setAmount(String.valueOf(transactions.getAmount()));
				pfmDetails.setDate(transactions.getOriginalDate().getTime());
				pfmDetails.setTransactionId(String.valueOf(transactions.getId()));
				setCategoryData(categories, result, id, pfmDetails);
				parsedDate(transactions, pfmDetails);
				categoryTransactionList.add(pfmDetails);
			}
			categories.setCategoryTransactionList(categoryTransactionList);
			categoriesList.add(categories);
		}
	}

	private void setCategoryData(CategoriesList categories, ResponseEntity<CategoriesResponse> result, Integer id,
			PfmDetails pfmDetails) {
		for (CategoryData categoryData : result.getBody().getData()) {
			if (categoryData.getId() == id) {
				categories.setCategoryName(categoryData.getCategoryType());
				pfmDetails.setCategoryType(categoryData.getCategoryType());
			}
		}
	}

	private void parsedDate(Transactions transactions, PfmDetails pfmDetails) {
		if(null!=transactions.getParsedData()){
			for(ParsedData pdata :transactions.getParsedData()){
				if(pdata.getKey().equals("PaymentType")){
					pfmDetails.setTransferType(pdata.getValue());
				}else if(pdata.getKey().equals("ReceiverFirstName")){
					pfmDetails.setFirstNm(pdata.getValue());
				}else{
					pfmDetails.setLastNm(pdata.getValue());
				}
			}
		}
	}

	private TransactionSeriesRequest createTransactionSeriesRequest(String targetDt, Long accountNo) {
		TransactionSeriesRequest seriesRequest = new TransactionSeriesRequest();
		TransactionFilter transactionFilter = new TransactionFilter();
		transactionFilter.setAscendingOrder(true);
		transactionFilter.setOrderBy("ByDate");
		transactionFilter.setPeriodFrom(createFromDate(targetDt));
		transactionFilter.setPeriodTo(createToDate(targetDt));
		List<String> accountIds = new ArrayList<>();
		accountIds.add(accountNo.toString());
		transactionFilter.setAccountIdentifiers(accountIds);
		Options options = new Options();
		options.setIncludeTransactionIds(true);
		options.setIncludeTransactions(true);
		List<SeriesSelectors> seriesSelectors = new ArrayList<>();
		SeriesSelectors selectors = new SeriesSelectors();
		Filter filter = new Filter();
		filter.setOriginalPeriodFrom(createFromDate(targetDt));
		filter.setOriginalPeriodTo(createToDate(targetDt));
		filter.setPeriodFrom(createFromDate(targetDt));
		filter.setPeriodTo(createToDate(targetDt));
		selectors.setFilter(filter);
		seriesSelectors.add(selectors);
		seriesRequest.setOptions(options);
		seriesRequest.setTransactionFilter(transactionFilter);
		seriesRequest.setSeriesSelectors(seriesSelectors);
		return seriesRequest;
	}

	private String createToDate(String targetDt) {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.MONTH,Integer.valueOf(targetDt.substring(0,2))-1);
		cal.set(Calendar.YEAR,Integer.valueOf(targetDt.substring(3,7)));
		if(Integer.valueOf(targetDt.substring(0,2))%2==0){
			cal.set(Calendar.DAY_OF_MONTH,30);
		}else{
			cal.set(Calendar.DAY_OF_MONTH,31);
		}
		return CommonUtils.dateFormater2(cal.getTime());
	}

	private String createFromDate(String targetDt) {
		Calendar cal = Calendar.getInstance();
		int month= Integer.parseInt(targetDt.substring(0,2));
		if(month==0){
			cal.set(Calendar.MONTH,month);
		}else{
			cal.set(Calendar.MONTH,month-1);
		}
		cal.set(Calendar.MONTH,Integer.valueOf(targetDt.substring(0,2))-1);
		cal.set(Calendar.YEAR,Integer.valueOf(targetDt.substring(3,7)));
		cal.set(Calendar.DAY_OF_MONTH,1);
		return CommonUtils.dateFormater2(cal.getTime());
	}

	@Override
	public PfmDetailsResponseDto fetchPfmTransactionDetails(String mobileNumber, String targetDt) {
		HttpHeaders headers = new HttpHeaders();
		headers.set(AUTHORIZATION, "Bearer uid:9999");
		String url = menigaUrl + "/user/v1/feed?dateFrom=" + createFromDate(targetDt) + "&dateTo="
				+ createToDate(targetDt) + "&type=transactions";
		restTemplate.getForEntity(url, Object.class);
		return null;
	}

}
