package com.no.mob.payment.service;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.no.mob.payment.common.GenericResponse;
import com.no.mob.payment.entity.ExternalPaymentCard;
import com.no.mob.payment.entity.MerchantEntity;
import com.no.mob.payment.entity.PaymentEntity;
import com.no.mob.payment.entity.PaymentView;
import com.no.mob.payment.exceptions.BusinessException;
import com.no.mob.payment.model.MerchantPaymentTransferRequestDto;
import com.no.mob.payment.model.MerchantTransferServiceResponseDto;
import com.no.mob.payment.model.PaymentTransferDto;
import com.no.mob.payment.repo.ExternalCardRepo;

@Service
public class ExternalCardChannel extends MerchantPaymentServiceImpl implements ChannelType {

	@Value("${external.debit.payment.uri}")
	private String externalDebitUri;

	@Autowired
	private ExternalCardRepo externalCardRepo;
	
	private Logger log = LoggerFactory.getLogger(this.getClass());

	@Override
	public MerchantTransferServiceResponseDto debitPayment(String mobileNo,
			MerchantPaymentTransferRequestDto merchantPaymentTransferRequestDto, PaymentView sourcePaymentDetails) {
		
		log.info("inside debit payment using external card channel where source details = {}",sourcePaymentDetails.toString());

		PaymentEntity paymentEntity = null;
		BigDecimal amount = merchantPaymentTransferRequestDto.getAmount();
		HttpHeaders headers = setHeaders(mobileNo);

		ExternalPaymentCard externalPaymentCard = externalCardRepo
				.findByCustomerIdAndCardNumber(sourcePaymentDetails.getCustomerId(),
						merchantPaymentTransferRequestDto.getPaymentSource())
				.orElseThrow(() -> new BusinessException("404", "Payment Source Invalid"));

		ResponseEntity<GenericResponse> debit = debitPayment(sourcePaymentDetails, amount, headers);

		if (debit.getStatusCode().equals(HttpStatus.OK)) {
			MerchantEntity merchant = merchantRepo.findByMerchantId(merchantPaymentTransferRequestDto.getMerchantId());
			PaymentEntity payment = createMerchantTransactionEntity(merchantPaymentTransferRequestDto,
					sourcePaymentDetails, String.valueOf(merchant.getMccCd()),BigDecimal.valueOf(2000L) /*debit.getBody().getResult()*/, false);
			paymentEntity = paymentRepo.save(payment);
		} else {
			throw new BusinessException("417", "debit failed");
		}
		return createMerchantResponse(merchantPaymentTransferRequestDto, paymentEntity, sourcePaymentDetails, externalPaymentCard.getCardName());
	}

	private ResponseEntity<GenericResponse> debitPayment(PaymentView sourcePaymentDetails, BigDecimal amount,
			HttpHeaders headers) {

		HttpEntity<PaymentTransferDto> request = new HttpEntity<>(
				new PaymentTransferDto(null, amount, sourcePaymentDetails.getAccountNo()), headers);

		ResponseEntity<GenericResponse> debit = new ResponseEntity<>(HttpStatus.OK);/* restTemplate.exchange(externalDebitUri, HttpMethod.POST, request,
				GenericResponse.class);*/
		return debit;
	}

}
