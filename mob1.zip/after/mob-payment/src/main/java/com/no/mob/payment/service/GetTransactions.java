package com.no.mob.payment.service;

import com.no.mob.payment.model.TransactionHistoryResponseDtoResult;
import com.no.mob.payment.model.TransactionHistoryResponseDtoResultTransactions;

public interface GetTransactions {

	TransactionHistoryResponseDtoResult getTransactionHistorydetails(String mobileNumber);

	TransactionHistoryResponseDtoResultTransactions getTransactionDetails(String transactionId, String mobileNumber);

}
