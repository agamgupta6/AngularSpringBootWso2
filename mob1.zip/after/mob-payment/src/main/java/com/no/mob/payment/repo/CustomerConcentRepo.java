package com.no.mob.payment.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.no.mob.payment.entity.CustomerConcent;

public interface CustomerConcentRepo extends CrudRepository<CustomerConcent, Long> {

	public Optional<List<CustomerConcent>> findAllByCustomerId(Long customerId);
	
	public Optional<CustomerConcent> findByCustomerIdAndMerchantId(Long customerId, Long merchantId);

}
