package com.no.mob.payment.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.no.mob.payment.entity.PaymentSource;


@Repository
public interface CardDetailsRepo extends CrudRepository<PaymentSource, Long> {
	public List<PaymentSource> findByCustomerId(Long customerId);

}
