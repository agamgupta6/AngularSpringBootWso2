package com.no.mob.payment.model;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class PaymentTransferRequestDto {
	private long targetAccountNo;

	private BigDecimal amount;

	private String swiftCode;

	private String name;

	private String countryCode;

	private String transactionTxt;

	private long cardNumber;

	private long accountId;

	private long senderId;

	private long receiverId;

}
