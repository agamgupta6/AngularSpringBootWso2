/*package com.no.mob.payment.security;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.no.mob.payment.exceptions.BusinessException;

@Component
public class JwtAuthFilter implements Filter {

	@Autowired
	private JWTAuthenticationFilter jWTAuthenticationFilter;
	
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// initialize filter
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest servletRequest = (HttpServletRequest) request;

		if (servletRequest.getRequestURI().contains("/getTransactions")
				|| servletRequest.getRequestURI().contains("/transferMoney")
				|| servletRequest.getRequestURI().contains("/getBeneficiaryDetails")
				|| servletRequest.getRequestURI().contains("/addPayeeDeatils")
				|| servletRequest.getRequestURI().contains("/loadMoney")
				|| servletRequest.getRequestURI().contains("/getCardDetails")
				|| servletRequest.getRequestURI().contains("/invoice")) {
			
			String authorization = servletRequest.getHeader("Authorization");
			if (authorization != null && jWTAuthenticationFilter.validateToken(authorization,
					servletRequest.getHeader("mobile_number"))) {
				chain.doFilter(request, response);
			} else {
				throw new BusinessException("401", "Unauthorized access");
			}
		} else{
			chain.doFilter(request, response);
		}
		
		chain.doFilter(request, response);
	}

	@Override
	public void destroy() {
		// destroy filter
	}
}*/