/**
 * 
 */
package com.no.mob.payment.common;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



/**
 * @author AB31666
 *
 */
public class CommonUtils {
	private CommonUtils(){
		//private constructor to hide implicit public one
	}

	

	private static final int NUM = 40;
	
	private static Logger log = LoggerFactory.getLogger(CommonUtils.class);
	
	/**
	 * @param inputValue
	 * @param salt
	 * @return
	 */
	public static String hashEmail(String inputValue, String salt) {
		return (DigestUtils.sha1Hex(inputValue.concat(salt)).substring(0, NUM)).toUpperCase();
	}

	public static Date dateFormater(String date)
	{
		DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy"); 
				try {
			return formatter.parse(date);
		} catch (ParseException e) {
			log.error("Exception while parsing date {}", date);
		}
		return null;

	}
	
	public static String dateFormater2(Date date)
	{
		SimpleDateFormat output = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		return output.format(date);
	
	}
	
	public static Date dateParser(String date)
	{
		SimpleDateFormat output = new SimpleDateFormat("dd MMM yyyy  HH:mm:ss");
		try {
			return output.parse(date);
		} catch (ParseException e) {
			log.error("Exception occured while parsing date {}", date);
		}
		return null;
	
	}
}
