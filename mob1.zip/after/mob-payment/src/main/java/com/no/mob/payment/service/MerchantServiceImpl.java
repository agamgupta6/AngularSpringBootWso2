package com.no.mob.payment.service;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.no.mob.payment.entity.CustomerBeaconOffer;
import com.no.mob.payment.entity.MerchantEntity;
import com.no.mob.payment.entity.PaymentView;
import com.no.mob.payment.exceptions.BusinessException;
import com.no.mob.payment.model.MerchantAccountDetailsDtoResult;
import com.no.mob.payment.model.MerchantDetailsRequestDto;
import com.no.mob.payment.repo.CustomerBeaconRepo;
import com.no.mob.payment.repo.MerchantRepo;
import com.no.mob.payment.repo.PaymentViewRepo;

@Service
public class MerchantServiceImpl implements MerchantService {

	@Autowired
	public MerchantRepo merchantRepo;

	@Autowired
	public CustomerBeaconRepo customerBeaconRepo;

	@Autowired
	public PaymentViewRepo paymentViewRepo;

	@Override
	public MerchantAccountDetailsDtoResult fetchMerchantDetailsByQrCode(
			MerchantDetailsRequestDto merchantDetailsRequestDto, String mobileNumber) {

		MerchantAccountDetailsDtoResult merchantAccountDetailsDtoResult = new MerchantAccountDetailsDtoResult();

		PaymentView customer = paymentViewRepo.findByMobileNo(mobileNumber)
				.orElseThrow(() -> new BusinessException("405", "No Customer found for given mobile number"));

		if (null != customer) {
			if (null != merchantDetailsRequestDto.getBeaconCode()) {
				 merchantRepo.findByQrCodeAndBeaconCode(merchantDetailsRequestDto.getQrCode(),
						merchantDetailsRequestDto.getBeaconCode());
			} else {
				MerchantEntity merchant = merchantRepo.findByQrCode(merchantDetailsRequestDto.getQrCode());
				if (null == merchant) {
					throw new BusinessException("405", "No Merchant Details available for given QR code");
				} else {
					CustomerBeaconOffer currentOffer = customerBeaconRepo
							.findByCustomerIdAndAccountNoAndConcent(customer.getCustomerId(), merchant.getAccountNo(), true);
					merchantAccountDetailsDtoResult.setMerchantLogo(merchant.getLogoUrl());
					merchantAccountDetailsDtoResult.setMerchantId(String.valueOf(merchant.getMerchantId()));
					merchantAccountDetailsDtoResult.setMerchantNm(merchant.getMerchantName());
					merchantAccountDetailsDtoResult.setMcc(String.valueOf(merchant.getMccCd()));
					merchantAccountDetailsDtoResult.setAccountNo(String.valueOf(merchant.getAccountNo()));
					if (null != currentOffer && currentOffer.getStatus() == 0) {
						merchantAccountDetailsDtoResult.setDiscountRate(merchant.getOfferDetails().getRate());
					} else 
					{
						merchantAccountDetailsDtoResult.setDiscountRate(new BigDecimal(0));
					}
				}
			}
		}
		return merchantAccountDetailsDtoResult;
	}
}
