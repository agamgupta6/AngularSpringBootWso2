package com.no.mob.payment.meniga.response;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CategoryData {
	 private int id;
	  private String name;
	  private String otherCategoryName;
	  private int parentCategoryId;
	  private boolean isPublic;
	  private boolean isFixedExpenses;
	  private String categoryType;
	  private String categoryRank;
	  private int budgetGenerationType;
	  private int orderId;
	  private String displayData;
}
