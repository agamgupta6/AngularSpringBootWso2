package com.no.mob.payment.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.no.mob.payment.entity.CustomerBeaconOffer;
import com.no.mob.payment.entity.CustomerConcent;
import com.no.mob.payment.entity.MerchantEntity;
import com.no.mob.payment.entity.OfferDetails;
import com.no.mob.payment.entity.PaymentView;
import com.no.mob.payment.exceptions.BusinessException;
import com.no.mob.payment.model.BeaconDetailsResponseDto;
import com.no.mob.payment.model.ConcentDetailsResponseDto;
import com.no.mob.payment.model.OfferDetailsResponseDto;
import com.no.mob.payment.repo.CustomerBeaconRepo;
import com.no.mob.payment.repo.CustomerConcentRepo;
import com.no.mob.payment.repo.MerchantRepo;
import com.no.mob.payment.repo.OfferDetailsRepo;
import com.no.mob.payment.repo.PaymentViewRepo;

@Service
public class OffersServiceImpl implements OffersService {

	private static final String ACCOUNT_DETAILS_NOT_FOUND = "Account Details Not Found";

	@Autowired
	private CustomerBeaconRepo customerBeaconRepo;

	@Autowired
	private OfferDetailsRepo offerDetailsRepo;

	@Autowired
	private MerchantRepo merchantRepo;

	@Autowired
	private PaymentViewRepo paymentViewRepo;
	
	@Autowired
	CustomerConcentRepo customerConcentRepo;

	@Override
	public OfferDetailsResponseDto fetchOfferDetails(String beaconCode, String mobileNumber) {
		OfferDetailsResponseDto beaconDetailsResponseDto = new OfferDetailsResponseDto();
		if (null != mobileNumber) {

			PaymentView paymentView = paymentViewRepo.findByMobileNo(mobileNumber)
					.orElseThrow(() -> new BusinessException("404", ACCOUNT_DETAILS_NOT_FOUND));

			if (null != beaconCode) {
				CustomerBeaconOffer customerBeaconOffer = customerBeaconRepo.findByBeaconCodeAndCustomerId(beaconCode,
						paymentView.getCustomerId());
				if (null == customerBeaconOffer) {
					OfferDetails offerDetails = offerDetailsRepo.findByBeaconCode(beaconCode);
					if (null != offerDetails) {
						MerchantEntity merchantEntity = merchantRepo.findByMerchantId(offerDetails.getMerchantId());
						CustomerConcent customerConcent = customerConcentRepo.findByCustomerIdAndMerchantId(paymentView.getCustomerId(), merchantEntity.getMerchantId()).orElseThrow(() -> new BusinessException("412","No Customer Concent Details Found"));
						if (customerConcent.getConcent()) {
							CustomerBeaconOffer beaconDetails = createCustomerBeaconOffer(offerDetails, merchantEntity,paymentView, customerConcent.getConcent());
							beaconDetailsResponseDto = createResponse(paymentView.getCustomerId(), true, beaconDetails.getCustomerOfferId());
							return beaconDetailsResponseDto;
						}
					}
				}
			}
			beaconDetailsResponseDto = createResponse(paymentView.getCustomerId(), false, 0);
		}
		return beaconDetailsResponseDto;
	}

	private OfferDetailsResponseDto createResponse(Long customerId, boolean newOfferStatus, long newAddedOffer) {
		OfferDetailsResponseDto responseDto = new OfferDetailsResponseDto();
		responseDto.setNewData(newOfferStatus);
		DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		List<CustomerBeaconOffer> offers = customerBeaconRepo.findByCustomerId(customerId).orElse(new ArrayList<>());
		List<BeaconDetailsResponseDto> offersResponse = new ArrayList<>();
		offers.forEach(beaconDetails -> {
			BeaconDetailsResponseDto beaconDetailsResponseDto = new BeaconDetailsResponseDto();
			beaconDetailsResponseDto.setAccountNo(String.valueOf(beaconDetails.getAccountNo()));
			beaconDetailsResponseDto.setCustomerId(String.valueOf(beaconDetails.getCustomerId()));
			beaconDetailsResponseDto.setDiscountRate(beaconDetails.getDiscountRate());
			beaconDetailsResponseDto.setExpiryDt(formatter.format(beaconDetails.getExpiryDt()));
			beaconDetailsResponseDto.setMerchantId(String.valueOf(beaconDetails.getMerchantId()));
			beaconDetailsResponseDto.setMerchantLogo(beaconDetails.getMerchantLogo());
			beaconDetailsResponseDto.setMerchantNm(beaconDetails.getMerchantNm());
			beaconDetailsResponseDto.setStatus(beaconDetails.getStatus() == 0);
			beaconDetailsResponseDto.setConcent(beaconDetails.getConcent());
			if(newOfferStatus && (beaconDetails.getCustomerOfferId() ==  newAddedOffer)) {
				beaconDetailsResponseDto.setNewData(newOfferStatus);				
			} else {
				beaconDetailsResponseDto.setNewData(false);
			}
			offersResponse.add(beaconDetailsResponseDto);
		});
		responseDto.setOfferDetails(offersResponse);
		return responseDto;
	}

	private CustomerBeaconOffer createCustomerBeaconOffer(OfferDetails offerDetails, MerchantEntity merchantEntity,
			PaymentView paymentView, boolean concent) {		
		CustomerBeaconOffer customerBeaconOffer = new CustomerBeaconOffer();
		customerBeaconOffer.setAccountNo(merchantEntity.getAccountNo());
		customerBeaconOffer.setBeaconCode(offerDetails.getBeaconCode());
		customerBeaconOffer.setCustomerId(paymentView.getCustomerId());
		customerBeaconOffer.setDiscountRate(offerDetails.getRate());
		customerBeaconOffer.setExpiryDt(createExpiryDate(offerDetails.getExpiryPeriod()));
		customerBeaconOffer.setMerchantId(merchantEntity.getMerchantId());
		customerBeaconOffer.setMerchantLogo(merchantEntity.getLogoUrl());
		customerBeaconOffer.setMerchantNm(merchantEntity.getMerchantName());
		customerBeaconOffer.setOfferId(offerDetails.getOfferId());
		customerBeaconOffer.setStatus(0);
		customerBeaconOffer.setConcent(concent);
		customerBeaconRepo.save(customerBeaconOffer);
		return customerBeaconOffer;
	}

	private Date createExpiryDate(int i) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, i);
		return cal.getTime();
	}

	@Override
	public OfferDetailsResponseDto setConcentDetails(String merchantId, String mobileNumber) {
		PaymentView paymentView = paymentViewRepo.findByMobileNo(mobileNumber)
				.orElseThrow(() -> new BusinessException("404", ACCOUNT_DETAILS_NOT_FOUND));
		CustomerBeaconOffer offer = customerBeaconRepo
				.findByCustomerIdAndMerchantId(paymentView.getCustomerId(), Long.valueOf(merchantId))
				.orElseThrow(() -> new BusinessException("404", "Cant find offer!"));
		offer.setConcent(true);
		customerBeaconRepo.save(offer);
		return createResponse(paymentView.getCustomerId(), true, 0);
	}

	@Override
	public List<ConcentDetailsResponseDto> updateConcentValue(boolean value, String mobileNumber, String merchantId) {
		List<ConcentDetailsResponseDto> concentDetailsResponseDtoList =  new ArrayList<>();
		PaymentView paymentView = paymentViewRepo.findByMobileNo(mobileNumber).orElseThrow(() -> new BusinessException("404", ACCOUNT_DETAILS_NOT_FOUND));
		CustomerBeaconOffer customerBeaconOffer = customerBeaconRepo.findByCustomerIdAndMerchantId(paymentView.getCustomerId(), Long.parseLong(merchantId)).orElse(null);
		CustomerConcent customerConcent = customerConcentRepo.findByCustomerIdAndMerchantId(paymentView.getCustomerId(), Long.parseLong(merchantId)).orElseThrow(() -> new BusinessException("412","No Customer Concent Details Found"));
		customerConcent.setConcent(value);
		if(null != customerBeaconOffer) {
			customerBeaconOffer.setConcent(value);
			customerBeaconRepo.save(customerBeaconOffer);
		}
		customerConcentRepo.save(customerConcent);
		List<CustomerConcent> customerConcentList = customerConcentRepo.findAllByCustomerId(paymentView.getCustomerId()).orElseThrow(() -> new BusinessException("412", "No Customer Concent Details found") );
		for (CustomerConcent Details : customerConcentList) {
			ConcentDetailsResponseDto concentDetailsResponseDto = new ConcentDetailsResponseDto();
			concentDetailsResponseDto.setMerchantId(String.valueOf(Details.getMerchantId()));
			concentDetailsResponseDto.setMerchantNm(Details.getMerchantNm());
			concentDetailsResponseDto.setMerchantLogoUrl(Details.getMerchantLogo());
			concentDetailsResponseDto.setConcent(Details.getConcent());
			concentDetailsResponseDtoList.add(concentDetailsResponseDto);
		}
		return concentDetailsResponseDtoList;
	}

}
