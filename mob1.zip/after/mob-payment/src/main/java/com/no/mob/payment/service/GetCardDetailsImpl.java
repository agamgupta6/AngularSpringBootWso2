package com.no.mob.payment.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.no.mob.payment.entity.PaymentSource;
import com.no.mob.payment.entity.PaymentView;
import com.no.mob.payment.exceptions.BusinessException;
import com.no.mob.payment.model.GetCardDetailsResponseDto;
import com.no.mob.payment.repo.CardDetailsRepo;
import com.no.mob.payment.repo.PaymentViewRepo;

@Service
public class GetCardDetailsImpl implements GetCardDetails {
	@Autowired
	private PaymentViewRepo paymentViewRepo;

	@Autowired
	private CardDetailsRepo cardDetailsRepo;

	@Override
	public List<GetCardDetailsResponseDto> getCardDetails(String mobileNumber) {

		List<GetCardDetailsResponseDto> getCardDetailsResponseDtoList = new ArrayList<>();
		PaymentView paymentView = paymentViewRepo.findByMobileNo(mobileNumber)
				.orElseThrow(() -> new BusinessException("412", "Customer not found.!"));

		List<PaymentSource> cardDetailsList = cardDetailsRepo.findByCustomerId(paymentView.getCustomerId());

		if (cardDetailsList != null) {
			for (PaymentSource cardDetails : cardDetailsList) {
				if (cardDetails != null) {
					GetCardDetailsResponseDto getCardDetailsResponseDto = new GetCardDetailsResponseDto();
					getCardDetailsResponseDto
							.setCardExpiry(new SimpleDateFormat("dd/MM/yyyy").format(cardDetails.getCardExpiry()));
					getCardDetailsResponseDto.setCardNumber(cardDetails.getCardNumber().toString());
					getCardDetailsResponseDtoList.add(getCardDetailsResponseDto);
				}
			}

		}
		return getCardDetailsResponseDtoList;
	}

}
