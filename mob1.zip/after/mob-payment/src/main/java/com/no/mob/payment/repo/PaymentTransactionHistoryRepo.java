package com.no.mob.payment.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.no.mob.payment.entity.PaymentEntity;

@Repository
public interface PaymentTransactionHistoryRepo extends CrudRepository<PaymentEntity, Long> {

	public Optional<List<PaymentEntity>> findBySenderIdOrReceiverId(Long senderId, Long receiverId);
	
	
	public Optional<List<PaymentEntity>> findBySenderId(Long cardNoForLoadMoney);


	public Optional<PaymentEntity> findByTransactionId(long parseLong);

}
