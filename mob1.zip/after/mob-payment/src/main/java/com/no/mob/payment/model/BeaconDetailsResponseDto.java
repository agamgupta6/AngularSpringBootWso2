package com.no.mob.payment.model;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BeaconDetailsResponseDto {
	private String customerId;
	private String merchantId;
	private String merchantNm;
	private String merchantLogo;
	private String accountNo;
	private BigDecimal discountRate;
	private String expiryDt;
	private boolean status;
	private boolean concent;
	private boolean newData;
}
