package com.no.mob.payment.model;

public enum CardStatus {

	ACTIVE(1), DEACTIVE(0);

	CardStatus(int i) {

	}
}
