package com.no.mob.payment.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CardDetailsRequestDto {
	@JsonProperty("card_type")
	private String cardType;
	@JsonProperty("card_number")
	private long cardNumber;
	@JsonProperty("card_expiry")
	private String cardExpiry;
	@JsonProperty("cvv")
	private int cvv2;

}
