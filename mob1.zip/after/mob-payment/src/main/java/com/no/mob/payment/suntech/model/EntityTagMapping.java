package com.no.mob.payment.suntech.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EntityTagMapping {
	
	private String etmEntityType;
	private int etmEntityVersion;
	private String etmStlUid;
	private String etmUid;
	private String stlTag;
	private String stlUid;
	private String stlWeightage;
	private String entityName;
	private String entityDescription;
	private String etmEntityCode;
	private String matchedTagCount;
	private String matchedTagList;

}
