package com.no.mob.payment.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.no.mob.payment.entity.BeneficiaryDetails;
import com.no.mob.payment.entity.PaymentView;
import com.no.mob.payment.exceptions.BusinessException;
import com.no.mob.payment.model.BeneficiaryDetailDto;
import com.no.mob.payment.model.BeneficiaryDetailsDtoResult;
import com.no.mob.payment.model.BeneficiaryRequestDto;
import com.no.mob.payment.repo.PaymentDetailsRepo;
import com.no.mob.payment.repo.PaymentViewRepo;
@Service
public class PayeeDetailsServiceImpl implements PayeeDetailsService {

	@Autowired
	private PaymentDetailsRepo paymentDetailsRepo;

	@Autowired
	private PaymentViewRepo paymentViewRepo;

	@Override
	public void addPayeeDetails(BeneficiaryRequestDto beneficiaryRequestdto,String mobileNumber) {
		BeneficiaryDetails beneficiaryDetails = new BeneficiaryDetails();
		PaymentView paymentView = paymentViewRepo.findByMobileNo(mobileNumber)
				.orElseThrow(() -> new BusinessException("412", "Account not found"));
		BeanUtils.copyProperties(beneficiaryRequestdto, beneficiaryDetails);
		beneficiaryDetails.setCustomerId(paymentView.getCustomerId());
		paymentDetailsRepo.save(beneficiaryDetails);

	}

	@Override
	public BeneficiaryDetailsDtoResult fetchPayeeDetails(String mobileNumber) {
		PaymentView paymentView = paymentViewRepo.findByMobileNo(mobileNumber)
				.orElseThrow(() -> new BusinessException("412", "Account not found"));
		BeneficiaryDetailsDtoResult beneficiaryResult = new BeneficiaryDetailsDtoResult();
		beneficiaryResult.setAccountNumber(String.valueOf(paymentView.getAccountNo()));
		beneficiaryResult.setBalanceAmount(String.valueOf(paymentView.getBalanceAmount()));
		beneficiaryResult.setQrCode(paymentView.getQrCode());

		List<BeneficiaryDetails> beneficiaryDetailsList = paymentDetailsRepo
				.findByCustomerId(paymentView.getCustomerId()).orElse(new ArrayList<>());
		List<BeneficiaryDetailDto> beneficiaryDetailDtoList = getBeneficiaryDetails(beneficiaryDetailsList);
		beneficiaryResult.setBeneficiaryDetails(beneficiaryDetailDtoList);

		return beneficiaryResult;
	}

	private List<BeneficiaryDetailDto> getBeneficiaryDetails(List<BeneficiaryDetails> beneficiaryDetailsList) {

		List<BeneficiaryDetailDto> dtoLIst = new ArrayList<>();
		beneficiaryDetailsList.forEach(beneficiaryDetail -> {
			BeneficiaryDetailDto dto = new BeneficiaryDetailDto();
			BeanUtils.copyProperties(beneficiaryDetail, dto);
			PaymentView paymentView = paymentViewRepo.findByAccountNo(beneficiaryDetail.getAccountNumber()).orElse(null);
			if(null != paymentView) {
				dto.setQrCode(paymentView.getQrCode());
			}
			dtoLIst.add(dto);
		});
		return dtoLIst;
	}

	
}
