package com.no.mob.payment.suntech.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SuntechIntegrationRequestDto {
	private String entityType = "P";
	private String searchTag;

}
