package com.no.mob.payment.common;

public class PaymentConstant {
	
	private PaymentConstant(){
		// private constructor
	}
	
	public static final String CARD_TYPE_NEW = "new";
	public static final String PAYMENT_TYPE_INVOICE = "INVOICE";
	public static final String PAYMENT_TYPE_P2P = "P2P";
	public static final String MOB_CUSTOMER_ID = "9999";
	public static final String P2B = "P2B";
}
	