package com.no.mob.payment.service;

import static com.no.mob.payment.common.PaymentConstant.CARD_TYPE_NEW;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.no.mob.payment.entity.PaymentEntity;
import com.no.mob.payment.entity.PaymentSource;
import com.no.mob.payment.entity.PaymentView;
import com.no.mob.payment.exceptions.BusinessException;
import com.no.mob.payment.model.CreditRequestDto;
import com.no.mob.payment.model.LoadMoneyRequestDto;
import com.no.mob.payment.model.PaymentRequest;
import com.no.mob.payment.model.PaymentTransferRequestDto;
import com.no.mob.payment.model.ResponseInfo;
import com.no.mob.payment.model.TransferServiceResponseDto;
import com.no.mob.payment.repo.PaymentRepo;
import com.no.mob.payment.repo.PaymentSourceRepo;
import com.no.mob.payment.repo.PaymentViewRepo;
import com.no.mob.payment.util.CurrencyConverter;
import com.no.mob.payment.util.TransactionsUtil;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class LoadMoneyTransactionServiceImpl implements LoadMoneyTransactionService {

	@Autowired
	private PaymentViewRepo paymentViewRepo;

	@Autowired
	private PaymentSourceRepo paymentSourceRepo;

	@Autowired
	private PaymentRepo paymentRepo;

	@Value("${debit.virtual.account.uri}")
	private String debitVirtualAccountUri = null;

	@Value("${credit.account.uri}")
	private String creditAccountUri = null;

	@Autowired
	RestTemplate restTemplate;

	@Value("${mob.to.other.payment.uri}")
	private String mob2OtherUri;

	@Value("${validate.virtual.card.uri}")
	private String validateVirtualCardUri;

	@Autowired
	private TransactionsUtil transactionsUtil;

	@Autowired
	private CurrencyConverter currencyConverter;

	@Override
	public TransferServiceResponseDto loadMoneyInAccount(LoadMoneyRequestDto loadMoneyRequestDto, String mobileNumber,
			String accessToken) {
		TransferServiceResponseDto transferServiceResponseDto = new TransferServiceResponseDto();
		List<PaymentSource> paymentSourceList = null;
		PaymentSource paymentSource = new PaymentSource();
		CreditRequestDto creditRequestDto = new CreditRequestDto();
		PaymentEntity paymentEntity = new PaymentEntity();
		PaymentTransferRequestDto paymentTransferRequestDto = new PaymentTransferRequestDto();
		Date expiryDate = null;
		try {
			expiryDate = new SimpleDateFormat("dd/MM/yyyy").parse(loadMoneyRequestDto.getCardDetails().getCardExpiry());
		} catch (ParseException e1) {
			throw new BusinessException("406", "Invalid date format");
		}
		// 1.validate customer
		PaymentView payment = paymentViewRepo.findByMobileNo(mobileNumber)
				.orElseThrow(() -> new BusinessException("422", "Customer not found.!"));
		log.info("card type is:" + loadMoneyRequestDto.getCardDetails().getCardType());
		if (expiryDate.before(new Date())) {
			throw new BusinessException("406", "Card Expired");
		}
		paymentSourceList = paymentSourceRepo.findByCardNumber(loadMoneyRequestDto.getCardDetails().getCardNumber())
				.orElse(new ArrayList<>());
		if (CollectionUtils.isEmpty(paymentSourceList)
				&& CARD_TYPE_NEW.equalsIgnoreCase(loadMoneyRequestDto.getCardDetails().getCardType())) {
			// save payment source details to payment source table
			log.info("saving external card details");
			paymentSource.setCustomerId(payment.getCustomerId());
			paymentSource.setActiveIn('Y');
			paymentSource.setCreatedDt(new Timestamp(System.currentTimeMillis()));
			paymentSource.setCardNumber(loadMoneyRequestDto.getCardDetails().getCardNumber());
			paymentSource.setCardExpiry(expiryDate);
			paymentSourceRepo.save(paymentSource);
		}
		// 2.validate card details(call internal card validate to account
		// microservice)
		log.info("Card number = {}", loadMoneyRequestDto.getCardDetails().getCardNumber());
		// call internal debit service(if virtual card)
		PaymentView cardDetailSender = paymentViewRepo
				.findByCardNo(String.valueOf(loadMoneyRequestDto.getCardDetails().getCardNumber())).orElse(null);
		BigDecimal amountToDebit = loadMoneyRequestDto.getAmount();
		if (null != cardDetailSender) {
			log.info("debiting balance");
			validateVirtualCard(validateVirtualCardUri, mobileNumber, accessToken, cardDetailSender.getCardNo(),
					loadMoneyRequestDto.getCardDetails().getCvv2());
			if (checkCurrencyCheckRequired(loadMoneyRequestDto.getCurrency(), cardDetailSender.getCountryCd())) {
				amountToDebit = currencyConverter.convertRequestedAmount(loadMoneyRequestDto.getAmount(),
						loadMoneyRequestDto.getCurrency(), cardDetailSender.getCountryCd());
			}
			creditRequestDto.setAccountNo(String.valueOf(cardDetailSender.getAccountNo()));

			debitBalance(debitVirtualAccountUri, mobileNumber, accessToken, creditRequestDto, amountToDebit);
		} else {
			// TBD currency conversion needed
			paymentTransferRequestDto.setAmount(amountToDebit);
			paymentTransferRequestDto.setCardNumber(loadMoneyRequestDto.getCardDetails().getCardNumber());
			paymentTransferRequestDto.setTargetAccountNo(Long.parseLong(payment.getAccountNo()));
			paymentTransferRequestDto.setTransactionTxt("Debiting from Account");
			paymentTransferRequestDto.setCountryCode(loadMoneyRequestDto.getCurrency());
			try {
				debitAmountFromExternalCard(mob2OtherUri, paymentTransferRequestDto);
			} catch (Exception e) {
				throw new BusinessException("410", "debit Account failed");
			}

		}
		log.info("crediting balance");
		creditRequestDto.setAccountNo(String.valueOf(payment.getAccountNo()));
		BigDecimal amountToCredit = loadMoneyRequestDto.getAmount();

		if (checkCurrencyCheckRequired(loadMoneyRequestDto.getCurrency(), payment.getCountryCd())) {
			amountToCredit = currencyConverter.convertRequestedAmount(loadMoneyRequestDto.getAmount(),
					loadMoneyRequestDto.getCurrency(), payment.getCountryCd());
		}
		creditBalance(creditAccountUri, mobileNumber, accessToken, creditRequestDto, amountToCredit);
		log.info("saving transaction ");
		paymentEntity = saveTransaction(loadMoneyRequestDto, paymentEntity, payment);
		return createResponse(transferServiceResponseDto, paymentEntity, loadMoneyRequestDto, payment);
	}

	private TransferServiceResponseDto createResponse(TransferServiceResponseDto transferServiceResponseDto,
			PaymentEntity paymentEntity, LoadMoneyRequestDto loadMoneyRequestDto, PaymentView payment) {
		transferServiceResponseDto.setTransactionId(paymentEntity.getTransactionId().toString());
		transferServiceResponseDto.setType("Fabby");
		transferServiceResponseDto.setStatus(TransactionsUtil.checkTransactionStatus(paymentEntity.getPaymentStatus()));
		transferServiceResponseDto.setCategory(TransactionsUtil.checkCategory(paymentEntity.getTransactionType()));
		transferServiceResponseDto.setLogoUrl("");
		transferServiceResponseDto.setAmount(paymentEntity.getTransactionAmount().toString());
		transferServiceResponseDto.setDate(paymentEntity.getCreatedDt().getTime());
		transferServiceResponseDto.setName(transactionsUtil.populateNameOrAccountNo(payment.getCustomerId()));
		transferServiceResponseDto.setAccountNumber(payment.getAccountNo());
		transferServiceResponseDto
				.setPaymentSource(String.valueOf(loadMoneyRequestDto.getCardDetails().getCardNumber()).trim());
		return transferServiceResponseDto;
	}

	private PaymentEntity saveTransaction(LoadMoneyRequestDto loadMoneyRequestDto, PaymentEntity paymentEntity,
			PaymentView payment) {
		paymentEntity.setCountryCode(loadMoneyRequestDto.getCurrency());
		paymentEntity.setBankAccountId(payment.getAccountId());
		paymentEntity.setSenderId(loadMoneyRequestDto.getCardDetails().getCardNumber());
		paymentEntity.setReceiverId(payment.getCustomerId());
		paymentEntity.setPaymentType("P2P");
		paymentEntity.setTransactionType(2);
		paymentEntity.setTransactionAmount(loadMoneyRequestDto.getAmount());
		paymentEntity.setTransactionText("Load Money to Card");
		paymentEntity.setPaymentStatus(101);
		paymentEntity.setCreatedDt(new Date());
		paymentEntity.setUpdatedDt(new Date());
		return paymentRepo.save(paymentEntity);
	}

	private boolean checkCurrencyCheckRequired(String sourceCountryCode, String countryCd) {
		return !sourceCountryCode.equals(countryCd);
	}

	private void debitBalance(String debitVirtualAccountUri, String mobileNumber, String token,
			CreditRequestDto creditRequestDto, BigDecimal amount) {

		HttpHeaders httpHeaders = setCommonHeaders(mobileNumber, token);

		JSONObject json = new JSONObject();
		try {
			json.put("amount", amount);
			json.put("accountNo", creditRequestDto.getAccountNo());
		} catch (JSONException e) {
			log.error("JSONException" + e);
		}
		HttpEntity<String> httpEntity = new HttpEntity<>(json.toString(), httpHeaders);
		try {
			restTemplate.postForObject(debitVirtualAccountUri, httpEntity, String.class);
		} catch (Exception e) {
			throw new BusinessException("410", "debit Account failed");
		}

	}

	private HttpHeaders setCommonHeaders(String mobileNumber, String token) {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.set("Content-Type", "application/json");
		httpHeaders.set("Authorization", token);
		httpHeaders.set("mobile_number", mobileNumber);
		return httpHeaders;
	}

	private void validateVirtualCard(String validateVirtualCardUri, String mobileNumber, String token, String cardNo,
			int cvv) {

		JSONObject json = new JSONObject();
		try {
			json.put("cardNo", cardNo);
			json.put("cvv", cvv);
		} catch (JSONException e) {
			log.error("JSONException occured with exception {}", e.getMessage());
		}

		HttpHeaders httpHeaders = setCommonHeaders(mobileNumber, token);
		HttpEntity<String> httpEntity = new HttpEntity<>(json.toString(), httpHeaders);
		try {
			restTemplate.postForObject(validateVirtualCardUri, httpEntity, String.class);
		} catch (HttpClientErrorException ex) {
			throw new BusinessException(String.valueOf(ex.getStatusCode().value()),
					ex.getMessage());
		}
	}

	private void creditBalance(String creditAccountUri, String mobileNumber, String token,
			CreditRequestDto creditRequestDto, BigDecimal amount) {
		HttpEntity<String> httpEntity;
		HttpHeaders httpHeaders = setCommonHeaders(mobileNumber, token);

		JSONObject json = new JSONObject();
		try {
			json.put("amount", amount);
			json.put("accountNo", creditRequestDto.getAccountNo());
		} catch (JSONException e) {
			log.error("JSONException occured :{}", e.getMessage());
		}
		httpEntity = new HttpEntity<>(json.toString(), httpHeaders);
		restTemplate.postForObject(creditAccountUri, httpEntity, String.class);

	}

	private ResponseEntity<ResponseInfo> debitAmountFromExternalCard(String mob2OtherUri,
			PaymentTransferRequestDto paymentTransferRequestDto) {
		HttpEntity<PaymentRequest> request = new HttpEntity<>(createPaymentRequest(paymentTransferRequestDto));
		return restTemplate.exchange(mob2OtherUri, HttpMethod.POST, request, ResponseInfo.class);
	}

	private PaymentRequest createPaymentRequest(PaymentTransferRequestDto paymentTransferRequestDto) {
		PaymentRequest paymentRequest = new PaymentRequest();
		paymentRequest.setAmount(paymentTransferRequestDto.getAmount());
		paymentRequest.setCreated(new Date());
		paymentRequest.setCurrency(paymentTransferRequestDto.getCountryCode());
		paymentRequest.setReference(paymentTransferRequestDto.getTransactionTxt());
		paymentRequest.setSwift(paymentTransferRequestDto.getSwiftCode());
		paymentRequest.setTargetAccount(paymentTransferRequestDto.getTargetAccountNo());
		paymentRequest.setCardNumber(paymentTransferRequestDto.getCardNumber());
		paymentRequest.setTransferRequest("");
		return paymentRequest;
	}

}