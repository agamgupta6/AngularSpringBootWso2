package com.no.mob.payment.util;

import static com.no.mob.payment.common.PaymentConstant.MOB_CUSTOMER_ID;
import static com.no.mob.payment.common.PaymentConstant.PAYMENT_TYPE_INVOICE;
import static com.no.mob.payment.common.PaymentConstant.PAYMENT_TYPE_P2P;
import static com.no.mob.payment.common.PaymentConstant.P2B;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.no.mob.payment.entity.BeneficiaryDetails;
import com.no.mob.payment.entity.ExternalPaymentCard;
import com.no.mob.payment.entity.MerchantEntity;
import com.no.mob.payment.entity.PaymentEntity;
import com.no.mob.payment.entity.PaymentView;
import com.no.mob.payment.repo.ExternalCardRepo;
import com.no.mob.payment.repo.MerchantRepo;
import com.no.mob.payment.repo.PaymentDetailsRepo;
import com.no.mob.payment.repo.PaymentViewRepo;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class TransactionsUtil {

	private static final String XXXX_XXX = "xxxx xxx ";

	private static final int ZERO = 0;

	@Autowired
	private PaymentViewRepo paymentViewRepo;

	@Autowired
	private PaymentDetailsRepo paymentDetailsRepo;

	@Autowired
	private MerchantRepo merchantRepo;

	@Autowired
	private ExternalCardRepo cardRepo;

	private static final int NUMBERZERO = 0;

	public static String checkTransactionStatus(int paymentStatus) {
		if (NUMBERZERO != paymentStatus) {
			if (paymentStatus == 101) {
				return "Success";
			}
			if (paymentStatus == 102) {
				return "Failed";
			}
			if (paymentStatus == 103) {
				return "Pending";
			}
		}
		return null;
	}

	public static String checkCategory(int transactionType) {
		if (NUMBERZERO != transactionType) {
			if (transactionType == 2) {
				return "PEER";
			} else {
				return "SHOPPING";
			}
		} else {
			return null;
		}
	}

	public String populateNameOrAccountNo(Long receiverId) {
		if (!(null == receiverId || ZERO == receiverId)) {
			List<PaymentView> receiverDetails = paymentViewRepo.findByCustomerId(receiverId).orElse(new ArrayList<>());
			if (!CollectionUtils.isEmpty(receiverDetails)) {
				return receiverDetails.get(0).getFirstName() + " " + receiverDetails.get(0).getLastName();
			} else {
				Optional<BeneficiaryDetails> beneficiaryDetails = paymentDetailsRepo.findByPayeeId(receiverId);
				if (beneficiaryDetails.isPresent()) {
					return beneficiaryDetails.get().getPayeeName();
				}
			}
		}
		return "";
	}

	public String populatePaymentSource(PaymentView customerPaymentDetails, PaymentEntity transactionDetails) {
		log.info("populating payment source with payment entity {}", transactionDetails.toString());
		String paymentSource = null;
		if (customerPaymentDetails.getCustomerId().toString().equals(transactionDetails.getSenderId().toString())
				&& PAYMENT_TYPE_INVOICE.equals(transactionDetails.getPaymentType())) {
			log.info("populating payment source for Invoice payments");
			if ( transactionDetails.getCardId() == null || transactionDetails.getCardId() == 0L ) {
				String accountNumber = customerPaymentDetails.getAccountNo();
				paymentSource = XXXX_XXX + accountNumber.substring(accountNumber.length() - 4, accountNumber.length());
			} else {
				ExternalPaymentCard externalPaymentCard = cardRepo.findByPaymentCardId(transactionDetails.getCardId())
						.orElse(null);
				
				if (externalPaymentCard != null) {
					log.info("card details = {}",externalPaymentCard.toString());
					paymentSource = externalPaymentCard.getCardNumber();
				}
			}
		} else if (!(customerPaymentDetails.getCustomerId().toString()
				.equals(transactionDetails.getSenderId().toString()))
				&& PAYMENT_TYPE_P2P.equals(transactionDetails.getPaymentType())) {
			log.info("populating payment source for P2P payments");
			if (transactionDetails.getSenderId().toString().equals(MOB_CUSTOMER_ID)) {
				paymentSource = "Fabby";
			} else {
				log.info("populating payment source for P2P payments via load money");
				String cardNo = transactionDetails.getSenderId().toString();
				paymentSource = "xxxx xxxx xxxx " + cardNo.substring(cardNo.length() - 4, cardNo.length());
			}
		} else if (customerPaymentDetails.getCustomerId().toString().equals(transactionDetails.getSenderId().toString())
				&& PAYMENT_TYPE_P2P.equals(transactionDetails.getPaymentType())) {
			log.info("populating payment source for P2P payments via mob to mob or mob to others");
			String accountNumber = customerPaymentDetails.getAccountNo();
			paymentSource = XXXX_XXX + accountNumber.substring(accountNumber.length() - 4, accountNumber.length());
		} else if (customerPaymentDetails.getCustomerId().toString().equals(transactionDetails.getSenderId().toString())
				&& P2B.equals(transactionDetails.getPaymentType())) {
			log.info("populating payment source for P2B payments");
			if (transactionDetails.getCardId() == null || transactionDetails.getCardId() == 0L) {
				String accountNumber = customerPaymentDetails.getAccountNo();
				paymentSource = XXXX_XXX + accountNumber.substring(accountNumber.length() - 4, accountNumber.length());
			} else {
				ExternalPaymentCard externalPaymentCard = cardRepo.findByPaymentCardId(transactionDetails.getCardId())
						.orElse(null);
				if (externalPaymentCard != null) {
					log.info("card details = {}", externalPaymentCard.toString());
					paymentSource = externalPaymentCard.getCardNumber();
				}
			}
		}
		return paymentSource;
	}

	public String populateReceiverName(PaymentView customerPaymentDetails, PaymentEntity transactionDetails) {
		log.info("populating receiver name");
		String name = null;
		if (customerPaymentDetails.getCustomerId().toString().equals(transactionDetails.getSenderId().toString())
				&& PAYMENT_TYPE_INVOICE.equals(transactionDetails.getPaymentType())) {
			log.info("populating receiver name for invoice payments");
			name = transactionDetails.getReceiverId().toString();
		} else if (customerPaymentDetails.getCustomerId().toString().equals(transactionDetails.getSenderId().toString())
				&& P2B.equals(transactionDetails.getPaymentType())) {
			log.info("populating receiver name for Merchant payments");
			MerchantEntity merchantEntity = merchantRepo.findByAccountNo(transactionDetails.getReceiverId());
			name = merchantEntity.getMerchantName();
		} else if (!(customerPaymentDetails.getCustomerId().toString()
				.equals(transactionDetails.getSenderId().toString()))
				&& PAYMENT_TYPE_P2P.equals(transactionDetails.getPaymentType())) {
			log.info("populating receiver name for p2p payments");
			name = customerPaymentDetails.getFirstName() + " " + customerPaymentDetails.getLastName();
		} else if (customerPaymentDetails.getCustomerId().toString().equals(transactionDetails.getSenderId().toString())
				&& PAYMENT_TYPE_P2P.equals(transactionDetails.getPaymentType())) {
			log.info("p2p transaction");
			PaymentView receiverDetails = paymentViewRepo.findReceiverByCustomerId(transactionDetails.getReceiverId())
					.orElse(null);
			if (null == receiverDetails) {
				log.info("p2p transaction fetching beneficiary details");
				BeneficiaryDetails beneficiaryDetails = paymentDetailsRepo
						.findByPayeeId(transactionDetails.getReceiverId()).orElse(null);

				if (beneficiaryDetails != null)
					name = beneficiaryDetails.getPayeeName();
			} else {
				log.info("populating receiver name for p2p payments via mob to mob");
				name = receiverDetails.getFirstName() + " " + receiverDetails.getLastName();
			}
		}
		return name;
	}

	public String populateAccountNumber(PaymentView customerPaymentDetails, PaymentEntity transactionDetails) {
		log.info("populating account number");
		String accountNumber = null;
		if (customerPaymentDetails.getCustomerId().toString().equals(transactionDetails.getSenderId().toString())
				&& PAYMENT_TYPE_P2P.equals(transactionDetails.getPaymentType())) {
			PaymentView receiverDetails = paymentViewRepo.findReceiverByCustomerId(transactionDetails.getReceiverId())
					.orElse(null);
			if (null == receiverDetails) {
				log.info("populating account number for mob to others");
				BeneficiaryDetails beneficiaryDetails = paymentDetailsRepo
						.findByPayeeId(transactionDetails.getReceiverId()).orElse(null);
				if (beneficiaryDetails != null) {
					String accNo = beneficiaryDetails.getAccountNumber();
					accountNumber = XXXX_XXX + accNo.substring(accNo.length() - 4, accNo.length());
				}
			} else {
				log.info("populating account number for mob to mob");
				String accNo = receiverDetails.getAccountNo();
				accountNumber = XXXX_XXX + accNo.substring(accNo.length() - 4, accNo.length());
			}
		} else if (customerPaymentDetails.getCustomerId().toString().equals(transactionDetails.getSenderId().toString())
				&& PAYMENT_TYPE_INVOICE.equals(transactionDetails.getPaymentType())) {
			log.info("populating account number for invoice payments");
			String accNo = transactionDetails.getReceiverId().toString();
			accountNumber = XXXX_XXX + accNo.substring(accNo.length() - 4, accNo.length());
		} else if (customerPaymentDetails.getCustomerId().toString().equals(transactionDetails.getSenderId().toString())
				&& P2B.equals(transactionDetails.getPaymentType())) {
			log.info("populating account number for merchant payments");
			String accNo = transactionDetails.getReceiverId().toString();
			accountNumber = XXXX_XXX + accNo.substring(accNo.length() - 4, accNo.length());
		} else if (!(customerPaymentDetails.getCustomerId().toString()
				.equals(transactionDetails.getSenderId().toString()))
				&& PAYMENT_TYPE_P2P.equals(transactionDetails.getPaymentType())) {
			log.info("populating account number for load money");
			String accNo = customerPaymentDetails.getAccountNo();
			accountNumber = XXXX_XXX + accNo.substring(accNo.length() - 4, accNo.length());
		}
		return accountNumber;
	}

}
