package com.no.mob.payment.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.no.mob.payment.util.AccountNumberFormatter;

import lombok.Getter;
import lombok.Setter;

/**
 * BeneficiaryDetailsDtoResult
 */

@Getter
@Setter
public class BeneficiaryDetailsDtoResult   {
  @JsonProperty("accountNumber")
  private String accountNumber = null;
  
  @JsonProperty("balanceAmount")
  private String balanceAmount = null;

  @JsonProperty("beneficiaryDetails")
  private List<BeneficiaryDetailDto> beneficiaryDetails = null;
  
  @JsonProperty("qrCode")
  private String qrCode;

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = AccountNumberFormatter.getFormattedNumber(accountNumber);
	}
   
}

