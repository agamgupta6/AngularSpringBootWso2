package com.no.mob.payment.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BeneficiaryRequestDto {
	
	
	  private String mobileNumber;

	  private String countryCode ;
	  
	  private String accountNumber;
	  
	  private String payeeName;
	 
	  private String swiftCode;

}
