package com.no.mob.payment.repo;

import org.springframework.data.repository.CrudRepository;

import com.no.mob.payment.entity.OfferDetails;

public interface OfferDetailsRepo extends CrudRepository<OfferDetails, Long>{

	public OfferDetails findByBeaconCode(String beaconCode);

}
