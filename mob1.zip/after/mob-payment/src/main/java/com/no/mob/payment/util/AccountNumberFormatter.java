package com.no.mob.payment.util;

import java.util.StringJoiner;

public class AccountNumberFormatter {
	
	private AccountNumberFormatter() {
		// private constructor
	}
	
	public static String getFormattedNumber(String number){
		
		StringJoiner sj = new StringJoiner(".");

        sj.add(number.substring(0, 4)).add(number.substring(4,6)).add(number.substring(6, number.length()));

        return sj.toString();

		
	}

}
