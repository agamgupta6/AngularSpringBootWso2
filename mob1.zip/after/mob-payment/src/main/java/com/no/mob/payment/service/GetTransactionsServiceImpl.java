package com.no.mob.payment.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.no.mob.payment.entity.BeneficiaryDetails;
import com.no.mob.payment.entity.ExternalPaymentCard;
import com.no.mob.payment.entity.MerchantEntity;
import com.no.mob.payment.entity.PaymentEntity;
import com.no.mob.payment.entity.PaymentSource;
import com.no.mob.payment.entity.PaymentView;
import com.no.mob.payment.exceptions.BusinessException;
import com.no.mob.payment.model.TransactionHistoryResponseDtoResult;
import com.no.mob.payment.model.TransactionHistoryResponseDtoResultTransactions;
import com.no.mob.payment.repo.ExternalCardRepo;
import com.no.mob.payment.repo.MerchantRepo;
import com.no.mob.payment.repo.PaymentDetailsRepo;
import com.no.mob.payment.repo.PaymentSourceRepo;
import com.no.mob.payment.repo.PaymentTransactionHistoryRepo;
import com.no.mob.payment.repo.PaymentViewRepo;
import com.no.mob.payment.util.TransactionsUtil;

@Service
public class GetTransactionsServiceImpl implements GetTransactions {

	@Autowired
	private PaymentTransactionHistoryRepo paymentTransactionHistoryRepo;

	private static final long ZERO = 0;

	private static final int NUMBERZERO = 0;

	@Autowired
	private PaymentViewRepo paymentViewRepo;

	@Autowired
	private PaymentSourceRepo paymentSourceRepo;

	@Autowired
	private PaymentDetailsRepo paymentDetailsRepo;

	@Autowired
	private TransactionsUtil transactionsUtil;

	@Autowired
	private MerchantRepo merchantRepo;

	@Autowired
	private ExternalCardRepo cardRepo;

	@Value("${load.money.sender}")
	private String loadMoneySender;

	private Logger log = LoggerFactory.getLogger(this.getClass());

	@Override
	public TransactionHistoryResponseDtoResult getTransactionHistorydetails(String mobileNumber) {

		log.info("Entering getTransactionHistorydetails Method for transaction history={}", mobileNumber);

		inputValidations(mobileNumber);

		PaymentView customerActive = mobileNumberValidation(mobileNumber);

		if (!customerActive.getStatusId().equals("1")) {
			throw new BusinessException("413", "InActive Customer");
		}

		return getPaymentTransaction(customerActive.getCustomerId());

	}

	private TransactionHistoryResponseDtoResult getPaymentTransaction(Long customerId) {

		TransactionHistoryResponseDtoResult transactionHistoryResponseDtoResult = new TransactionHistoryResponseDtoResult();
		List<PaymentEntity> paymentEntityList = paymentTransactionHistoryRepo
				.findBySenderIdOrReceiverId(customerId, customerId).orElse(new ArrayList<>());

		List<PaymentView> paymentViewForLoadMoney = paymentViewRepo.findByCustomerId(customerId)
				.orElse(new ArrayList<>());

		List<PaymentEntity> paymentEntityListForLoadMoney = paymentTransactionHistoryRepo
				.findBySenderId(Long.valueOf(paymentViewForLoadMoney.get(0).getCardNo())).orElse(new ArrayList<>());

		paymentEntityList.addAll(paymentEntityListForLoadMoney);
		Collections.sort(paymentEntityList, (o1, o2) -> o2.getCreatedDt().compareTo(o1.getCreatedDt()));

		paymentEntityList.forEach(paymentTransaction -> generateTransactionHistory(customerId,
				transactionHistoryResponseDtoResult, paymentViewForLoadMoney, paymentTransaction));

		return transactionHistoryResponseDtoResult;

	}

	private void generateTransactionHistory(Long customerId,
			TransactionHistoryResponseDtoResult transactionHistoryResponseDtoResult,
			List<PaymentView> paymentViewForLoadMoney, PaymentEntity paymentTransaction) {
		TransactionHistoryResponseDtoResultTransactions transactionHistoryResponseDtoResultTransactions = new TransactionHistoryResponseDtoResultTransactions();
		if (null != paymentTransaction.getUpdatedDt()) {
			transactionHistoryResponseDtoResultTransactions.setDate(paymentTransaction.getUpdatedDt().getTime());
		}

		populateTransactionAmtAndCurrency(paymentTransaction, transactionHistoryResponseDtoResultTransactions);

		populateTransactionCategory(paymentTransaction, transactionHistoryResponseDtoResultTransactions);

		if (ZERO != paymentTransaction.getSenderId()) {
			populateReceiverName(customerId, transactionHistoryResponseDtoResultTransactions, paymentTransaction,
					paymentViewForLoadMoney);
		}

		if (ZERO != paymentTransaction.getReceiverId()) {
			populateSenderName(customerId, transactionHistoryResponseDtoResultTransactions, paymentTransaction);
		}

		setTransactionStatus(paymentTransaction, transactionHistoryResponseDtoResultTransactions);

		log.info("payment transaction details -> {}", paymentTransaction.toString());
		if (paymentTransaction.getCardId() == null || paymentTransaction.getCardId() == 0L) {
			transactionHistoryResponseDtoResultTransactions.setType("Fabby");
		} else {
			ExternalPaymentCard externalPaymentCard = cardRepo.findByPaymentCardId(paymentTransaction.getCardId())
					.orElse(null);
			if (externalPaymentCard != null) {
				transactionHistoryResponseDtoResultTransactions.setType(externalPaymentCard.getCardName());
			}
		}
		transactionHistoryResponseDtoResultTransactions
				.setTransactionId(paymentTransaction.getTransactionId().toString());
		transactionHistoryResponseDtoResult.addTransactionsItem(transactionHistoryResponseDtoResultTransactions);
	}

	private void populateTransactionAmtAndCurrency(PaymentEntity paymentTransaction,
			TransactionHistoryResponseDtoResultTransactions transactionHistoryResponseDtoResultTransactions) {
		if (null != paymentTransaction.getTransactionAmount() && null != paymentTransaction.getCountryCode()) {

			transactionHistoryResponseDtoResultTransactions
					.setAmount(String.valueOf(paymentTransaction.getTransactionAmount()));

			transactionHistoryResponseDtoResultTransactions.setCountryCode(paymentTransaction.getCountryCode());
		}
	}

	private void populateTransactionCategory(PaymentEntity paymentTransaction,
			TransactionHistoryResponseDtoResultTransactions transactionHistoryResponseDtoResultTransactions) {
		if (NUMBERZERO != paymentTransaction.getTransactionType()) {
			if (paymentTransaction.getTransactionType() == 2) {

				transactionHistoryResponseDtoResultTransactions.setCategory("peer");
			} else {
				transactionHistoryResponseDtoResultTransactions.setCategory("shopping");
			}
		}
	}

	private void setTransactionStatus(PaymentEntity paymentTransaction,
			TransactionHistoryResponseDtoResultTransactions transactionHistoryResponseDtoResultTransactions) {
		if (NUMBERZERO != paymentTransaction.getPaymentStatus()) {
			if (paymentTransaction.getPaymentStatus() == 101) {
				transactionHistoryResponseDtoResultTransactions.setStatus("Success");
			}

			if (paymentTransaction.getPaymentStatus() == 102) {
				transactionHistoryResponseDtoResultTransactions.setStatus("Failed");
			}

			if (paymentTransaction.getPaymentStatus() == 103) {
				transactionHistoryResponseDtoResultTransactions.setStatus("Pending");
			}

		}
	}

	private void populateSenderName(Long customerId,
			TransactionHistoryResponseDtoResultTransactions transactionHistoryResponseDtoResultTransactions,
			PaymentEntity paymentTransaction) {
		if (customerId.equals(paymentTransaction.getReceiverId())) {

			List<PaymentView> senderDetails = paymentViewRepo.findByCustomerId(paymentTransaction.getSenderId())
					.orElse(new ArrayList<>());
			if (!CollectionUtils.isEmpty(senderDetails)) {
				transactionHistoryResponseDtoResultTransactions.transferType("Cr");

				transactionHistoryResponseDtoResultTransactions
						.setName(senderDetails.get(0).getFirstName() + " " + senderDetails.get(0).getLastName());
			} else {

				List<PaymentSource> paymentSourceDetails = paymentSourceRepo
						.findByCardNumber(paymentTransaction.getSenderId()).orElse(new ArrayList<>());
				if (!CollectionUtils.isEmpty(paymentSourceDetails)) {

					String cardNumber = String.valueOf(paymentSourceDetails.get(0).getCardNumber());
					String loadMoneycardNumber = cardNumber.substring(cardNumber.length() - 4, cardNumber.length());
					transactionHistoryResponseDtoResultTransactions
							.setName(loadMoneySender + " " + loadMoneycardNumber);
					log.info("load money sender name = {} with card no {}", loadMoneySender, loadMoneycardNumber);
					transactionHistoryResponseDtoResultTransactions.transferType("Cr");
				}
			}

		}
	}

	private void populateReceiverName(Long customerId,
			TransactionHistoryResponseDtoResultTransactions transactionHistoryResponseDtoResultTransactions,
			PaymentEntity paymentTransaction, List<PaymentView> paymentViewForLoadMoney) {

		log.info("populating receiver name");
		populateReceiverNameForNormalTransactions(customerId, transactionHistoryResponseDtoResultTransactions,
				paymentTransaction);
		populateReceiverNameForLoadMoney(customerId, transactionHistoryResponseDtoResultTransactions,
				paymentTransaction, paymentViewForLoadMoney);
	}

	private void populateReceiverNameForNormalTransactions(Long customerId,
			TransactionHistoryResponseDtoResultTransactions transactionHistoryResponseDtoResultTransactions,
			PaymentEntity paymentTransaction) {
		if (customerId.equals(paymentTransaction.getSenderId())) {
			log.info("senderID= {}, ReceiverID = {}", paymentTransaction.getSenderId(), customerId);

			List<PaymentView> receiverDetails = paymentViewRepo.findByCustomerId(paymentTransaction.getReceiverId())
					.orElse(new ArrayList<>());

			if (!CollectionUtils.isEmpty(receiverDetails)) {
				transactionHistoryResponseDtoResultTransactions.transferType("Dr");
				transactionHistoryResponseDtoResultTransactions
						.setName(receiverDetails.get(0).getFirstName() + " " + receiverDetails.get(0).getLastName());
			} else {

				List<BeneficiaryDetails> beneficiaryDetails = paymentDetailsRepo
						.findByPayeeIdOrAccountNumber(paymentTransaction.getReceiverId(),
								String.valueOf(paymentTransaction.getReceiverId()))
						.orElse(new ArrayList<>());
				if (!CollectionUtils.isEmpty(beneficiaryDetails)) {
					transactionHistoryResponseDtoResultTransactions.transferType("Dr");
					transactionHistoryResponseDtoResultTransactions.setName(beneficiaryDetails.get(0).getPayeeName());
				} else {
					MerchantEntity merchantEntity = merchantRepo.findByAccountNo(paymentTransaction.getReceiverId());
					if (null == merchantEntity) {
						transactionHistoryResponseDtoResultTransactions.transferType("Dr");
						transactionHistoryResponseDtoResultTransactions.setName("Merchant Payment");
					} else {
						transactionHistoryResponseDtoResultTransactions.transferType("Dr");
						transactionHistoryResponseDtoResultTransactions
								.setName("Payment Made To " + merchantEntity.getMerchantName());
					}

				}
			}
		}
	}

	private void populateReceiverNameForLoadMoney(Long customerId,
			TransactionHistoryResponseDtoResultTransactions transactionHistoryResponseDtoResultTransactions,
			PaymentEntity paymentTransaction, List<PaymentView> paymentViewForLoadMoney) {
		if ((!customerId.equals(paymentTransaction.getSenderId()))
				&& paymentTransaction.getSenderId().toString().equals(paymentViewForLoadMoney.get(0).getCardNo())) {
			List<PaymentSource> receiverDetailsForLoadMoney = paymentSourceRepo
					.findByCardNumber(paymentTransaction.getSenderId()).orElse(new ArrayList<>());
			log.info("senderID= {}, ReceiverID = {}", paymentTransaction.getSenderId(), customerId);
			log.info(" ReceiverID = {}", receiverDetailsForLoadMoney.get(0).getCustomerId());
			if (!CollectionUtils.isEmpty(receiverDetailsForLoadMoney)) {
				receiverDetailsForLoadMoney.forEach(receiver -> {
					List<PaymentView> receiverDetails = paymentViewRepo.findByCustomerId(receiver.getCustomerId())
							.orElse(new ArrayList<>());
					log.info(" ReceiverName = {}", receiverDetails.get(0).getFirstName());
					receiverDetails.forEach(receiverForLoadMoney -> {
						transactionHistoryResponseDtoResultTransactions.setName(
								receiverForLoadMoney.getFirstName() + " " + receiverForLoadMoney.getLastName());
						transactionHistoryResponseDtoResultTransactions.transferType("Dr");
					});
				});

			}
		}
	}

	private void inputValidations(String mobileNumber) {
		if (null == mobileNumber || "" == mobileNumber) {
			throw new BusinessException("400", "Invalid Mobile number");

		}

	}

	private PaymentView mobileNumberValidation(String mobileNo) {

		log.info("Entering into mobileNumberValidation Method ={}", mobileNo);

		return paymentViewRepo.findByMobileNo(mobileNo)
				.orElseThrow(() -> new BusinessException("412", "Customer not found.!"));

	}

	@Override
	public TransactionHistoryResponseDtoResultTransactions getTransactionDetails(String transactionId,
			String mobileNumber) {
		PaymentView customerPaymentDetails = paymentViewRepo.findByMobileNo(mobileNumber)
				.orElseThrow(() -> new BusinessException("412", "Customer not found.!"));
		PaymentEntity transactionDetails = paymentTransactionHistoryRepo
				.findByTransactionId(Long.parseLong(transactionId))
				.orElseThrow(() -> new BusinessException("413", "No Transaction Details Found"));
		return formTransactionDetialsResponse(customerPaymentDetails, transactionDetails);
	}

	private TransactionHistoryResponseDtoResultTransactions formTransactionDetialsResponse(
			PaymentView customerPaymentDetails, PaymentEntity transactionDetails) {
		TransactionHistoryResponseDtoResultTransactions transactionDetailsResponse = new TransactionHistoryResponseDtoResultTransactions();
		transactionDetailsResponse.setTransactionId(transactionDetails.getTransactionId().toString());
		transactionDetailsResponse
				.setName(transactionsUtil.populateReceiverName(customerPaymentDetails, transactionDetails));
		transactionDetailsResponse
				.setAccountNumber(transactionsUtil.populateAccountNumber(customerPaymentDetails, transactionDetails));
		transactionDetailsResponse.setAmount(String.valueOf(transactionDetails.getTransactionAmount()));
		transactionDetailsResponse.setDate(transactionDetails.getCreatedDt().getTime());
		transactionDetailsResponse
				.setPaymentSource(transactionsUtil.populatePaymentSource(customerPaymentDetails, transactionDetails));
		return transactionDetailsResponse;
	}

}
