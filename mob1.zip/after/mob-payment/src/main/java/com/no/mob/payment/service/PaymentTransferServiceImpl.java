package com.no.mob.payment.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.no.mob.payment.common.GenericResponse;
import com.no.mob.payment.entity.BeneficiaryDetails;
import com.no.mob.payment.entity.MccCode;
import com.no.mob.payment.entity.MerchantEntity;
import com.no.mob.payment.entity.PaymentEntity;
import com.no.mob.payment.entity.PaymentSource;
import com.no.mob.payment.entity.PaymentView;
import com.no.mob.payment.exceptions.BusinessException;
import com.no.mob.payment.model.MerchantPaymentTransferRequestDto;
import com.no.mob.payment.model.MerchantTransferServiceResponseDto;
import com.no.mob.payment.model.PaymentRequest;
import com.no.mob.payment.model.PaymentSourceRequestDto;
import com.no.mob.payment.model.PaymentTransferDto;
import com.no.mob.payment.model.PaymentTransferRequestDto;
import com.no.mob.payment.model.TransferServiceResponseDto;
import com.no.mob.payment.repo.MccCodeRepo;
import com.no.mob.payment.repo.MerchantRepo;
import com.no.mob.payment.repo.PaymentDetailsRepo;
import com.no.mob.payment.repo.PaymentRepo;
import com.no.mob.payment.repo.PaymentSourceRepo;
import com.no.mob.payment.repo.PaymentViewRepo;
import com.no.mob.payment.util.CurrencyConverter;
import com.no.mob.payment.util.TransactionsUtil;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PaymentTransferServiceImpl implements PaymentTransferService {

	@Autowired
	private PaymentViewRepo paymentViewRepo;

	@Autowired
	private PaymentRepo paymentRepo;

	@Autowired
	private PaymentDetailsRepo paymentDetailsRepo;

	@Autowired
	private PaymentSourceRepo paymentSourceRepo;

	@Autowired
	private MccCodeRepo mccCodeRepo;

	@Autowired
	public MerchantRepo merchantRepo;

	RestTemplate restTemplate = new RestTemplate();
	@Value("${credit.payment.uri}")
	private String creditUrl;

	@Value("${debit.payment.uri}")

	private String debitUrl;

	@Value("${mob.to.other.payment.uri}")
	private String mob2Other;

	@Autowired
	private TransactionsUtil transactionsUtil;

	@Autowired
	private CurrencyConverter currencyConverter;

	@Override
	@Transactional
	public TransferServiceResponseDto makePayment(String mobileNo,
			PaymentTransferRequestDto paymentTransferRequestDto) {
		PaymentEntity paymentEntity = null;
		PaymentView sourcePaymentDetails = paymentViewRepo.findByMobileNo(mobileNo)
				.orElseThrow(() -> new BusinessException("404", "Account Details Not Found"));
		if (sourcePaymentDetails.getAccountStatus() == 'N') {
			throw new BusinessException("417", "Source Account Deactivated");
		}
		BigDecimal amount = paymentTransferRequestDto.getAmount();
		if (checkCurrencyCheckRequired(paymentTransferRequestDto.getCountryCode(),
				sourcePaymentDetails.getCountryCd())) {
			amount = currencyConverter.convertRequestedAmount(amount, paymentTransferRequestDto.getCountryCode(),
					sourcePaymentDetails.getCountryCd());
		}
		HttpHeaders headers = setHeaders(mobileNo);
		HttpEntity<PaymentTransferDto> request = new HttpEntity<>(
				new PaymentTransferDto(null, amount, sourcePaymentDetails.getAccountNo()), headers);
		ResponseEntity<GenericResponse> debit = restTemplate.exchange(debitUrl, HttpMethod.POST, request,
				GenericResponse.class);

		if (debit.getStatusCode().equals(HttpStatus.OK)) {
			Optional<PaymentView> targetPaymentDetails = paymentViewRepo
					.findByAccountNo(String.valueOf(paymentTransferRequestDto.getTargetAccountNo()));
			PaymentEntity payment = createTransactionEntity(paymentTransferRequestDto, sourcePaymentDetails,
					paymentTransferRequestDto.getAmount(), debit.getBody().getResult());
			MccCode mccCd = mccCodeRepo.findByCategoryType("P2P");
			payment.setMccCode(String.valueOf(mccCd.getMccCd()));
			paymentEntity = paymentRepo.save(payment);
			if (!targetPaymentDetails.isPresent()) {
				paymentEntity = performMob2OtherAccountTransfer(paymentTransferRequestDto,
						Long.valueOf(sourcePaymentDetails.getAccountNo()), payment);
			} else {
				if (targetPaymentDetails.get().getAccountStatus() == 'N') {
					throw new BusinessException("417", "Target Account Deactivated");
				}

				createHttpRequestForCredit(paymentTransferRequestDto, targetPaymentDetails, amount, request);
				ResponseEntity<GenericResponse> credit = restTemplate.exchange(creditUrl, HttpMethod.POST, request,
						GenericResponse.class);
				if (!credit.getStatusCode().equals(HttpStatus.OK)) {
					throw new BusinessException("417", "credit failed");
				}

				payment.setReceiverId(targetPaymentDetails.get().getCustomerId());
				payment.setUpdatedDt(new Date());
				payment.setPaymentStatus(103);
				payment.setBalanceAm(getBigDecimal(credit.getBody().getResult()));
				MccCode mccCd2 = mccCodeRepo.findByCategoryType("P2P");
				paymentEntity.setMccCode(String.valueOf(mccCd2.getMccCd()));
				paymentEntity = paymentRepo.save(payment);

			}
		} else {
			throw new BusinessException("417", "debit failed");
		}

		return createResponse(paymentTransferRequestDto, paymentEntity, sourcePaymentDetails);
	}

	private void createHttpRequestForCredit(PaymentTransferRequestDto paymentTransferRequestDto,
			Optional<PaymentView> targetPaymentDetails, BigDecimal amount, HttpEntity<PaymentTransferDto> request) {
		if (targetPaymentDetails.isPresent()) {
			if (checkCurrencyCheckRequired(paymentTransferRequestDto.getCountryCode(),
					targetPaymentDetails.get().getCountryCd())) {
				request.getBody().setAmount(currencyConverter.convertRequestedAmount(amount,
						paymentTransferRequestDto.getCountryCode(), targetPaymentDetails.get().getCountryCd()));
			}

			request.getBody().setAccountNo(targetPaymentDetails.get().getAccountNo());
		}
	}

	private TransferServiceResponseDto createResponse(PaymentTransferRequestDto paymentTransferRequestDto,
			PaymentEntity paymentEntity, PaymentView sourcePaymentDetails) {
		TransferServiceResponseDto transferServiceResponseDto = new TransferServiceResponseDto();
		transferServiceResponseDto.setTransactionId(paymentEntity.getTransactionId().toString());
		transferServiceResponseDto.setType("Fabby");
		transferServiceResponseDto.setStatus(TransactionsUtil.checkTransactionStatus(paymentEntity.getPaymentStatus()));
		transferServiceResponseDto.setCategory(TransactionsUtil.checkCategory(paymentEntity.getTransactionType()));
		transferServiceResponseDto.setLogoUrl("");
		transferServiceResponseDto.setAmount(paymentEntity.getTransactionAmount().toString());
		transferServiceResponseDto.setDate(paymentEntity.getCreatedDt().getTime());
		transferServiceResponseDto.setName(transactionsUtil.populateNameOrAccountNo(paymentEntity.getReceiverId()));
		transferServiceResponseDto.setAccountNumber(String.valueOf(paymentTransferRequestDto.getTargetAccountNo()));
		transferServiceResponseDto.setPaymentSource(sourcePaymentDetails.getCardNo());
		return transferServiceResponseDto;
	}

	private boolean checkCurrencyCheckRequired(String sourceCountryCode, String countryCd) {
		return !sourceCountryCode.equals(countryCd);
	}

	private PaymentEntity createTransactionEntity(PaymentTransferRequestDto paymentTransferRequestDto,
			PaymentView sourcePaymentDetails, BigDecimal amount, Object balance) {
		PaymentEntity payment = new PaymentEntity();
		payment.setSenderId(sourcePaymentDetails.getCustomerId());
		payment.setCreatedDt(new Date());
		payment.setUpdatedDt(new Date());
		payment.setCountryCode(paymentTransferRequestDto.getCountryCode());
		payment.setPaymentStatus(101);
		payment.setTransactionType(2);
		payment.setPaymentType("P2P");
		payment.setSwift(paymentTransferRequestDto.getSwiftCode());
		payment.setTransactionAmount(amount);
		payment.setTransactionText(paymentTransferRequestDto.getTransactionTxt());
		payment.setBankAccountId(sourcePaymentDetails.getAccountId());
		payment.setBalanceAm(getBigDecimal(balance));
		return payment;
	}

	private HttpHeaders setHeaders(String mobileNo) {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "application/json");
		headers.set("mobile_number", mobileNo);
		return headers;
	}

	private PaymentEntity performMob2OtherAccountTransfer(PaymentTransferRequestDto paymentTransferRequestDto,
			long accountNo, PaymentEntity payment) {

		HttpEntity<PaymentRequest> request = new HttpEntity<>(
				createPaymentRequest(paymentTransferRequestDto, accountNo));
		restTemplate.exchange(mob2Other, HttpMethod.POST, request, PaymentTransferDto.class);

		BeneficiaryDetails beneficiaryDetails = paymentDetailsRepo
				.findByAccountNumber(String.valueOf(paymentTransferRequestDto.getTargetAccountNo()));
		if (null == beneficiaryDetails) {
			payment.setReceiverId(paymentTransferRequestDto.getTargetAccountNo());
		} else {
			payment.setReceiverId(beneficiaryDetails.getPayeeId());
		}
		payment.setPaymentStatus(101);
		payment.setUpdatedDt(new Date());
		return paymentRepo.save(payment);
	}

	private PaymentRequest createPaymentRequest(PaymentTransferRequestDto paymentTransferRequestDto, long accountNo) {
		PaymentRequest paymentRequest = new PaymentRequest();
		paymentRequest.setAmount(paymentTransferRequestDto.getAmount());
		paymentRequest.setCreated(new Date());
		paymentRequest.setCurrency(paymentTransferRequestDto.getCountryCode());
		paymentRequest.setReference(paymentTransferRequestDto.getTransactionTxt());
		paymentRequest.setSourceAccount(accountNo);
		paymentRequest.setSwift(paymentTransferRequestDto.getSwiftCode());
		paymentRequest.setTargetAccount(paymentTransferRequestDto.getTargetAccountNo());
		paymentRequest.setTransferRequest("");
		return paymentRequest;
	}

	@Override

	public void saveTransaction(PaymentTransferRequestDto paymentTransferRequestDto) {
		PaymentEntity paymentEntity = new PaymentEntity();
		paymentEntity.setBankAccountId(paymentTransferRequestDto.getAccountId());
		paymentEntity.setCountryCode(paymentTransferRequestDto.getCountryCode());
		paymentEntity.setPaymentStatus(101);
		paymentEntity.setPaymentType("P2P");
		paymentEntity.setTransactionType(2);
		paymentEntity.setSenderId(paymentTransferRequestDto.getSenderId());
		paymentEntity.setReceiverId(paymentTransferRequestDto.getReceiverId());
		paymentEntity.setTransactionAmount(paymentTransferRequestDto.getAmount());
		paymentEntity.setTransactionText("Initial credit from Fabby Bank");
		paymentEntity.setCreatedDt(new Date());
		paymentEntity.setUpdatedDt(new Date());
		paymentRepo.save(paymentEntity);
	}

	public static BigDecimal getBigDecimal(Object value) {
		BigDecimal ret = null;
		if (value != null) {
			if (value instanceof BigDecimal) {
				ret = (BigDecimal) value;
			} else if (value instanceof String) {
				ret = new BigDecimal((String) value);
			} else if (value instanceof BigInteger) {
				ret = new BigDecimal((BigInteger) value);
			} else if (value instanceof Number) {
				ret = BigDecimal.valueOf((Double) value);
			} else if (value instanceof Double) {
				ret = BigDecimal.valueOf((Double) value);
			} else {
				throw new ClassCastException("Not possible to coerce [" + value + "] from class " + value.getClass()
						+ " into a BigDecimal.");
			}
		}
		return ret;
	}

	@Override
	public void savePaymentSource(PaymentSourceRequestDto paymentSourceRequestDto) {
		PaymentSource paymentSource = new PaymentSource();
		paymentSource.setCardNumber(paymentSourceRequestDto.getCardNumber());
		paymentSource.setActiveIn('Y');
		paymentSource.setCustomerId(paymentSourceRequestDto.getCustomerId());
		paymentSource.setCardExpiry(parseDate("2023-01-30"));
		paymentSource.setCreatedDt(new Timestamp(System.currentTimeMillis()));
		paymentSource.setUpdatedDt(new Timestamp(System.currentTimeMillis()));
		paymentSourceRepo.save(paymentSource);
	}

	private Date parseDate(String date) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		Date d = null;
		try {
			d = sdf.parse(date);
		} catch (ParseException e) {
			log.error("Error occured while parsing date" + e.getMessage());
		}
		return d;
	}

	@Override
	public MerchantTransferServiceResponseDto makeMerchantPayment(String mobileNo,
			MerchantPaymentTransferRequestDto merchantPaymentTransferRequestDto) {
		MerchantTransferServiceResponseDto merchantTransferServiceResponseDto = new MerchantTransferServiceResponseDto();
		PaymentEntity paymentEntity = null;
		PaymentView sourcePaymentDetails = paymentViewRepo.findByMobileNo(mobileNo)
				.orElseThrow(() -> new BusinessException("404", "Account Details Not Found"));

		if (sourcePaymentDetails.getAccountStatus() == 'N') {
			throw new BusinessException("417", "Source Account Deactivated");
		}

		BigDecimal amount = merchantPaymentTransferRequestDto.getAmount();
		HttpHeaders headers = setHeaders(mobileNo);
		HttpEntity<PaymentTransferDto> request = new HttpEntity<>(
				new PaymentTransferDto(null, amount, sourcePaymentDetails.getAccountNo()), headers);

		ResponseEntity<GenericResponse> debit = restTemplate.exchange(debitUrl, HttpMethod.POST, request,
				GenericResponse.class);
		if (debit.getStatusCode().equals(HttpStatus.OK)) {
			MerchantEntity merchant = merchantRepo.findByMerchantId(merchantPaymentTransferRequestDto.getMerchantId());
			PaymentEntity payment = createMerchantTransactionEntity(merchantPaymentTransferRequestDto,
					sourcePaymentDetails, String.valueOf(merchant.getMccCd()), debit.getBody().getResult());
			paymentEntity = paymentRepo.save(payment);
		} else {
			throw new BusinessException("417", "debit failed");
		}
		return createMerchantResponse(merchantPaymentTransferRequestDto, merchantTransferServiceResponseDto,
				paymentEntity, sourcePaymentDetails);
	}
	
	private PaymentEntity createMerchantTransactionEntity(
			MerchantPaymentTransferRequestDto merchantPaymentTransferRequestDto, PaymentView sourcePaymentDetails,
			String mccCode, Object balance) {
		PaymentEntity payment = new PaymentEntity();
		payment.setSenderId(sourcePaymentDetails.getCustomerId());
		payment.setCreatedDt(new Date());
		payment.setUpdatedDt(new Date());
		payment.setCountryCode(sourcePaymentDetails.getCountryCd());
		payment.setPaymentStatus(101);
		payment.setTransactionType(3);
		payment.setPaymentType("P2B");
		payment.setTransactionAmount(merchantPaymentTransferRequestDto.getAmount());
		payment.setBankAccountId(sourcePaymentDetails.getAccountId());
		payment.setBalanceAm(getBigDecimal(balance));
		payment.setReceiverId(merchantPaymentTransferRequestDto.getMerchantId());
		payment.setMccCode(mccCode);
		return payment;
	}

	private MerchantTransferServiceResponseDto createMerchantResponse(
			MerchantPaymentTransferRequestDto merchantPaymentTransferRequestDto,
			MerchantTransferServiceResponseDto merchantTransferServiceResponseDto, PaymentEntity paymentEntity,
			PaymentView sourcePaymentDetails) {
		merchantTransferServiceResponseDto.setTransactionId(paymentEntity.getTransactionId().toString());
		merchantTransferServiceResponseDto.setType("Fabby");
		merchantTransferServiceResponseDto
				.setStatus(TransactionsUtil.checkTransactionStatus(paymentEntity.getPaymentStatus()));
		merchantTransferServiceResponseDto
				.setCategory(TransactionsUtil.checkCategory(paymentEntity.getTransactionType()));
		merchantTransferServiceResponseDto.setAmount(merchantPaymentTransferRequestDto.getAmount().toString());
		merchantTransferServiceResponseDto.setDate(paymentEntity.getCreatedDt().getTime());
		merchantTransferServiceResponseDto.setAccountNumber(sourcePaymentDetails.getAccountNo());
		merchantTransferServiceResponseDto.setPaymentSource(sourcePaymentDetails.getCardNo());
		return merchantTransferServiceResponseDto;
	}
}
