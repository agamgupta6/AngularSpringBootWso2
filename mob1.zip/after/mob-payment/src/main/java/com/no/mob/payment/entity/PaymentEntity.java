package com.no.mob.payment.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Entity
@Table(name = "tb_payment_transaction")
public class PaymentEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@SequenceGenerator(name="seq",sequenceName="tb_payment_transaction_id_seq")
	 @GeneratedValue(generator="seq",strategy=GenerationType.SEQUENCE)
	@Column(name="TRANSACTION_ID",columnDefinition = "NUMERIC(12,0)", nullable = false)
	@JsonProperty("transactionId")
	private Long transactionId;
	
	@Column(name="BANK_ACCOUNT_ID")
	private Long bankAccountId;
	
	@Column(name="CARD_ID")
	private Long cardId;
	
	@Column(name="TRASANCTION_AM")
	private BigDecimal transactionAmount;
	
	@Column(name="CREATED_DT")
    private Date createdDt;

	@Column(name="SENDER_ID")
	private Long senderId;
	
	@Column(name="PAYMENT_TYPE")
	private String paymentType;
	
	@Column(name="STATUS")
	private int paymentStatus;
	
	@Column(name="UPDATED_DT")
	private  Date updatedDt;
	
	@Column(name="COUNTRY_CODE")
	private String countryCode;
	
	@Column(name="TRANSACTION_TX")
	private String transactionText;
	
	@Column(name="RECEIVER_ID")
	private Long receiverId;
	
	@Column(name="TRASANCTION_TYPE")
	private int transactionType;
	
	@Column(name="IBAN")
	private String iban;
	
	@Column(name="SWIFT")
	private String swift;
	
	@Column(name="MCC_CD")
	private String mccCode;
	
	@Column(name="BALANCE_AM")
	private BigDecimal balanceAm;
}
