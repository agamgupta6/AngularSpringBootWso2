package com.no.mob.payment.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.no.mob.payment.common.ErrorDetails;
import com.no.mob.payment.common.GenericResponse;
import com.no.mob.payment.common.ResponseConverter;
import com.no.mob.payment.exceptions.BusinessException;
import com.no.mob.payment.model.BeneficiaryDetailsDtoResult;
import com.no.mob.payment.model.BeneficiaryRequestDto;
import com.no.mob.payment.model.CardDetailsDto;
import com.no.mob.payment.model.ConcentDetailsResponseDto;
import com.no.mob.payment.model.GetCardDetailsResponseDto;
import com.no.mob.payment.model.InvoicePaymentRequestDto;
import com.no.mob.payment.model.InvoiceRequest;
import com.no.mob.payment.model.LoadMoneyRequestDto;
import com.no.mob.payment.model.MerchantAccountDetailsDtoResult;
import com.no.mob.payment.model.MerchantDetailsRequestDto;
import com.no.mob.payment.model.MerchantPaymentTransferRequestDto;
import com.no.mob.payment.model.MerchantTransferServiceResponseDto;
import com.no.mob.payment.model.OfferDetailsResponseDto;
import com.no.mob.payment.model.PaymentRequest;
import com.no.mob.payment.model.PaymentSourceRequestDto;
import com.no.mob.payment.model.PaymentTransferRequestDto;
import com.no.mob.payment.model.PfmDetailsResponseDto;
import com.no.mob.payment.model.TransactionHistoryResponseDtoResult;
import com.no.mob.payment.model.TransactionHistoryResponseDtoResultTransactions;
import com.no.mob.payment.model.TransferServiceResponseDto;
import com.no.mob.payment.service.ConcentService;
import com.no.mob.payment.service.GetCardDetails;
import com.no.mob.payment.service.GetTransactions;
import com.no.mob.payment.service.InvoicePaymentService;
import com.no.mob.payment.service.LoadMoneyTransactionService;
import com.no.mob.payment.service.MerchantPaymentService;
import com.no.mob.payment.service.MerchantService;
import com.no.mob.payment.service.OffersService;
import com.no.mob.payment.service.PayeeDetailsService;
import com.no.mob.payment.service.PaymentTransferService;
import com.no.mob.payment.service.PfmService;
import com.no.mob.payment.service.SuntechIntegrationService;
import com.no.mob.payment.suntech.model.SuntechRequestDto;
import com.no.mob.payment.suntech.model.SuntechResponseDto;

import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2017-12-21T06:56:41.040Z")
@Controller
@Slf4j
public class PaymentsApiController implements PaymentsApi {

	@Autowired
	private LoadMoneyTransactionService loadMoneyTransactionService;

	@Autowired
	private PaymentTransferService paymentTransferService;

	@Autowired
	private GetTransactions getTransactions;

	@Autowired
	private PayeeDetailsService payeeDetailsService;

	@Autowired
	private GetCardDetails getCardDetails;

	@Autowired
	private InvoicePaymentService invoicePaymentService;

	@Autowired
	private MerchantService merchantService;

	@Autowired
	private OffersService offersService;

	@Autowired
	private PfmService pfmService;

	@Autowired
	private ConcentService concentService;

	@Autowired
	private SuntechIntegrationService suntechIntegrationService;
	
	@Autowired
	@Qualifier("merchantPaymentServiceImpl")
	private MerchantPaymentService merchantPaymentService;
	
	public ResponseEntity<GenericResponse> paymentsGetTransactionsGet(
			@ApiParam(value = "") @RequestHeader(value = "mobile_number", required = false) String mobileNumber,
			@ApiParam(value = "") @RequestHeader(value = "Authorization", required = false) String accessToken) {

		GenericResponse response = new GenericResponse();
		TransactionHistoryResponseDtoResult transactionHistoryResponseDtoResult = getTransactions
				.getTransactionHistorydetails(mobileNumber);
		response.setResult(transactionHistoryResponseDtoResult);
		return new ResponseEntity<GenericResponse>(response, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<GenericResponse> transferMoney(
			@ApiParam(value = "") @RequestHeader(value = "mobile_number", required = false) String mobileNumber,
			@ApiParam(value = "") @RequestHeader(value = "Authorization", required = false) String accessToken,
			@ApiParam(value = "") @RequestBody(required = false) PaymentTransferRequestDto paymentTransferRequestDto) {
		TransferServiceResponseDto transferServiceResponseDto = paymentTransferService.makePayment(mobileNumber,
				paymentTransferRequestDto);
		GenericResponse response = new GenericResponse();
		response.setResult(transferServiceResponseDto);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<GenericResponse> transferMoneybetweenToOtherAccounts(
			@RequestBody(required = false) PaymentRequest paymentRequest) {
		return new ResponseEntity<>(new GenericResponse(), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<GenericResponse> paymentGetBeneficiaryDetailsPost(
			@ApiParam(value = "") @RequestHeader(value = "mobile_number", required = false) String mobileNumber,
			@ApiParam(value = "") @RequestHeader(value = "Authorization", required = false) String accessToken) {

		GenericResponse response = new GenericResponse();
		BeneficiaryDetailsDtoResult beneficiaryDetailsResponseDto = payeeDetailsService.fetchPayeeDetails(mobileNumber);
		response.setResult(beneficiaryDetailsResponseDto);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<GenericResponse> paymentAddPayeeDeatilsPost(
			@ApiParam(value = "", required = true) @Valid @RequestBody BeneficiaryRequestDto beneficiaryRequestdto,
			@ApiParam(value = "") @RequestHeader(value = "mobile_number", required = false) String mobileNumber,
			@ApiParam(value = "") @RequestHeader(value = "Authorization", required = false) String authorization) {
		payeeDetailsService.addPayeeDetails(beneficiaryRequestdto, mobileNumber);
		return new ResponseEntity<GenericResponse>(new GenericResponse(), HttpStatus.OK);
	}

	@ExceptionHandler(BusinessException.class)
	public ResponseEntity<GenericResponse> defaultErrorHandler(BusinessException e) {
		ErrorDetails errorDetails = e.getErrorDetails();
		return new ResponseEntity<>(ResponseConverter.formGenericErrorResponse(errorDetails),
				(HttpStatus.valueOf(Integer.valueOf(errorDetails.getErrorCode()))));

	}

	@Override
	public ResponseEntity<GenericResponse> loadMoneyToAccount(
			@ApiParam(value = "load money", required = true) @Valid @RequestBody LoadMoneyRequestDto loadMoneyRequestDto,
			@ApiParam(value = "") @RequestHeader(value = "mobile_number", required = true) String mobileNumber,
			@ApiParam(value = "") @RequestHeader(value = "Authorization", required = false) String accessToken) {
		TransferServiceResponseDto transferServiceResponseDto = loadMoneyTransactionService
				.loadMoneyInAccount(loadMoneyRequestDto, mobileNumber, accessToken);
		GenericResponse response = new GenericResponse();
		response.setResult(transferServiceResponseDto);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<GenericResponse> paymentGetCardDetailsGet(
			@ApiParam(value = "") @RequestHeader(value = "mobile_number", required = false) String mobileNumber,
			@ApiParam(value = "") @RequestHeader(value = "Authorization", required = false) String accessToken) {
		GenericResponse response = new GenericResponse();
		List<GetCardDetailsResponseDto> cardDetailsList = new ArrayList<GetCardDetailsResponseDto>();
		cardDetailsList = getCardDetails.getCardDetails(mobileNumber);
		CardDetailsDto cardDetails = new CardDetailsDto();
		cardDetails.setCardDetails(cardDetailsList);
		response.setResult(cardDetails);
		return new ResponseEntity<>(response, HttpStatus.OK);

	}

	@Override
	public ResponseEntity<GenericResponse> performInvoicePayments(
			@ApiParam(value = "") @RequestHeader(value = "mobile_number", required = false) String mobileNumber,
			@ApiParam(value = "") @RequestHeader(value = "Authorization", required = false) String accessToken,
			@RequestBody InvoicePaymentRequestDto invoicePaymentRequestDto) {
		TransferServiceResponseDto transferServiceResponseDto = invoicePaymentService
				.makeInvoicePayment(invoicePaymentRequestDto, mobileNumber);
		GenericResponse response = new GenericResponse();
		response.setResult(transferServiceResponseDto);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<GenericResponse> invoiceExternalApi(InvoiceRequest invoiceRequest) {
		return new ResponseEntity<>(new GenericResponse(), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<GenericResponse> getMerchantDetails(
			@ApiParam(value = "", required = true) @RequestBody MerchantDetailsRequestDto merchantDetailsRequestDto,
			@ApiParam(value = "") @RequestHeader(value = "mobile_number", required = false) String mobileNumber,
			@ApiParam(value = "") @RequestHeader(value = "Authorization", required = false) String accessToken) {
		GenericResponse response = new GenericResponse();
		MerchantAccountDetailsDtoResult merchantAccountDetailsDtoResult = merchantService
				.fetchMerchantDetailsByQrCode(merchantDetailsRequestDto, mobileNumber);
		response.setResult(merchantAccountDetailsDtoResult);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<GenericResponse> saveTransaction(
			@RequestHeader(value = "mobile_number", required = false) String mobileNumber,
			@ApiParam(value = "") @RequestHeader(value = "Authorization", required = false) String accessToken,
			@ApiParam(value = "") @RequestBody(required = false) PaymentTransferRequestDto paymentTransferRequestDto) {
		paymentTransferService.saveTransaction(paymentTransferRequestDto);
		return new ResponseEntity<>(new GenericResponse(), HttpStatus.OK);
	}

	@Override
	@RequestMapping(value = "/getAccountDetails/{beacon_code}", produces = {
			"application/json" }, method = RequestMethod.GET)
	public ResponseEntity<GenericResponse> getDetailsByBeaconCode(
			@ApiParam(value = "", required = false) @PathVariable("beacon_code") String beaconCode,
			@ApiParam(value = "") @RequestHeader(value = "mobile_number", required = false) String mobileNumber,
			@ApiParam(value = "") @RequestHeader(value = "Authorization", required = false) String accessToken) {
		OfferDetailsResponseDto beaconDetailsResponseDto = offersService.fetchOfferDetails(beaconCode, mobileNumber);
		GenericResponse response = new GenericResponse();
		response.setResult(beaconDetailsResponseDto);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<GenericResponse> getTransactionDetails(
			@PathVariable(value = "transactionId", required = false) String transactionId,
			@ApiParam(value = "") @RequestHeader(value = "mobile_number", required = false) String mobileNumber,
			@ApiParam(value = "") @RequestHeader(value = "Authorization", required = false) String accessToken) {
		TransactionHistoryResponseDtoResultTransactions transactionDetails = getTransactions
				.getTransactionDetails(transactionId, mobileNumber);
		GenericResponse response = new GenericResponse();
		response.setResult(transactionDetails);
		return new ResponseEntity<GenericResponse>(response, HttpStatus.OK);
	}

	@Override
	@RequestMapping(value = "/setConcent/{merchantId}", produces = { "application/json" }, method = RequestMethod.POST)
	public ResponseEntity<GenericResponse> setConcentDetails(
			@ApiParam(value = "", required = false) @PathVariable("merchantId") String merchantId,
			@ApiParam(value = "") @RequestHeader(value = "mobile_number", required = true) String mobileNumber,
			@ApiParam(value = "") @RequestHeader(value = "Authorization", required = true) String accessToken) {
		OfferDetailsResponseDto beaconDetailsResponseDto = offersService.setConcentDetails(merchantId, mobileNumber);
		GenericResponse response = new GenericResponse();
		response.setResult(beaconDetailsResponseDto);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "/pfmDetails/{targetDt}", produces = { "application/json" }, method = RequestMethod.POST)
	public ResponseEntity<GenericResponse> getPfmDetails(
			@ApiParam(value = "") @RequestHeader(value = "mobile_number", required = false) String mobileNumber,
			@ApiParam(value = "") @RequestHeader(value = "access_token", required = false) String accessToken,
			@ApiParam(value = "") @PathVariable(value = "targetDt", required = false) String targetDt) {
		PfmDetailsResponseDto pfmDetailsResponseDto = pfmService.fetchPfmDetails(mobileNumber, targetDt);
		GenericResponse response = new GenericResponse();
		response.setResult(pfmDetailsResponseDto);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "/updateConcent/{merchantId}/{value}", produces = {
			"application/json" }, method = RequestMethod.POST)
	public ResponseEntity<GenericResponse> updateConcentDetails(
			@ApiParam(value = "", required = false) @PathVariable("value") String value,
			@ApiParam(value = "") @RequestHeader(value = "mobile_number", required = true) String mobileNumber,
			@ApiParam(value = "") @RequestHeader(value = "Authorization", required = true) String accessToken,
			@ApiParam(value = "", required = false) @PathVariable("merchantId") String merchantId) {
		List<ConcentDetailsResponseDto> concentDetailsResponse = offersService
				.updateConcentValue(Boolean.valueOf(value), mobileNumber, merchantId);
		GenericResponse response = new GenericResponse();
		response.setResult(concentDetailsResponse);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<GenericResponse> getPfmTransactionDetails(String mobileNumber, String accessToken,
			String targetDt) {
		PfmDetailsResponseDto pfmDetailsResponseDto = pfmService.fetchPfmTransactionDetails(mobileNumber, targetDt);
		GenericResponse response = new GenericResponse();
		response.setResult(pfmDetailsResponseDto);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<GenericResponse> createPaymentSource(
			@RequestHeader(value = "mobile_number", required = true) String mobileNumber,
			@ApiParam(value = "") @RequestHeader(value = "Authorization", required = true) String accessToken,
			@ApiParam(value = "", required = false) @Valid @RequestBody PaymentSourceRequestDto paymentSourceRequestDto) {
		GenericResponse response = new GenericResponse();
		paymentTransferService.savePaymentSource(paymentSourceRequestDto);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<GenericResponse> getConcentDetails(
			@RequestHeader(value = "mobile_number", required = true) String mobileNumber,
			@ApiParam(value = "") @RequestHeader(value = "Authorization", required = true) String accessToken) {
		List<ConcentDetailsResponseDto> concentDetailsResponse = concentService
				.fetchCustomerConcentDetails(mobileNumber);
		GenericResponse response = new GenericResponse();
		response.setResult(concentDetailsResponse);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<GenericResponse> createCustomerConcentDetails(
			@RequestHeader(value = "mobile_number", required = true) String mobileNumber,
			@ApiParam(value = "") @RequestHeader(value = "Authorization", required = true) String accessToken) {
		concentService.createCustomerConcentDetails(mobileNumber);
		GenericResponse response = new GenericResponse();
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "/suntechintegrations", produces = { "application/json" }, method = RequestMethod.POST)
	public ResponseEntity<GenericResponse> getSuntechProductRecommomentations(
			@RequestBody SuntechRequestDto suntechRequestDto) {
		log.info("Inside the suntech integration controller");
		List<SuntechResponseDto> responseDto = suntechIntegrationService
				.getProductRecommentation(suntechRequestDto);
		GenericResponse response = new GenericResponse();
		response.setResult(responseDto);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<GenericResponse> makeMerchantPayment(
			@ApiParam(value = "") @RequestHeader(value = "mobile_number", required = false) String mobileNumber,
			@ApiParam(value = "") @RequestBody(required = false) MerchantPaymentTransferRequestDto merchantPaymentTransferRequestDto) {
		MerchantTransferServiceResponseDto transferServiceResponseDto = merchantPaymentService
				.makeMerchantPayment(mobileNumber, merchantPaymentTransferRequestDto);
		GenericResponse response = new GenericResponse();
		response.setResult(transferServiceResponseDto);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

}
