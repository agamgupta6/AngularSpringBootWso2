package com.no.mob.payment.common;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.no.mob.payment.model.ResponseInfo;

public class ResponseConverter {
	private ResponseConverter() {
		//private constructor
	}

	/**
	 * @param response
	 * @return GenericResponse This method prepare generic response for success
	 *         cases
	 */
	public static ResponseEntity<GenericResponse> formResponse() {
		GenericResponse response = new GenericResponse();
		response.setResponseInfo(new ResponseInfo());
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	/**
	 * @param errorDetails
	 * @return GenericResponse This method prepare generic response for failure
	 *         cases
	 */
	public static GenericResponse formGenericErrorResponse(
			ErrorDetails errorDetails) {
		GenericErrorResponse genericErrorResponse = new GenericErrorResponse();
		ResponseInfo responseInfo = new ResponseInfo();
		if (null != errorDetails) {
			responseInfo.setResponseCode(errorDetails.getErrorCode());
			responseInfo.setResponseMessage(errorDetails.getErrorMsgKey());
			genericErrorResponse.setResponseInfo(responseInfo);
		}
		return genericErrorResponse;
	}

	/**
	 * Creates a generic response structure with input object.
	 * 
	 * @param response
	 * @return
	 */
	public static ResponseEntity<GenericResponse> formResponse(Object response) {
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setResponseInfo(new ResponseInfo());
		genericResponse.setResult(response);
		return new ResponseEntity<>(genericResponse,
				HttpStatus.OK);
	}
}
