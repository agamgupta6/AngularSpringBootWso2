package com.no.mob.payment.service;

import java.util.List;

import com.no.mob.payment.model.ConcentDetailsResponseDto;

public interface ConcentService {

	public List<ConcentDetailsResponseDto> fetchCustomerConcentDetails(String mobileNumber);

	public void createCustomerConcentDetails(String mobileNumber);

}
