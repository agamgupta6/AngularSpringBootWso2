package com.no.mob.payment.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "tb_payment_source")
public class PaymentSource implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@SequenceGenerator(name="seq",sequenceName="tb_payment_source_id_seq")
	 @GeneratedValue(generator="seq",strategy=GenerationType.SEQUENCE)
	@Column(name="PAYMENT_SOURCE_ID",columnDefinition = "NUMERIC(12,0)", nullable = false)
	private Long paymentSourceId;
	@Column(name="CARD_NUMBER")
	private Long cardNumber;
	@Column(name="CARD_EXPIRY")
	private Date cardExpiry;
	@Column(name="CUSTOMER_ID")
	private Long customerId;
	@Column(name="ACTIVE_IN")
	private char activeIn;
	@Column(name = "CREATED_DT")
	private Timestamp createdDt;
	@Column(name = "UPDATED_DT")
	private Timestamp updatedDt;
}
