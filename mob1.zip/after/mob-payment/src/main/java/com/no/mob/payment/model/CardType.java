package com.no.mob.payment.model;

public enum CardType {

	VISA,MASTER_CARD;
}
