package com.no.mob.payment.entity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "tb_beacon_offer_details")
public class CustomerBeaconOffer {
	@Id
	@SequenceGenerator(name="seq",sequenceName="customer_offer_id_seq", schema="payment", allocationSize = 1)
	@GeneratedValue(generator="seq",strategy=GenerationType.SEQUENCE)
	@Column(name = "customer_offer_id", columnDefinition = "NUMERIC(12,0)", nullable = false) 
	private long customerOfferId;
	@Column(name="customer_id")
	private long customerId;
	@Column(name="merchant_id")
	private long merchantId;
	@Column(name="offer_id")
	private long offerId;
	@Column(name="merchant_nm")
	private String merchantNm;
	@Column(name="merchant_logo")
	private String merchantLogo;
	@Column(name="merchant_account_no")
	private long accountNo;
	@Column(name="discount_rate")
	private BigDecimal discountRate;
	@Column(name="offer_expiry_dt")
	private Date expiryDt;
	@Column(name="status")
	private int status;
	@Column(name="beacon_cd")
	private String beaconCode;
	@Column(name="concent")
	private Boolean concent;
	
}
