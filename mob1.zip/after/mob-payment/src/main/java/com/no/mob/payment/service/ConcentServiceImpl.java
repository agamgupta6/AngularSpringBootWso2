package com.no.mob.payment.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.no.mob.payment.entity.CustomerConcent;
import com.no.mob.payment.entity.MerchantEntity;
import com.no.mob.payment.entity.PaymentView;
import com.no.mob.payment.exceptions.BusinessException;
import com.no.mob.payment.model.ConcentDetailsResponseDto;
import com.no.mob.payment.repo.CustomerConcentRepo;
import com.no.mob.payment.repo.MerchantRepo;
import com.no.mob.payment.repo.PaymentViewRepo;

@Service
public class ConcentServiceImpl implements ConcentService {
	
	@Autowired
	private PaymentViewRepo paymentViewRepo;
	
	@Autowired
	private CustomerConcentRepo customerConcentRepo;
	
	@Autowired
	private MerchantRepo merchantRepo;

	@Override
	public List<ConcentDetailsResponseDto> fetchCustomerConcentDetails(String mobileNumber) {
		List<ConcentDetailsResponseDto> concentDetailsResponseDtoList = new ArrayList<>();
		PaymentView customerDetails = paymentViewRepo.findByMobileNo(mobileNumber).orElseThrow(() -> new BusinessException("412", "Customer not found.!"));
		List<CustomerConcent> concentDetailsList = customerConcentRepo.findAllByCustomerId(customerDetails.getCustomerId()).orElse(new ArrayList<>());
		if(!CollectionUtils.isEmpty(concentDetailsList)) {
			for (CustomerConcent customerConcent : concentDetailsList) {
				MerchantEntity merchantEntity = merchantRepo.findByMerchantId(customerConcent.getMerchantId());
				ConcentDetailsResponseDto concentDetailsResponseDto = new ConcentDetailsResponseDto();
				concentDetailsResponseDto.setMerchantId(String.valueOf(customerConcent.getMerchantId()));
				concentDetailsResponseDto.setMerchantNm(customerConcent.getMerchantNm());
				if(merchantEntity != null){
					concentDetailsResponseDto.setMcc(String.valueOf(merchantEntity.getMccCd()));
				}
				concentDetailsResponseDto.setMerchantLogoUrl(customerConcent.getMerchantLogo());
				concentDetailsResponseDto.setConcent(customerConcent.getConcent());
				concentDetailsResponseDtoList.add(concentDetailsResponseDto);
			}
		}
		return concentDetailsResponseDtoList;
	}

	@Override
	public void createCustomerConcentDetails(String mobileNumber) {
		PaymentView customerDetails = paymentViewRepo.findByMobileNo(mobileNumber).orElseThrow(() -> new BusinessException("412", "Customer not found.!"));
		List<CustomerConcent> customerConcentList = new ArrayList<>();
		CustomerConcent cutsomerConcentOne = new CustomerConcent();
		cutsomerConcentOne.setMerchantId(Long.valueOf(10001));
		cutsomerConcentOne.setCustomerId(customerDetails.getCustomerId());
		cutsomerConcentOne.setMerchantNm("MyCoffee");
		cutsomerConcentOne.setMerchantLogo("https://s3-eu-west-1.amazonaws.com/mob-private-bckt-dev/merchant/offers/my+coffee%402x.png");
		cutsomerConcentOne.setConcent(false);
		customerConcentList.add(cutsomerConcentOne);
		
		CustomerConcent customerConcentTwo = new CustomerConcent();
		customerConcentTwo.setMerchantId(Long.valueOf(10002));
		customerConcentTwo.setCustomerId(customerDetails.getCustomerId());
		customerConcentTwo.setMerchantNm("Style");
		customerConcentTwo.setMerchantLogo("https://s3-eu-west-1.amazonaws.com/mob-private-bckt-dev/merchant/offers/style%402x.png");
		customerConcentTwo.setConcent(false);
		customerConcentList.add(customerConcentTwo);
		
		CustomerConcent customerConcentThree = new CustomerConcent();
		customerConcentThree.setMerchantId(Long.valueOf(10003));
		customerConcentThree.setCustomerId(customerDetails.getCustomerId());
		customerConcentThree.setMerchantNm("Aahar");
		customerConcentThree.setMerchantLogo("https://s3-eu-west-1.amazonaws.com/mob-private-bckt-dev/merchant/offers/aahar%402x.png");
		customerConcentThree.setConcent(false); 
		customerConcentList.add(customerConcentThree);
		
		CustomerConcent customerConcentFour = new CustomerConcent();
		customerConcentFour.setMerchantId(Long.valueOf(10004));
		customerConcentFour.setCustomerId(customerDetails.getCustomerId());
		customerConcentFour.setMerchantNm("Ehome");
		customerConcentFour.setMerchantLogo("https://s3-eu-west-1.amazonaws.com/mob-private-bckt-dev/merchant/offers/ehome%402x.png");
		customerConcentFour.setConcent(false);
		customerConcentList.add(customerConcentFour);
		
		customerConcentRepo.save(customerConcentList);
		
	}

}
