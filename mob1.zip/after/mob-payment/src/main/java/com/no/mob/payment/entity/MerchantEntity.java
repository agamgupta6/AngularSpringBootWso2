package com.no.mob.payment.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "tb_merchant")
public class MerchantEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6913647313665960208L;

	@Id
	@SequenceGenerator(name="seq",sequenceName="tb_merchant_id_seq")
	@GeneratedValue(generator="seq",strategy=GenerationType.SEQUENCE)
	@Column(name = "merchant_id")
	private long merchantId;
	
	@Column(name = "merchant_nm")
	private String merchantName;
	
	@Column(name = "merchant_status")
	private int merchantStatus;
	
	@Column(name = "mcc_cd")
	private int mccCd;
	
	@Column(name = "created_dt")
	private Date createdDt;
	
	@Column(name = "created_by")
	private String createdBy;
	
	@Column(name = "address_line1_tx")
	private String addressLine1;
	
	@Column(name = "address_line2_tx")
	private String addressLine2;
	
	@Column(name = "city_nm")
	private String cityName;
	
	@Column(name = "postal_cd")
	private String postalCode;
	
	@Column(name = "country_cd")
	private String countryCode;
	
	@Column(name = "email_id")
	private String emailId;
	
	@Column(name = "invoice_partner_id")
	private String invoicePartnerId;
	
	@Column(name = "account_no")
	private long accountNo;
	
	@Column(name = "logo_link_tx")
	private String logoUrl;
	
	@Column(name = "qr_code")
	private String qrCode;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="merchant_id",insertable = false, updatable = false, referencedColumnName="merchant_id")
	private OfferDetails offerDetails;
	
}
