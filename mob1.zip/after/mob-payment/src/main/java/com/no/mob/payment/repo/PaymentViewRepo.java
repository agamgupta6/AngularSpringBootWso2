package com.no.mob.payment.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.no.mob.payment.entity.PaymentView;

@Repository
public interface PaymentViewRepo extends CrudRepository<PaymentView, Long> {

	public Optional<PaymentView> findByAccountNo(String accountNo);
	
	public Optional<List<PaymentView>> findByCustomerId(long customerId);
	
	public Optional<PaymentView> findByMobileNo(String mobileNo);
	
	public Optional<PaymentView> findByCardNo(String cardNo);
	
	@Query(value = "Select * from payment.vw_customer_account_details pv where pv.customer_id =:customerId", nativeQuery = true)
	public Optional<PaymentView> findReceiverByCustomerId(@Param("customerId") Long customerId);
	
	
	
}
