package com.no.mob.payment.meniga.response;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Values {

	private long nettoAmount;
	private long totalPositive;
	private int totalNegative;
	private String date;
	private List<Integer> transactionIds;
}
