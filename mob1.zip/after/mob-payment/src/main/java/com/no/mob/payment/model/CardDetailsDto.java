package com.no.mob.payment.model;

import java.util.List;

public class CardDetailsDto {

   private List<GetCardDetailsResponseDto> cardDetails;
   
	public List<GetCardDetailsResponseDto> getCardDetails() {
		return cardDetails;
	}

	public void setCardDetails(List<GetCardDetailsResponseDto> cardDetails) {
		this.cardDetails = cardDetails;
	}

}
