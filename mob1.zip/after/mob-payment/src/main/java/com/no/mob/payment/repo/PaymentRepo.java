package com.no.mob.payment.repo;

import org.springframework.data.repository.CrudRepository;

import com.no.mob.payment.entity.PaymentEntity;

public interface PaymentRepo extends CrudRepository<PaymentEntity, Long>{

}
