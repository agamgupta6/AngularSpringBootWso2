package com.no.mob.payment.service;

import com.no.mob.payment.model.PfmDetailsResponseDto;

public interface PfmService {

	public PfmDetailsResponseDto fetchPfmDetails(String mobileNumber, String targetDt);

	public PfmDetailsResponseDto fetchPfmTransactionDetails(String mobileNumber, String targetDt);

}
