package com.no.mob.payment.meniga.response;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class TransactionSeriesResponse {

	private String timeResolution;
	private String statistics;
	private List<Values> values;
	private List<Transactions> transactions;
	private List<Integer> transactionIds;
}
