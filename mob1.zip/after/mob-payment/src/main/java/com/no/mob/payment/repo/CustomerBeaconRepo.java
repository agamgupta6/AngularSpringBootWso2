package com.no.mob.payment.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.no.mob.payment.entity.CustomerBeaconOffer;

public interface CustomerBeaconRepo  extends CrudRepository<CustomerBeaconOffer, Long>  {

	public CustomerBeaconOffer findByBeaconCode(String beaconCode);

	public CustomerBeaconOffer findByBeaconCodeAndCustomerId(String beaconCode, Long customerId);

	public CustomerBeaconOffer findByCustomerIdAndAccountNo(Long customerId, long accountNo);
	
	Optional<List<CustomerBeaconOffer>> findByCustomerId(Long customerId);
	
	Optional<CustomerBeaconOffer> findByCustomerIdAndMerchantId(Long customerId, Long merchantId);

	public CustomerBeaconOffer findByCustomerIdAndAccountNoAndConcent(Long customerId, long accountNo, Boolean concent);

}
