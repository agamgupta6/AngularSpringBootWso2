package com.no.mob.payment.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class InvoicePaymentRequestDto {

	private String targetAccountNo;
	private String recipientName;
	private String kidNo;
	private String dueDate;
	private String amount;
	private boolean isOfferApplied = false;
	private String paymentSource;
	
}
