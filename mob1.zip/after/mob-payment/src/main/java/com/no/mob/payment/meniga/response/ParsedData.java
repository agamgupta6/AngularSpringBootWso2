package com.no.mob.payment.meniga.response;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ParsedData {
	private String key;
	private String value;
}
