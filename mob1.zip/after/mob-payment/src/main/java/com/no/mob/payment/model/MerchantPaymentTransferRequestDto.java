package com.no.mob.payment.model;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MerchantPaymentTransferRequestDto {
	private Long merchantId;
	private BigDecimal amount;
	private String paymentSource;
}
