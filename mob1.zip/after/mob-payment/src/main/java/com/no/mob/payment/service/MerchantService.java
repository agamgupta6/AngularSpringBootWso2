package com.no.mob.payment.service;

import com.no.mob.payment.model.MerchantAccountDetailsDtoResult;
import com.no.mob.payment.model.MerchantDetailsRequestDto;

public interface MerchantService {

	public MerchantAccountDetailsDtoResult fetchMerchantDetailsByQrCode(MerchantDetailsRequestDto merchantDetailsRequestDto, String mobileNumber);
}
