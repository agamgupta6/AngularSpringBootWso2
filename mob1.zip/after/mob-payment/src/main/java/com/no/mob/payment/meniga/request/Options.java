package com.no.mob.payment.meniga.request;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Options {
	private boolean includeTransactions;
	private boolean includeTransactionIds;
}
