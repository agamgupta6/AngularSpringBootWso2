package com.no.mob.payment.service;

import com.no.mob.payment.entity.PaymentView;
import com.no.mob.payment.model.MerchantPaymentTransferRequestDto;
import com.no.mob.payment.model.MerchantTransferServiceResponseDto;

public interface ChannelType {

	public MerchantTransferServiceResponseDto debitPayment(String mobileNo,
			MerchantPaymentTransferRequestDto merchantPaymentTransferRequestDto,PaymentView sourcePaymentDetails);

}
