package com.no.mob.payment.suntech.model;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResponseObj {
	
	private String searchTags;
	private List<EntityTagMapping> entityTagMapping;

}
