package com.no.mob.payment.service;

import java.util.List;

import com.no.mob.payment.suntech.model.SuntechRequestDto;
import com.no.mob.payment.suntech.model.SuntechResponseDto;

public interface SuntechIntegrationService {
	List<SuntechResponseDto> getProductRecommentation(SuntechRequestDto requestDto);

}
