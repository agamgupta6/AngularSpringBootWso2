package com.no.mob.payment.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "tb_beneficiary_details")
public class BeneficiaryDetails {
	
	@Id
	@Column(name = "PAYEE_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long payeeId;
	
	@Column(name="MOBILE_NUMBER")
	private String mobileNumber;
	
	@Column(name="COUNTRY_CODE")
	 private String countryCode ;
	
	@Column(name="ACCOUNT_NUMBER")
	  private String accountNumber;
	
	@Column(name="PAYEE_NAME")
	  private String payeeName;
	
	@Column(name="SWIFT_CODE")
	  private String swiftCode;
	
	@Column(name="CUSTOMER_ID")
	private Long customerId;
	
}
