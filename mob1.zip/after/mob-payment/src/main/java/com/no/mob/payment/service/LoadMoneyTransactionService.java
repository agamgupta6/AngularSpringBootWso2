package com.no.mob.payment.service;

import com.no.mob.payment.model.LoadMoneyRequestDto;
import com.no.mob.payment.model.TransferServiceResponseDto;

public interface LoadMoneyTransactionService {

	public TransferServiceResponseDto loadMoneyInAccount(LoadMoneyRequestDto loadMoneyRequestDto, String mobileNumber, String accessToken);
}
