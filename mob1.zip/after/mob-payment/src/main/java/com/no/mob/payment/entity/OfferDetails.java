package com.no.mob.payment.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "tb_offer_details")
public class OfferDetails implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 354640830780508457L;
	
	
	@Id
	@SequenceGenerator(name="seq",sequenceName="tb_offer_id_seq")
	@GeneratedValue(generator="seq",strategy=GenerationType.SEQUENCE)
	@Column(name = "offer_id")
	private long offerId;
	@Column(name = "merchant_id")
	private long merchantId;
	@Column(name = "offer_nm")
	private String offerName;
	@Column(name = "offer_desc")
	private String offerDescription;
	@Column(name = "rate")
	private BigDecimal rate;
	@Column(name = "beacon_cd")
	private String beaconCode;
	@Column(name= "expiry_period")
	private int expiryPeriod;
	
	@OneToOne(mappedBy = "offerDetails")
	private MerchantEntity merchantEntity;
}
