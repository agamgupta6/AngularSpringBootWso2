package com.no.mob.payment.model;

public enum TransactionType {

	INVOICE(1),MOB2MOB(2),MOB2LOCAL(3),MOB2INTERNATIONA(4);
	
	TransactionType(int i){
		
	}
}
