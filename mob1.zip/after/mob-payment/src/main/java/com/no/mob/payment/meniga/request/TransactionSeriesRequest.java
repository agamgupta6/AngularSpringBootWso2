package com.no.mob.payment.meniga.request;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class TransactionSeriesRequest {

	private TransactionFilter transactionFilter;
	private Options options;
	private List<SeriesSelectors> seriesSelectors;

}
