package com.no.mob.payment.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

import lombok.Data;

@Entity
@Immutable
@Table(name = "VW_EXTERNAL_CARD_DETAILS")
@Data
public class ExternalPaymentCard implements Serializable {

private static final long serialVersionUID = 1L;	
	
	@Id
	@Column(name = "PAYMENT_CARD_ID", columnDefinition = "NUMERIC(12,0)", nullable = false) 
	private Long paymentCardId;
	
	@Column(name = "CARD_NUMBER")
	private String cardNumber ;
	
	@Column(name = "CARD_NAME")
	private String cardName;

	@Column(name = "VALID_TO")
	private String validTo;
	
	@Column(name = "CUSTOMER_ID", columnDefinition = "NUMERIC(12,0)")
	private Long customerId;
	
	@Column(name="ACTIVE_IN")	
	private char activeIn;
	
	@Column(name="CARD_SCHEME")
	private String cardScheme;
	
}
