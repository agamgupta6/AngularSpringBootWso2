
package com.no.mob.payment.repo;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.no.mob.payment.entity.MerchantEntity;

@Repository
public interface MerchantRepo extends CrudRepository<MerchantEntity, Long> {

	public MerchantEntity findByAccountNo(Long valueOf);

	@Query(value = "SELECT * FROM payment.tb_merchant m  JOIN payment.tb_offer_details off ON m.merchant_id = off.merchant_id where m.qr_code=:qrCode and off.beacon_cd=:beaconCd", nativeQuery = true)
	public MerchantEntity findByQrCodeAndBeaconCode(@Param("qrCode") String qrCode, @Param("beaconCd") String beaconCode);

	public MerchantEntity findByQrCode(String qrCode);

	public MerchantEntity findByMerchantId(long merchantId);
	
}

