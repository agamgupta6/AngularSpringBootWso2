package com.no.mob.payment.model;

public enum PaymentType {

	P2P,P2B
}
