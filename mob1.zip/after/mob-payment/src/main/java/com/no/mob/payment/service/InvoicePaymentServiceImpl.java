package com.no.mob.payment.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Currency;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.no.mob.payment.common.GenericResponse;
import com.no.mob.payment.config.LoggingRequestInterceptor;
import com.no.mob.payment.entity.CustomerBeaconOffer;
import com.no.mob.payment.entity.ExternalPaymentCard;
import com.no.mob.payment.entity.MccCode;
import com.no.mob.payment.entity.MerchantEntity;
import com.no.mob.payment.entity.PaymentEntity;
import com.no.mob.payment.entity.PaymentView;
import com.no.mob.payment.exceptions.BusinessException;
import com.no.mob.payment.model.InvoicePaymentDto;
import com.no.mob.payment.model.InvoicePaymentRequestDto;
import com.no.mob.payment.model.InvoiceRequest;
import com.no.mob.payment.model.PaymentTransferDto;
import com.no.mob.payment.model.TransferServiceResponseDto;
import com.no.mob.payment.repo.CustomerBeaconRepo;
import com.no.mob.payment.repo.ExternalCardRepo;
import com.no.mob.payment.repo.MccCodeRepo;
import com.no.mob.payment.repo.MerchantRepo;
import com.no.mob.payment.repo.PaymentRepo;
import com.no.mob.payment.repo.PaymentViewRepo;
import com.no.mob.payment.util.TransactionsUtil;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class InvoicePaymentServiceImpl implements InvoicePaymentService {

	@Autowired
	private PaymentViewRepo paymentViewRepo;

	@Autowired
	private PaymentRepo paymentRepo;

	@Value("${invoice.payment.uri}")
	private String invoiceUri;

	@Value("${debit.payment.uri}")
	private String debitUrl;

	@Autowired
	private CustomerBeaconRepo customerBeaconRepo;

	@Autowired
	private MccCodeRepo mccCodeRepo;

	@Autowired
	private MerchantRepo merchantRepo;
	
	@Autowired
	private ExternalCardRepo externalCardRepo;

	RestTemplate restTemplate = new RestTemplate(
			new BufferingClientHttpRequestFactory(new SimpleClientHttpRequestFactory()));

	@Override
	public TransferServiceResponseDto makeInvoicePayment(InvoicePaymentRequestDto invoicePaymentRequestDto,
			String mobileNo) {
		
		ExternalPaymentCard  externalPaymentCard = null;
		List<ClientHttpRequestInterceptor> interceptors = new ArrayList<>();
		interceptors.add(new LoggingRequestInterceptor());
		restTemplate.setInterceptors(interceptors);

		TransferServiceResponseDto transferServiceResponseDto = new TransferServiceResponseDto();
		PaymentEntity paymentEntity = new PaymentEntity();
		PaymentView sourcePaymentDetails = new PaymentView();
		MerchantEntity merchantEntity = null;
		if (null != invoicePaymentRequestDto) {
			sourcePaymentDetails = paymentViewRepo.findByMobileNo(mobileNo)
					.orElseThrow(() -> new BusinessException("404", "Account Details Not Found"));
			if (sourcePaymentDetails.getAccountStatus() == 'N') {
				throw new BusinessException("417", "Source Account Deactivated");
			}
			if (invoicePaymentRequestDto.isOfferApplied()) {
				CustomerBeaconOffer customerBeaconOffer = customerBeaconRepo.findByCustomerIdAndAccountNo(
						sourcePaymentDetails.getCustomerId(),
						Long.valueOf(invoicePaymentRequestDto.getTargetAccountNo()));
				customerBeaconOffer.setStatus(1);
				customerBeaconRepo.save(customerBeaconOffer);
			}
			InvoiceRequest invoiceRequest = createInvoiceRequest(invoicePaymentRequestDto, sourcePaymentDetails);
			HttpEntity<InvoiceRequest> request = new HttpEntity<>(invoiceRequest);
			log.info("Invoice Request: {}", request);
			ResponseEntity<InvoicePaymentDto> invoicePaymentDto = restTemplate.exchange(invoiceUri, HttpMethod.POST,
					request, InvoicePaymentDto.class);
			log.info("Invoice Response: {}", invoicePaymentDto);
			HttpHeaders headers = setHeaders(mobileNo);
			ResponseEntity<GenericResponse> debit = null;
			
			if(sourcePaymentDetails.getAccountNo().equals(invoicePaymentRequestDto.getPaymentSource())) {
			HttpEntity<PaymentTransferDto> debitRequest = new HttpEntity<>(new PaymentTransferDto(null,
					new BigDecimal(invoicePaymentRequestDto.getAmount()), sourcePaymentDetails.getAccountNo()),
					headers);
			 debit = restTemplate.exchange(debitUrl, HttpMethod.POST, debitRequest,
					GenericResponse.class);
			} else {
				
				externalPaymentCard = externalCardRepo
						.findByCustomerIdAndCardNumber(sourcePaymentDetails.getCustomerId(),
								invoicePaymentRequestDto.getPaymentSource())
						.orElseThrow(() -> new BusinessException("404", "Payment Source Invalid"));
				
				debit = new ResponseEntity<>(HttpStatus.OK);
			}
			if (debit.getStatusCode().equals(HttpStatus.OK)) {
				merchantEntity = merchantRepo
						.findByAccountNo(Long.valueOf(invoicePaymentRequestDto.getTargetAccountNo()));
				PaymentEntity payment;
				if (null == merchantEntity) {
					payment = createTransactionEntity(sourcePaymentDetails, invoiceRequest, invoicePaymentDto.getBody(),
							null,externalPaymentCard);
					MccCode mccCd2 = mccCodeRepo.findByCategoryType("Invoice");
					payment.setMccCode(String.valueOf(mccCd2.getMccCd()));

				} else {
					payment = createTransactionEntity(sourcePaymentDetails, invoiceRequest, invoicePaymentDto.getBody(),
							merchantEntity,externalPaymentCard);
					payment.setMccCode(String.valueOf(merchantEntity.getMccCd()));
				}
				paymentEntity = paymentRepo.save(payment);
			}
		}
		return createResponse(invoicePaymentRequestDto, transferServiceResponseDto, paymentEntity, sourcePaymentDetails,
				merchantEntity, externalPaymentCard);
	}

	private TransferServiceResponseDto createResponse(InvoicePaymentRequestDto invoicePaymentRequestDto,
			TransferServiceResponseDto transferServiceResponseDto, PaymentEntity paymentEntity,
			PaymentView sourcePaymentDetails, MerchantEntity merchantEntity, ExternalPaymentCard externalPaymentCard) {
		if (null == merchantEntity && invoicePaymentRequestDto != null) {
			transferServiceResponseDto.setLogoUrl("");
			transferServiceResponseDto.setName(invoicePaymentRequestDto.getTargetAccountNo());
		} else if (merchantEntity != null) {
			transferServiceResponseDto.setLogoUrl(merchantEntity.getLogoUrl());
			transferServiceResponseDto.setName(merchantEntity.getMerchantName());
			transferServiceResponseDto.setMmCd(merchantEntity.getMccCd());
		}
		transferServiceResponseDto.setTransactionId(paymentEntity.getTransactionId().toString());
		
		if(externalPaymentCard == null) {
			transferServiceResponseDto.setType("Fabby");
		}else {
			transferServiceResponseDto.setType(externalPaymentCard.getCardName());
		}

		if (invoicePaymentRequestDto != null) {
			transferServiceResponseDto.setAccountNumber(invoicePaymentRequestDto.getTargetAccountNo());
		}

		transferServiceResponseDto.setStatus(TransactionsUtil.checkTransactionStatus(paymentEntity.getPaymentStatus()));
		transferServiceResponseDto.setCategory(TransactionsUtil.checkCategory(paymentEntity.getTransactionType()));
		transferServiceResponseDto.setAmount(paymentEntity.getTransactionAmount().toString());
		transferServiceResponseDto.setDate(paymentEntity.getCreatedDt().getTime());
		transferServiceResponseDto.setPaymentSource(String.valueOf(invoicePaymentRequestDto.getPaymentSource()).trim());
		return transferServiceResponseDto;
	}

	private InvoiceRequest createInvoiceRequest(InvoicePaymentRequestDto invoicePaymentRequestDto,
			PaymentView sourcePaymentDetails) {
		InvoiceRequest invoiceRequest = new InvoiceRequest();
		invoiceRequest.setAmount(BigDecimal.valueOf(Long.valueOf(invoicePaymentRequestDto.getAmount())));
		invoiceRequest.setTargetAccount(Long.valueOf(invoicePaymentRequestDto.getTargetAccountNo()));
		if (!(invoicePaymentRequestDto.getKidNo() == null || invoicePaymentRequestDto.getKidNo() == "")
				&& !(invoicePaymentRequestDto.getDueDate() == null || invoicePaymentRequestDto.getDueDate() == "")) {
			invoiceRequest.setDueDate(invoicePaymentRequestDto.getDueDate());
			invoiceRequest.setKidNo(Long.valueOf(invoicePaymentRequestDto.getKidNo()));
		}
		invoiceRequest.setCreatedDt(new Date().toString());
		invoiceRequest.setCurrency(
				Currency.getInstance(new Locale("", sourcePaymentDetails.getCountryCd())).getCurrencyCode());
		invoiceRequest.setReference("Merchant Payments");
		invoiceRequest.setSourceAccount(Long.valueOf(sourcePaymentDetails.getAccountNo()));
		return invoiceRequest;
	}

	private PaymentEntity createTransactionEntity(PaymentView sourcePaymentDetails, InvoiceRequest invoiceRequest,
			InvoicePaymentDto invoicePaymentDto, MerchantEntity merchantEntity, ExternalPaymentCard externalPaymentCard) {
		PaymentEntity payment = new PaymentEntity();
		payment.setSenderId(sourcePaymentDetails.getCustomerId());
		payment.setReceiverId(invoiceRequest.getTargetAccount());
		payment.setCreatedDt(new Date());
		payment.setUpdatedDt(new Date());
		payment.setCountryCode(sourcePaymentDetails.getCountryCd());
		payment.setPaymentStatus(checkStatus(invoicePaymentDto));
		if (null == merchantEntity) {
			payment.setPaymentType("INVOICE");
			payment.setTransactionText(invoiceRequest.getReference());
		} else {
			payment.setPaymentType("P2B");
			payment.setTransactionText("Payment made to " + merchantEntity.getMerchantName());
		}
		payment.setSwift(null);
		payment.setTransactionAmount(invoiceRequest.getAmount());
		
		if(externalPaymentCard!= null) {
			payment.setCardId(externalPaymentCard.getPaymentCardId());
		}

		payment.setTransactionType(1);
		payment.setBankAccountId(sourcePaymentDetails.getAccountId());
		return payment;
	}

	private int checkStatus(InvoicePaymentDto invoicePaymentDto) {
		if (invoicePaymentDto.getResponseInfo().getResponseCode().equals(String.valueOf(HttpStatus.OK.value()))) {
			return 101;
		} else {
			return 102;
		}
	}

	private HttpHeaders setHeaders(String mobileNo) {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "application/json");
		headers.set("mobile_number", mobileNo);
		return headers;
	}

}
