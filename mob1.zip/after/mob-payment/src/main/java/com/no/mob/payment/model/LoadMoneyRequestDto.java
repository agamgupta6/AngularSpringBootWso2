package com.no.mob.payment.model;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class LoadMoneyRequestDto {

	private BigDecimal amount;
	private String currency;
	private CardDetailsRequestDto cardDetails;
	
}
