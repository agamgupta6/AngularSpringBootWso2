package com.no.mob.payment.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;


public class TransactionListDto {
	@JsonProperty("name")
	  private List<Transactions> transactions = null;
}
