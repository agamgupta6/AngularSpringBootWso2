package com.no.mob.payment.service;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.no.mob.payment.common.GenericResponse;
import com.no.mob.payment.entity.MerchantEntity;
import com.no.mob.payment.entity.PaymentEntity;
import com.no.mob.payment.entity.PaymentView;
import com.no.mob.payment.exceptions.BusinessException;
import com.no.mob.payment.model.MerchantPaymentTransferRequestDto;
import com.no.mob.payment.model.MerchantTransferServiceResponseDto;
import com.no.mob.payment.model.PaymentTransferDto;

@Service
public class FabbyChannel extends MerchantPaymentServiceImpl implements ChannelType {

	private static final String TYPE = "Fabby";
	
	@Value("${debit.payment.uri}")
	private String debitUrl;
	
	private Logger log = LoggerFactory.getLogger(this.getClass());

	@Override
	public MerchantTransferServiceResponseDto debitPayment(String mobileNo,
			MerchantPaymentTransferRequestDto merchantPaymentTransferRequestDto, PaymentView sourcePaymentDetails) {

		log.info("inside debit payment using fabby channel");
		PaymentEntity paymentEntity = null;
		BigDecimal amount = merchantPaymentTransferRequestDto.getAmount();

		HttpHeaders headers = setHeaders(mobileNo);
		HttpEntity<PaymentTransferDto> request = new HttpEntity<>(
				new PaymentTransferDto(null, amount, sourcePaymentDetails.getAccountNo()), headers);

		ResponseEntity<GenericResponse> debit = restTemplate.exchange(debitUrl, HttpMethod.POST, request,
				GenericResponse.class);
		if (debit.getStatusCode().equals(HttpStatus.OK)) {
			MerchantEntity merchant = merchantRepo.findByMerchantId(merchantPaymentTransferRequestDto.getMerchantId());
			PaymentEntity payment = createMerchantTransactionEntity(merchantPaymentTransferRequestDto,
					sourcePaymentDetails, String.valueOf(merchant.getMccCd()), debit.getBody().getResult(), true);
			paymentEntity = paymentRepo.save(payment);
		} else {
			throw new BusinessException("417", "debit failed");
		}
		return createMerchantResponse(merchantPaymentTransferRequestDto, paymentEntity, sourcePaymentDetails, TYPE);
	}

}
