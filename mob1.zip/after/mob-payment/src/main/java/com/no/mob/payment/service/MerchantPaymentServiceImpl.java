package com.no.mob.payment.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.no.mob.payment.entity.PaymentEntity;
import com.no.mob.payment.entity.PaymentView;
import com.no.mob.payment.exceptions.BusinessException;
import com.no.mob.payment.model.MerchantPaymentTransferRequestDto;
import com.no.mob.payment.model.MerchantTransferServiceResponseDto;
import com.no.mob.payment.repo.MerchantRepo;
import com.no.mob.payment.repo.PaymentRepo;
import com.no.mob.payment.repo.PaymentViewRepo;
import com.no.mob.payment.util.TransactionsUtil;

@Service
public class MerchantPaymentServiceImpl implements MerchantPaymentService {

	@Autowired
	private PaymentViewRepo paymentViewRepo;

	@Autowired
	protected PaymentRepo paymentRepo;

	@Autowired
	protected MerchantRepo merchantRepo;

	@Autowired
	protected RestTemplate restTemplate;
	
	@Autowired
	@Qualifier("fabbyChannel")
	private ChannelType fabbyChannel;
	
	@Autowired
	@Qualifier("externalCardChannel")
	private ChannelType externalCardChannel;
	
	@Override
	public MerchantTransferServiceResponseDto makeMerchantPayment(String mobileNo,
			MerchantPaymentTransferRequestDto merchantPaymentTransferRequestDto) {

		PaymentView sourcePaymentDetails = paymentViewRepo.findByMobileNo(mobileNo)
				.orElseThrow(() -> new BusinessException("404", "Account Details Not Found"));

		if (sourcePaymentDetails.getAccountStatus() == 'N') {
			throw new BusinessException("417", "Source Account Deactivated");
		}

		if (merchantPaymentTransferRequestDto.getPaymentSource().equals(sourcePaymentDetails.getAccountNo())) {
			return fabbyChannel.debitPayment(mobileNo, merchantPaymentTransferRequestDto, sourcePaymentDetails);
		} else {
			return externalCardChannel.debitPayment(mobileNo, merchantPaymentTransferRequestDto, sourcePaymentDetails);
		}

		
	}

	protected PaymentEntity createMerchantTransactionEntity(
			MerchantPaymentTransferRequestDto merchantPaymentTransferRequestDto, PaymentView sourcePaymentDetails,
			String mccCode, Object balance, boolean isFabby) {
		PaymentEntity payment = new PaymentEntity();
		payment.setSenderId(sourcePaymentDetails.getCustomerId());
		payment.setCreatedDt(new Date());
		payment.setUpdatedDt(new Date());
		payment.setCountryCode(sourcePaymentDetails.getCountryCd());
		payment.setPaymentStatus(101);
		payment.setTransactionType(3);
		payment.setPaymentType("P2B");
		payment.setTransactionAmount(merchantPaymentTransferRequestDto.getAmount());
		payment.setBankAccountId(sourcePaymentDetails.getAccountId());
		payment.setBalanceAm(getBigDecimal(balance));
		payment.setReceiverId(merchantPaymentTransferRequestDto.getMerchantId());
		payment.setMccCode(mccCode);
		return payment;
	}

	protected MerchantTransferServiceResponseDto createMerchantResponse(
			MerchantPaymentTransferRequestDto merchantPaymentTransferRequestDto, PaymentEntity paymentEntity,
			PaymentView sourcePaymentDetails, String type) {

		MerchantTransferServiceResponseDto merchantTransferServiceResponseDto = new MerchantTransferServiceResponseDto();
		merchantTransferServiceResponseDto.setTransactionId(paymentEntity.getTransactionId().toString());
			merchantTransferServiceResponseDto.setType(type);
		merchantTransferServiceResponseDto
				.setStatus(TransactionsUtil.checkTransactionStatus(paymentEntity.getPaymentStatus()));
		merchantTransferServiceResponseDto
				.setCategory(TransactionsUtil.checkCategory(paymentEntity.getTransactionType()));
		merchantTransferServiceResponseDto.setAmount(merchantPaymentTransferRequestDto.getAmount().toString());
		merchantTransferServiceResponseDto.setDate(paymentEntity.getCreatedDt().getTime());
		merchantTransferServiceResponseDto.setAccountNumber(sourcePaymentDetails.getAccountNo());
		merchantTransferServiceResponseDto.setPaymentSource(merchantPaymentTransferRequestDto.getPaymentSource());
		return merchantTransferServiceResponseDto;
	}

	protected HttpHeaders setHeaders(String mobileNo) {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "application/json");
		headers.set("mobile_number", mobileNo);
		return headers;
	}

	public static BigDecimal getBigDecimal(Object value) {
		BigDecimal ret = null;
		if (value != null) {
			if (value instanceof BigDecimal) {
				ret = (BigDecimal) value;
			} else if (value instanceof String) {
				ret = new BigDecimal((String) value);
			} else if (value instanceof BigInteger) {
				ret = new BigDecimal((BigInteger) value);
			} else if (value instanceof Number) {
				ret = BigDecimal.valueOf((Double) value);
			} else if (value instanceof Double) {
				ret = BigDecimal.valueOf((Double) value);
			} else {
				throw new ClassCastException("Not possible to coerce [" + value + "] from class " + value.getClass()
						+ " into a BigDecimal.");
			}
		}
		return ret;
	}

}
