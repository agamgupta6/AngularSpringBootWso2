package com.no.mob.payment.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "tb_customer_concent")
public class CustomerConcent {
	
	@Id
	@SequenceGenerator(name="seq",sequenceName="customer_concent_id_seq", schema="payment", allocationSize = 1)
	@GeneratedValue(generator="seq",strategy=GenerationType.SEQUENCE)
	@Column(name = "concent_id", columnDefinition = "NUMERIC(12,0)", nullable = false) 
	private Long concentId;
	@Column(name="customer_id")
	private Long customerId;
	@Column(name="merchant_id")
	private Long merchantId;
	@Column(name="merchant_nm")
	private String merchantNm;
	@Column(name="merchant_logo")
	private String merchantLogo;
	@Column(name="concent")
	private Boolean concent;

}
