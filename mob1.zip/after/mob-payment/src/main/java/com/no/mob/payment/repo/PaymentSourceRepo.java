package com.no.mob.payment.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.no.mob.payment.entity.PaymentSource;

@Repository
public interface PaymentSourceRepo extends CrudRepository<PaymentSource, Long> {
	
	public Optional<List<PaymentSource>> findByPaymentSourceId(long customerId);

    public Optional<List<PaymentSource>> findByCustomerId(long customerId);

    public Optional<List<PaymentSource>> findByCardNumber(Long cardNo);



}
