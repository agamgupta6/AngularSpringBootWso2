package com.no.mob.payment.service;

import java.util.List;

import com.no.mob.payment.model.ConcentDetailsResponseDto;
import com.no.mob.payment.model.OfferDetailsResponseDto;

public interface OffersService {

	public OfferDetailsResponseDto fetchOfferDetails(String beaconCode, String mobileNumber);
	
	public OfferDetailsResponseDto setConcentDetails(String merchantId, String mobileNumber);

	public List<ConcentDetailsResponseDto> updateConcentValue(boolean value, String mobileNumber, String merchantId);

}
