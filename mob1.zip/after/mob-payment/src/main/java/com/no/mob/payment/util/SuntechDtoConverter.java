package com.no.mob.payment.util;


import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

import lombok.extern.slf4j.Slf4j;

import com.no.mob.payment.suntech.model.EntityTagMapping;
import com.no.mob.payment.suntech.model.ResponseObj;
import com.no.mob.payment.suntech.model.SuntechIntegrationRequestDto;
import com.no.mob.payment.suntech.model.SuntechRequestDto;
import com.no.mob.payment.suntech.model.SuntechResponseDto;
@Slf4j
public class SuntechDtoConverter {
	
	private SuntechDtoConverter() {
		// private constructor
	}

	public static final Function<SuntechRequestDto, SuntechIntegrationRequestDto> REQUESTCONVERTOR = req -> {
		SuntechIntegrationRequestDto obj = new SuntechIntegrationRequestDto();
		
		log.info("Inside the suntech porduct recommentation request converter" );

		if (!req.getBotTag().isEmpty()){
			if (req.getBotTag().equalsIgnoreCase("RISKY")) {
				obj.setSearchTag("DNB05");
			}
			else if (req.getBotTag().equalsIgnoreCase("LOW RISKY")) {
				obj.setSearchTag("DNB06");
			}
			else if (req.getBotTag().equalsIgnoreCase("MEDIUM RISKY")) {
				obj.setSearchTag("DNB07");
			}
			else {
				obj.setSearchTag("DNB08");
			}
		}
		else if (req.getTransactionCount() > 0) {
			if (req.getTransactionCount() >= 5 && req.getTransactionCount() <= 10) {
				obj.setSearchTag("DNB01");
			}
			else if (req.getTransactionCount() >= 10) {
				obj.setSearchTag("DNB04");
			}
		}
		else if (!req.getMerchantCode().isEmpty() && req.getMerchantCode().equalsIgnoreCase("7285217")){
				obj.setSearchTag("DNB02");
		}
		
		return obj;
	};
	
	public static final Function<ResponseObj, List<SuntechResponseDto>> RESPONSECONVERTOR = req -> {
		
		log.info("Inside the suntech porduct recommentation request converter" );
		List<SuntechResponseDto> listOfResponse = new ArrayList<>();
		for (EntityTagMapping objMapping : req.getEntityTagMapping()) {
			SuntechResponseDto obj = new SuntechResponseDto();
			obj.setEntityCode(objMapping.getEtmEntityCode());
			obj.setEntityImage(objMapping.getEntityDescription());
			obj.setEntityName(objMapping.getEntityName());
			obj.setEntityUri(objMapping.getEtmStlUid());
			
			listOfResponse.add(obj);
		}
		
		return listOfResponse;
	};
}
