package com.no.mob.payment.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentSourceRequestDto {

	private Long cardNumber;
	private Long customerId;
}
