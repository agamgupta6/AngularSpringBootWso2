package com.no.mob.payment.common;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * This dto contains the details of an error or exception occurs, the error code
 * and error message is wrapped using this class.
 * 
 * @author AB04529
 *
 */
@Setter
@Getter
public class ErrorDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6737063923611306600L;

	@JsonInclude
	private String errorCode;

	@JsonIgnore
	private String errorMsgKey;

	public ErrorDetails(String errorCode, String errorMessageKey) {
		this.errorCode = errorCode;
		this.errorMsgKey = errorMessageKey;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public String getErrorKey() {
		return errorMsgKey;
	}
}
