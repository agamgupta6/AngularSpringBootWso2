package com.no.mob.payment.util;

import java.math.BigDecimal;
import java.util.Currency;
import java.util.Locale;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.no.mob.payment.exceptions.BusinessException;


@Component
public class CurrencyConverter {

	private Logger log = LoggerFactory.getLogger(this.getClass());

	@Value("${currency.conversion.url}")
	private String url;

	public BigDecimal convertRequestedAmount(BigDecimal amount, String countryCode, String targetCountryCode) {
		log.info("Entering currency conversion api with amount {} and country Codes {} and {}", amount, countryCode,
				targetCountryCode);
		String sourceCurrencyCd = CurrencyConverter.getCurrencyCode(countryCode);
		String targetCurrencyCd = CurrencyConverter.getCurrencyCode(targetCountryCode);
		String updatedUrl = url + sourceCurrencyCd + "_" + targetCurrencyCd;
		RestTemplate restTemplate = new RestTemplate();
		log.info("Entering currency conversion api with url {}", updatedUrl);
		String myResponse = restTemplate.getForObject(updatedUrl, String.class);
		log.info("Currency conversion response = {}", myResponse);

		try {
			BigDecimal convertedAmount = new BigDecimal(new JSONObject(myResponse).getJSONObject("results")
					.getJSONObject(sourceCurrencyCd + "_" + targetCurrencyCd).get("val").toString());
			return convertedAmount.multiply(amount);
		} catch (JSONException e) {
			log.error("currency conversion exception ocured with exception {}", e.getMessage());
			throw new BusinessException("499", "Something Went Wrong..Please Try again");

		}

	}

	public static String getCurrencyCode(String countryCode) {
		return Currency.getInstance(new Locale("", countryCode)).getCurrencyCode();
	}
}
