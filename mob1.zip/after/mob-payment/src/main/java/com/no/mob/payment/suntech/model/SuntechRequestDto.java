package com.no.mob.payment.suntech.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SuntechRequestDto {

	private int transactionCount;
	private String merchantCode;
	private String botTag;
}
