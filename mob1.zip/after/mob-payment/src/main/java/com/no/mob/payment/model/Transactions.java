package com.no.mob.payment.model;

import java.util.Objects;

import org.joda.time.DateTime;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * Transactions
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2017-12-21T06:56:41.040Z")

public class Transactions {
	@JsonProperty("name")
	private String name = null;

	@JsonProperty("date")
	private DateTime date = null;

	@JsonProperty("type")
	private String type = null;

	@JsonProperty("transferType")
	private String transferType = null;

	@JsonProperty("category")
	private String category = null;

	@JsonProperty("amount")
	private Long amount = null;

	public Transactions name(String name) {
		this.name = name;
		return this;
	}

	/**
	 * Get name
	 * 
	 * @return name
	 **/
	@ApiModelProperty(value = "")

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	

	public Transactions date(DateTime date) {
		this.date = date;
		return this;
	}

	/**
	 * Get date
	 * 
	 * @return date
	 **/
	@ApiModelProperty(value = "")

	public DateTime getDate() {
		return date;
	}

	public void setDate(DateTime date) {
		this.date = date;
	}

	
	public Transactions type(String type) {
		this.type = type;
		return this;
	}

	/**
	 * Get type
	 * 
	 * @return type
	 **/
	@ApiModelProperty(value = "")

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	
	public Transactions amount(Long amount) {
		this.amount = amount;
		return this;
	}

	/**
	 * Get amount
	 * 
	 * @return amount
	 **/
	@ApiModelProperty(value = "")

	public Long getAmount() {
		return amount;
	}

	public void setAmount(Long amount) {
		this.amount = amount;
	}

	public Transactions transferType(String transferType) {
		this.transferType = transferType;
		return this;
	}

	/**
	 * Get transferType
	 * 
	 * @return transferType
	 **/
	@ApiModelProperty(value = "")

	public String getTransferType() {
		return transferType;
	}

	public void setTransferType(String transferType) {
		this.transferType = transferType;
	}

	public Transactions category(String category) {
		this.category = category;
		return this;
	}

	/**
	 * Get category
	 * 
	 * @return category
	 **/
	@ApiModelProperty(value = "")

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		Transactions transactions = (Transactions) o;
		return Objects.equals(this.name, transactions.name) && Objects.equals(this.type, transactions.type)
				&& Objects.equals(this.date, transactions.date) && Objects.equals(this.amount, transactions.amount)
				&& Objects.equals(this.transferType, transactions.transferType)
				&& Objects.equals(this.category, transactions.category);
	}

	@Override
	public int hashCode() {
		return Objects.hash(name, type, date, amount, transferType, category);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class Transactions {\n");

		sb.append("    name: ").append(toIndentedString(name)).append("\n");
		sb.append("    type: ").append(toIndentedString(type)).append("\n");
		sb.append("    date: ").append(toIndentedString(date)).append("\n");
		sb.append("    amount: ").append(toIndentedString(amount)).append("\n");
		sb.append("    transferType: ").append(toIndentedString(transferType)).append("\n");
		sb.append("    category: ").append(toIndentedString(category)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}
}
