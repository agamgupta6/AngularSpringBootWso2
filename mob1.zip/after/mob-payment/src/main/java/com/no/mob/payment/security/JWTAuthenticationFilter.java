package com.no.mob.payment.security;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.no.mob.payment.common.CommonUtils;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;

@Component
public class JWTAuthenticationFilter {
	
	@Value("${mob.create.token.code}")
    private String tokenCode;
	
	private Logger log = LoggerFactory.getLogger(this.getClass());

	public String genetareSecret(String key) {
		return CommonUtils.hashEmail(key, tokenCode);
	}

	public boolean validateToken(String jwt, String identifier) {
		
		log.debug("identifier = {}",identifier);
		Boolean isValid = false;
		Claims claim = Jwts.parser()
				.setSigningKey(genetareSecret(identifier).getBytes())
				.parseClaimsJws(jwt).getBody();
		if ((claim.getExpiration().compareTo(new Date(System.currentTimeMillis()))) == 1 &&
				claim.getSubject().equalsIgnoreCase(identifier)) {
			log.debug("inside validate token expiration check");
			isValid = true;
		}
		return isValid;
	}

}
