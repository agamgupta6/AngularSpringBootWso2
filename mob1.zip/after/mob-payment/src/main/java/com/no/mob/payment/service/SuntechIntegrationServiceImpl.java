package com.no.mob.payment.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.no.mob.payment.suntech.model.EntityTagMapping;
import com.no.mob.payment.suntech.model.ResponseObj;
import com.no.mob.payment.suntech.model.SuntechIntegrationRequestDto;
import com.no.mob.payment.suntech.model.SuntechRequestDto;
import com.no.mob.payment.suntech.model.SuntechResponseDto;
import com.no.mob.payment.util.SuntechDtoConverter;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SuntechIntegrationServiceImpl implements SuntechIntegrationService {

	private static final String ACTIV_JPG = "activ.jpg";
	private static final String BASE_URL = "https://s3-eu-west-1.amazonaws.com/digiapp/";
	@Value("${suntech.integration.uri}")
	private String suntechIntegrationUrl;

	@Override
	public List<SuntechResponseDto> getProductRecommentation(SuntechRequestDto requestDto) {
		log.info("Inside the suntech porduct recommentation service: Request object {}", requestDto);
		SuntechIntegrationRequestDto integrationRequestDto = SuntechDtoConverter.REQUESTCONVERTOR.apply(requestDto);
		ResponseObj responseObj = createReponse(integrationRequestDto);
		log.info("End suntech porduct recommentation service response : {}", responseObj);

		return SuntechDtoConverter.RESPONSECONVERTOR.apply(responseObj);
	}

	private void populateEntityTagMapping(EntityTagMapping tagMapping, String entityName, String entityCode,
			String entityDesc, String etmStlUid) {
		tagMapping.setEntityName(entityName);
		tagMapping.setEtmEntityCode(entityCode);
		tagMapping.setEntityDescription(entityDesc);
		tagMapping.setEtmStlUid(etmStlUid);
	}

	private ResponseObj createReponse(SuntechIntegrationRequestDto integrationRequestDto) {

		log.info("Inside the dummy response creator");

		ResponseObj responseObj = new ResponseObj();
		List<EntityTagMapping> listTagMapping = new ArrayList<>();
		EntityTagMapping tagMapping = new EntityTagMapping();
		if (integrationRequestDto.getSearchTag().equalsIgnoreCase("DNB01")) {
			populateEntityTagMapping(tagMapping, "Saga Credit Card", "DNB01",
					BASE_URL + "product_01_saga_credit_card.png", "https://www.dnb.no/privat/saga/kort.html");
		} else if (integrationRequestDto.getSearchTag().equalsIgnoreCase("DNB04")) {
			populateEntityTagMapping(tagMapping, "Pensjonssparing", "DNB04", BASE_URL + "maxresdefault.jpg",
					"https://www.dnb.no/privat/pensjon.html");
		} else if (integrationRequestDto.getSearchTag().equalsIgnoreCase("DNB05")) {
			populateEntityTagMapping(tagMapping, "DNB Aktiv 100", "DNB05", BASE_URL + ACTIV_JPG,
					"https://www.dnb.no/en/personal/savings-and-investments/funds/aktiv100.html");
		} else if (integrationRequestDto.getSearchTag().equalsIgnoreCase("DNB02")) {
			populateEntityTagMapping(tagMapping, "Spedbarnsforsikring", "DNB02", BASE_URL + "Spedbarnsforsikring.jpg",
					"https://www.dnb.no/privat/forsikring/spedbarnsforsikring.html");
		} else if (integrationRequestDto.getSearchTag().equalsIgnoreCase("DNB06")) {
			populateEntityTagMapping(tagMapping, "DNB Aktiv 50", "DNB06", BASE_URL + ACTIV_JPG,
					"https://www.dnb.no/en/personal/savings-and-investments/funds/aktiv50.html");
		} else if (integrationRequestDto.getSearchTag().equalsIgnoreCase("DNB07")) {
			populateEntityTagMapping(tagMapping, "DNB Aktiv 30", "DNB07", BASE_URL + ACTIV_JPG,
					"https://www.dnb.no/en/personal/savings-and-investments/funds/aktiv30.html");
		} else if (integrationRequestDto.getSearchTag().equalsIgnoreCase("DNB08")) {
			populateEntityTagMapping(tagMapping, "Car Loans", "DNB08", BASE_URL + "product_08_car-loans.png",
					"https://www.dnb.no/privat/laan/billaan.html");
		}

		listTagMapping.add(tagMapping);
		responseObj.setEntityTagMapping(listTagMapping);
		log.info("End the dummy response creator");

		return responseObj;
	}

}
