package com.no.mob.payment.model;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class PaymentTransferDto {

	ResponseInfo responseInfo;
	
	private BigDecimal amount;
	
	private String accountNo;
}
