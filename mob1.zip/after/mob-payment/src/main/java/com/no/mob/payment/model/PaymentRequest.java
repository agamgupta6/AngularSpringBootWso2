package com.no.mob.payment.model;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class PaymentRequest {

	private int id;
	private Long targetAccount;
	private Long sourceAccount;
	private BigDecimal amount;
	private String currency;
	private String reference;
	private Date created;
	private String transferRequest;
	private String swift;
	private String iban;
	private int cvv;
	private int cardExpiryDate;
	private long cardNumber;
	private String cardType;

}
