package com.no.mob.payment.model;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;
import lombok.ToString;

/**
 * TransactionHistoryResponseDtoResultTransactions
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-01-04T07:26:20.605Z")

@ToString
public class TransactionHistoryResponseDtoResultTransactions   {
	
  @JsonProperty("transactionId")
  private String transactionId;
  
  @JsonProperty("name")
  private String name = null;

  @JsonProperty("type")
  private String type = null;

  @JsonProperty("date")
  private String date = null;

  @JsonProperty("amount")
  private String amount = null;

  @JsonProperty("transferType")
  private String transferType = null;

  @JsonProperty("category")
  private String category = null;

  @JsonProperty("status")
  private String status = null;

  @JsonProperty("countryCode")
  private String countryCode = null;
  
  @JsonProperty("paymentSource")
  private String paymentSource = null;
  
  @JsonProperty("accountNumber")
  private String accountNumber = null;

  public TransactionHistoryResponseDtoResultTransactions name(String name) {
    this.name = name;
    return this;
  }

   public String getPaymentSource() {
	return paymentSource;
}

public void setPaymentSource(String paymentSource) {
	this.paymentSource = paymentSource;
}

public String getAccountNumber() {
	return accountNumber;
}

public void setAccountNumber(String accountNumber) {
	this.accountNumber = accountNumber;
}

/**
   * Get name
   * @return name
  **/
  @ApiModelProperty(value = "")


  public String getName() {
    return name;
  }

  public String getTransactionId() {
	return transactionId;
}

public void setTransactionId(String transactionId) {
	this.transactionId = transactionId;
}

public void setName(String name) {
    this.name = name;
  }

  public TransactionHistoryResponseDtoResultTransactions type(String type) {
    this.type = type;
    return this;
  }

   /**
   * Get type
   * @return type
  **/
  @ApiModelProperty(value = "")


  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public TransactionHistoryResponseDtoResultTransactions date(String date) {
    this.date = date;
    return this;
  }

   /**
   * Get date
   * @return date
  **/
  @ApiModelProperty(value = "")


  public String getDate() {
	 return this.date;
  }

  public void setDate(Long date) {
	 DateFormat df = new SimpleDateFormat("dd MMM yyyy  HH:mm:ss");
    this.date = df.format(date);
  }

  public TransactionHistoryResponseDtoResultTransactions amount(String amount) {
    this.amount = amount;
    return this;
  }

   /**
   * Get amount
   * @return amount
  **/
  @ApiModelProperty(value = "")


  public String getAmount() {
    return amount;
  }

  public void setAmount(String amount) {
    this.amount = amount;
  }

  public TransactionHistoryResponseDtoResultTransactions transferType(String transferType) {
    this.transferType = transferType;
    return this;
  }

   /**
   * Get transferType
   * @return transferType
  **/
  @ApiModelProperty(value = "")


  public String getTransferType() {
    return transferType;
  }

  public void setTransferType(String transferType) {
    this.transferType = transferType;
  }

  public TransactionHistoryResponseDtoResultTransactions category(String category) {
    this.category = category;
    return this;
  }

   /**
   * Get category
   * @return category
  **/
  @ApiModelProperty(value = "")


  public String getCategory() {
    return category;
  }

  public void setCategory(String category) {
    this.category = category;
  }

  public TransactionHistoryResponseDtoResultTransactions status(String status) {
    this.status = status;
    return this;
  }

   /**
   * Get status
   * @return status
  **/
  @ApiModelProperty(value = "")


  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public TransactionHistoryResponseDtoResultTransactions currencyCode(String countryCode) {
    this.countryCode = countryCode;
    return this;
  }

   /**
   * Get currencyCode
   * @return currencyCode
  **/
  @ApiModelProperty(value = "")


  public String getCountryCode() {
    return countryCode;
  }

  public void setCountryCode(String countryCode) {
    this.countryCode = countryCode;
  }

  }

