package com.no.mob.payment.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.no.mob.payment.entity.BeneficiaryDetails;

@Repository
public interface PaymentDetailsRepo extends CrudRepository<BeneficiaryDetails, Long> {
	
	public Optional<List<BeneficiaryDetails>> findByCustomerId(Long customerId);

	public BeneficiaryDetails findByAccountNumber(String valueOf);
	
	public Optional<List<BeneficiaryDetails>> findByPayeeIdOrAccountNumber(Long payeeId,String accountNumber);
	
	public Optional<BeneficiaryDetails> findByPayeeId(Long receiverId);



}
