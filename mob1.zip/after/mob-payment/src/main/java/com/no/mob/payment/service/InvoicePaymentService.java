package com.no.mob.payment.service;

import com.no.mob.payment.model.InvoicePaymentRequestDto;
import com.no.mob.payment.model.TransferServiceResponseDto;

public interface InvoicePaymentService {

	public TransferServiceResponseDto makeInvoicePayment(InvoicePaymentRequestDto invoicePaymentRequestDto, String mobileNumber);
}
