package com.no.mob.payment.model;

public enum PaymentStatus {

	SUCCESS(101), FAILED(102), PENDING(103);
	
	PaymentStatus(int i){
		
	}
	
}

