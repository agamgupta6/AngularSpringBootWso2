package com.no.mob.payment.model;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InvoiceRequest {
	
	private int id;
	private Long targetAccount;
	private Long sourceAccount;
	private Long kidNo;
	private String dueDate;
	private BigDecimal amount;
	private String currency;
	private String reference;
	private String createdDt;
}
