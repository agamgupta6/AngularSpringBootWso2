package com.no.mob.payment.service

import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.client.RestTemplate

import com.no.mob.payment.common.GenericResponse
import com.no.mob.payment.entity.PaymentView
import com.no.mob.payment.meniga.response.TransactionSeriesResponse
import com.no.mob.payment.meniga.response.TransactionSeriesResponseDto
import com.no.mob.payment.meniga.response.Transactions
import com.no.mob.payment.meniga.response.Values
import com.no.mob.payment.model.PfmDetailsResponseDto
import com.no.mob.payment.repo.PaymentViewRepo

import spock.lang.Specification

class PfmServiceSpec extends Specification{

    def "Test Success Scenario for fetchPfmTransactionDetails method"(){

        given:
        String mobileNumber = "12346"
        String targetDt="05-2019"

        GenericResponse response = new GenericResponse();
        ResponseEntity resp = new ResponseEntity<>(response,HttpStatus.OK)

        RestTemplate restTemplate = Mock(RestTemplate.class)
        restTemplate.getForEntity(_) >> resp

        PaymentView paymentView = new PaymentView()
        paymentView.setAccountNo("1")
        paymentView.setAccountStatus('Y' as char)
        paymentView.setBalanceAmount(BigDecimal.TEN)
        //paymentView.setCardNo("1234567890123456")
        //paymentView.setCountryCd("NO")
        paymentView.setFirstName("first")
        paymentView.setLastName("lastName")
        paymentView.setMobileNo("98765432")
        paymentView.setStatusId("1")
        paymentView.setCustomerId(123456L)

        PaymentViewRepo paymentViewRepo = Mock(PaymentViewRepo.class)
        paymentViewRepo.findByMobileNo(_) >> Optional.ofNullable(paymentView)

        PfmServiceImpl service = new PfmServiceImpl()
        service.paymentViewRepo = paymentViewRepo
        service.restTemplate = restTemplate

        when:
        PfmDetailsResponseDto respon = service.fetchPfmTransactionDetails(mobileNumber,targetDt )

        then:
        respon == null

    }

    def "Test Success Scenario for fetchPfmDetails method"(){

        given:
        String mobileNumber = "12346"
        String targetDt="05-2014"

        TransactionSeriesResponseDto response = new TransactionSeriesResponseDto();
		
		List<TransactionSeriesResponse> datas = new ArrayList();
		TransactionSeriesResponse data = new TransactionSeriesResponse();
		List<Transactions> transactions = new ArrayList();
		data.setTransactions(transactions);
		
		data.setTransactions(transactions);
		Values value = new Values();
		value.setNettoAmount(12L);
		List<Values> values = new ArrayList<>();
		values.add(value);
		data.setValues(values);
		datas.add(data);
		response.setData(datas);
		
        ResponseEntity<TransactionSeriesResponseDto> result = new ResponseEntity<TransactionSeriesResponseDto>(response,HttpStatus.OK)

        RestTemplate restTemplate = Mock(RestTemplate.class)
        restTemplate.exchange(_,_,_,TransactionSeriesResponseDto.class) >> result

        PaymentView paymentView = new PaymentView()
        paymentView.setAccountNo("1")
		paymentView.setAccountId(1L);
        paymentView.setAccountStatus('Y' as char)
        paymentView.setBalanceAmount(BigDecimal.TEN)
        //paymentView.setCardNo("1234567890123456")
        //paymentView.setCountryCd("NO")
        paymentView.setFirstName("first")
        paymentView.setLastName("lastName")
        paymentView.setMobileNo("98765432")
        paymentView.setStatusId("1")
        paymentView.setCustomerId(123456L)

        PaymentViewRepo paymentViewRepo = Mock(PaymentViewRepo.class)
        paymentViewRepo.findByMobileNo(_) >> Optional.ofNullable(paymentView)

        PfmServiceImpl service = new PfmServiceImpl()
        service.paymentViewRepo = paymentViewRepo
        service.restTemplate = restTemplate

        when:
        PfmDetailsResponseDto respon = service.fetchPfmDetails(mobileNumber,targetDt )
		System.out.println(respon)

        then:
        respon.getTotalAmount() == result.getBody().getData().get(0).getValues().get(0).getNettoAmount().toString()

    }
}
