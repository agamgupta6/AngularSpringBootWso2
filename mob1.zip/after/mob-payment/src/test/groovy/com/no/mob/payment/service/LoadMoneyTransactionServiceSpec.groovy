package com.no.mob.payment.service

import org.springframework.web.client.RestTemplate

import com.no.mob.payment.entity.PaymentEntity
import com.no.mob.payment.entity.PaymentSource
import com.no.mob.payment.entity.PaymentView
import com.no.mob.payment.exceptions.BusinessException
import com.no.mob.payment.model.CardDetailsRequestDto
import com.no.mob.payment.model.LoadMoneyRequestDto
import com.no.mob.payment.repo.PaymentRepo
import com.no.mob.payment.repo.PaymentSourceRepo
import com.no.mob.payment.repo.PaymentViewRepo
import com.no.mob.payment.util.CurrencyConverter
import com.no.mob.payment.util.TransactionsUtil

import spock.lang.Specification

class LoadMoneyTransactionServiceSpec extends Specification {
	
	def "Test Success Scenario for loadMoneyInAccount method"(){
		
		given:
		LoadMoneyTransactionService loadMoneyTransactionService = new LoadMoneyTransactionServiceImpl();
		
		CurrencyConverter currencyConverter = new CurrencyConverter();
		currencyConverter.url = "http://url@test.com";
		
		String mobileNumber = "974756123";
		String accessToken = "abcd";
		
		LoadMoneyRequestDto dto = new LoadMoneyRequestDto();
		CardDetailsRequestDto cardRequestDto = new CardDetailsRequestDto();
		dto.setAmount(100);
		dto.setCurrency("NO");
		cardRequestDto.setCardExpiry("01/09/2019");
		cardRequestDto.setCardNumber(12345678910);
		cardRequestDto.setCardType("NEW");
		cardRequestDto.setCvv2(123);
		dto.setCardDetails(cardRequestDto);
		
		PaymentView paymentView = new PaymentView();
		paymentView.setCustomerId(1234567981L)
		paymentView.setAccountId(1234567894562);
		paymentView.setAccountNo("123456789");
		paymentView.setBalanceAmount(45610);
		paymentView.setFirstName("test");
		paymentView.setMobileNo("974756123");
		paymentView.setCountryCd("NO")
		
		PaymentSource paymentSource = new PaymentSource();
		paymentSource.setPaymentSourceId(123456789)
		paymentSource.setCustomerId(paymentView.getCustomerId());
		paymentSource.setActiveIn('Y' as char);
		paymentSource.setCardNumber(1236547895623);
		
		PaymentEntity paymentEntity = new PaymentEntity();
		paymentEntity.setCountryCode("NOK");
		paymentEntity.setBankAccountId(123456789562);
		paymentEntity.setSenderId(1234568974123);
		paymentEntity.setReceiverId(123564789);
		paymentEntity.setPaymentType("P2P");
		paymentEntity.setTransactionType(2);
		paymentEntity.setTransactionId(13463131L);
		paymentEntity.setTransactionAmount(100);
		paymentEntity.setTransactionText("Load Money to Card");
		paymentEntity.setPaymentStatus(101);
		paymentEntity.setCreatedDt(new Date());
		paymentEntity.setUpdatedDt(new Date());
		
		List<PaymentSource> paymentSources = new ArrayList();
		paymentSources.add(paymentSource);
		
		
		def paymentViewRepo =  Mock(PaymentViewRepo.class);
		paymentViewRepo.findByMobileNo(_) >> Optional.ofNullable(paymentView);
		loadMoneyTransactionService.paymentViewRepo = paymentViewRepo;
		
		def paymentSourceRepo = Mock(PaymentSourceRepo.class);
		paymentSourceRepo.findByCardNumber(_) >>  Optional.ofNullable(paymentSources);
		paymentSourceRepo.save(_) >> paymentSource
		loadMoneyTransactionService.paymentSourceRepo = paymentSourceRepo;
		paymentViewRepo.findByCardNo(_) >> Optional.ofNullable(paymentView);
		
		def restTemplate = Mock(RestTemplate.class)
		restTemplate.postForObject(_,_,String.class) >>"Hello"
		loadMoneyTransactionService.restTemplate = restTemplate;
		
		def paymentRepo = Mock(PaymentRepo.class)
		paymentRepo.save(_) >>> paymentEntity
		loadMoneyTransactionService.paymentRepo = paymentRepo;
		
		TransactionsUtil transactionsUtil = Mock {TransactionsUtil.class}
		transactionsUtil.populateNameOrAccountNo(_)>> "accountNo"
		loadMoneyTransactionService.transactionsUtil = transactionsUtil
		
		when:
		loadMoneyTransactionService.loadMoneyInAccount(dto,mobileNumber,accessToken);
		then:
		"money loaded mocked"
	}
	
	def "Test Failure Scenario Invalid Customer method"(){
		
		given:
		LoadMoneyTransactionService loadMoneyTransactionService = new LoadMoneyTransactionServiceImpl();
		
		String mobileNumber = "974756123";
		String accessToken = "abcd";
		
		LoadMoneyRequestDto dto = new LoadMoneyRequestDto();
		CardDetailsRequestDto cardRequestDto = new CardDetailsRequestDto();
		dto.setAmount(100);
		dto.setCurrency("NOK");
		cardRequestDto.setCardExpiry("01/12/2020");
		cardRequestDto.setCardNumber(12345678910);
		cardRequestDto.setCardType("NEW");
		cardRequestDto.setCvv2(123);
		dto.setCardDetails(cardRequestDto);
		
		PaymentView paymentView = new PaymentView();
		paymentView.setAccountId(1234567894562);
		paymentView.setAccountNo("123456789");
		paymentView.setAccountStatus('Y' as char);
		paymentView.setBalanceAmount(45610);
		paymentView.setFirstName("test");
		paymentView.setMobileNo("974756123");
		
		def paymentViewRepo =  Mock(PaymentViewRepo.class);
		paymentViewRepo.findByMobileNo(_) >> Optional.empty()
		loadMoneyTransactionService.paymentViewRepo = paymentViewRepo;

		when:
		loadMoneyTransactionService.loadMoneyInAccount(dto,mobileNumber,accessToken);
		then:
		BusinessException e = thrown()
		e.getErrorDetails().getErrorCode() == "422"
		e.getErrorDetails().getErrorMsgKey() == "Customer not found.!"
	}
	

}
