package com.no.mob.payment.service

import com.no.mob.payment.entity.CustomerBeaconOffer
import com.no.mob.payment.entity.CustomerConcent
import com.no.mob.payment.entity.MerchantEntity
import com.no.mob.payment.entity.OfferDetails
import com.no.mob.payment.entity.PaymentView
import com.no.mob.payment.model.OfferDetailsResponseDto
import com.no.mob.payment.repo.CustomerBeaconRepo
import com.no.mob.payment.repo.CustomerConcentRepo
import com.no.mob.payment.repo.MerchantRepo
import com.no.mob.payment.repo.OfferDetailsRepo
import com.no.mob.payment.repo.PaymentViewRepo
import spock.lang.Specification

import java.sql.Date

class OfferServiceSpec extends Specification{

    def "Test Success Scenario for fetchOfferDetails method"(){

        given:
        String beaconCode = "12346"
        String mobileNumber="123456789"

        PaymentView paymentView = new PaymentView()
        paymentView.setAccountNo("1")
        paymentView.setAccountStatus('Y' as char)
        paymentView.setBalanceAmount(BigDecimal.TEN)
        //paymentView.setCardNo("1234567890123456")
        //paymentView.setCountryCd("NO")
        paymentView.setFirstName("first")
        paymentView.setLastName("lastName")
        paymentView.setMobileNo("98765432")
        paymentView.setStatusId("1")
        paymentView.setCustomerId(123456L)

        PaymentViewRepo paymentViewRepo = Mock(PaymentViewRepo.class)
        paymentViewRepo.findByMobileNo(_) >> Optional.ofNullable(paymentView)

        CustomerBeaconOffer customerBeaconOffer = null

        CustomerBeaconRepo customerBeaconRepo = Mock(CustomerBeaconRepo.class)
        customerBeaconRepo.findByBeaconCodeAndCustomerId(_) >> customerBeaconOffer

        OfferDetails offerDetails = new OfferDetails()
        offerDetails.setMerchantId(23456L)
        offerDetails.setBeaconCode("56423")
        offerDetails.setExpiryPeriod(25)
        offerDetails.setOfferId(56478L)
        offerDetails.setRate(BigDecimal.ONE)

        OfferDetailsRepo offerDetailsRepo = Mock(OfferDetailsRepo.class)
        offerDetailsRepo.findByBeaconCode(_) >> offerDetails

        MerchantEntity merchant = new MerchantEntity();
        merchant.setAccountNo(987654123L)
        merchant.setLogoUrl("http://sample.com/")
        merchant.setMerchantId(123456L)
        merchant.setMerchantName("Joseph")

        MerchantRepo merchantRepo = Mock(MerchantRepo.class)
        merchantRepo.findByMerchantId(_) >> merchant

        CustomerBeaconOffer customerBeaconOffer1 = new CustomerBeaconOffer()
        customerBeaconOffer1.setAccountNo(123456L)
        customerBeaconOffer1.setCustomerId(1234567L)
        customerBeaconOffer1.setDiscountRate(BigDecimal.ONE)
        customerBeaconOffer1.setExpiryDt(new java.util.Date())
        customerBeaconOffer1.setMerchantId(12345687L)
        customerBeaconOffer1.setMerchantNm("Robert")
        customerBeaconOffer1.setMerchantLogo("ABCD")
        customerBeaconOffer1.setStatus(0)
        customerBeaconOffer1.setConcent(true)
        List<CustomerBeaconOffer> list = new ArrayList<CustomerBeaconOffer>()
        list.add(customerBeaconOffer1)

        customerBeaconRepo.findByCustomerId(_) >> Optional.ofNullable(list)
        customerBeaconRepo.save(_)
		
		CustomerConcentRepo customerConcentRepo = Mock(CustomerConcentRepo.class);
		CustomerConcent customerConcent = new CustomerConcent();
		customerConcent.setConcent(true);
		customerConcent.setConcentId(1L);
		customerConcent.setCustomerId(1L);
		customerConcent.setMerchantId(1L);
		customerConcentRepo.findByCustomerIdAndMerchantId(_, _)>> Optional.ofNullable(customerConcent);
		
		
        OffersServiceImpl service = new OffersServiceImpl()
        service.paymentViewRepo = paymentViewRepo
        service.customerBeaconRepo = customerBeaconRepo
        service.merchantRepo = merchantRepo
        service.offerDetailsRepo = offerDetailsRepo
		service.customerConcentRepo = customerConcentRepo;

        when:
        OfferDetailsResponseDto beaconDetailsResponseDto = service.fetchOfferDetails(beaconCode, mobileNumber)

        then:
        beaconDetailsResponseDto.isNewData() == true
    }

    def "Test Success Scenario for setConcentDetails method"(){

        given:
        String merchantId = "12346"
        String mobileNumber="123456789"

        PaymentView paymentView = new PaymentView()
        paymentView.setAccountNo("1")
        paymentView.setAccountStatus('Y' as char)
        paymentView.setBalanceAmount(BigDecimal.TEN)
        //paymentView.setCardNo("1234567890123456")
        //paymentView.setCountryCd("NO")
        paymentView.setFirstName("first")
        paymentView.setLastName("lastName")
        paymentView.setMobileNo("98765432")
        paymentView.setStatusId("1")
        paymentView.setCustomerId(123456L)

        PaymentViewRepo paymentViewRepo = Mock(PaymentViewRepo.class)
        paymentViewRepo.findByMobileNo(_) >> Optional.ofNullable(paymentView)

        CustomerBeaconOffer customerBeaconOffer = new CustomerBeaconOffer()

        CustomerBeaconRepo customerBeaconRepo = Mock(CustomerBeaconRepo.class)
        customerBeaconRepo.findByCustomerIdAndMerchantId(_,_) >> Optional.ofNullable(customerBeaconOffer)
        customerBeaconRepo.save(_)

        CustomerBeaconOffer customerBeaconOffer1 = new CustomerBeaconOffer()
        customerBeaconOffer1.setAccountNo(123456L)
        customerBeaconOffer1.setCustomerId(1234567L)
        customerBeaconOffer1.setDiscountRate(BigDecimal.ONE)
        customerBeaconOffer1.setExpiryDt(new java.util.Date())
        customerBeaconOffer1.setMerchantId(12345687L)
        customerBeaconOffer1.setMerchantNm("Robert")
        customerBeaconOffer1.setMerchantLogo("ABCD")
        customerBeaconOffer1.setStatus(0)
        customerBeaconOffer1.setConcent(true)
        List<CustomerBeaconOffer> list = new ArrayList<CustomerBeaconOffer>()
        list.add(customerBeaconOffer1)

        customerBeaconRepo.findByCustomerId(_) >> Optional.ofNullable(list)

        OffersServiceImpl service = new OffersServiceImpl()
        service.paymentViewRepo = paymentViewRepo
        service.customerBeaconRepo = customerBeaconRepo

        when:
        OfferDetailsResponseDto beaconDetailsResponseDto = service.setConcentDetails(merchantId, mobileNumber)

        then:
        beaconDetailsResponseDto.isNewData() == true
    }

    def "Test Success Scenario for updateConcentValue method"(){

        given:
        boolean value=true
        String merchantId = "12346"
        String mobileNumber="123456789"

        PaymentView paymentView = new PaymentView()
        paymentView.setAccountNo("1")
        paymentView.setAccountStatus('Y' as char)
        paymentView.setBalanceAmount(BigDecimal.TEN)
        //paymentView.setCardNo("1234567890123456")
        //paymentView.setCountryCd("NO")
        paymentView.setFirstName("first")
        paymentView.setLastName("lastName")
        paymentView.setMobileNo("98765432")
        paymentView.setStatusId("1")
        paymentView.setCustomerId(123456L)

        PaymentViewRepo paymentViewRepo = Mock(PaymentViewRepo.class)
        paymentViewRepo.findByMobileNo(_) >> Optional.ofNullable(paymentView)

        CustomerBeaconOffer customerBeaconOffer = new CustomerBeaconOffer()

        CustomerBeaconRepo customerBeaconRepo = Mock(CustomerBeaconRepo.class)
        customerBeaconRepo.findByCustomerIdAndMerchantId(_,_) >> Optional.ofNullable(customerBeaconOffer)
        customerBeaconRepo.save(_)
		
		CustomerConcentRepo customerConcentRepo = Mock(CustomerConcentRepo.class);
		CustomerConcent customerConcent = new CustomerConcent();
		customerConcent.setConcent(true);
		customerConcent.setConcentId(1L);
		customerConcent.setCustomerId(1L);
		customerConcent.setMerchantId(1L);
		
		List<CustomerConcent> customerConcents = new ArrayList();
		customerConcents.add(customerConcent);
		
		
		customerConcentRepo.findByCustomerIdAndMerchantId(_, _)>> Optional.ofNullable(customerConcent);
		customerConcentRepo.findAllByCustomerId(_) >>  Optional.ofNullable(customerConcents);
		
        OffersServiceImpl service = new OffersServiceImpl()
        service.paymentViewRepo = paymentViewRepo
        service.customerBeaconRepo = customerBeaconRepo
		service.customerConcentRepo = customerConcentRepo;

        when:
        service.updateConcentValue(value, mobileNumber, merchantId)

        then:
        true
    }
}
