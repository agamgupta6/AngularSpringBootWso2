package com.no.mob.payment.service

import com.no.mob.payment.entity.BeneficiaryDetails
import com.no.mob.payment.entity.PaymentView
import com.no.mob.payment.model.BeneficiaryDetailsDtoResult
import com.no.mob.payment.repo.PaymentDetailsRepo
import com.no.mob.payment.repo.PaymentViewRepo

import spock.lang.Specification

class PaymentGetBeneficiaryServiceSpec extends Specification{

	def "Test Success Scenario for paymentGetBeneficiaryDetailsPost method"(){
		
		given:
		PayeeDetailsServiceImpl payeeDetailsServiceImpl = new PayeeDetailsServiceImpl();
		
		String mobileNumber= "9633999563";
		char accountStatus = 'y';
		PaymentView customerActive = new PaymentView();
		customerActive.setAccountId(1L);
		customerActive.setAccountNo("85693241");
		customerActive.setBalanceAmount(BigDecimal.TEN);
		customerActive.setCardNo("7894563333");
		customerActive.setAccountStatus(accountStatus);
		customerActive.setCountryCd("No");
		customerActive.setCustomerId(1L);
		customerActive.setFirstName("Ain");
		customerActive.setLastName("Babu");
		customerActive.setMobileNo("9633999563");
		customerActive.setStatusId("1");
		
		def paymentViewRepo =  Mock(PaymentViewRepo.class);
		paymentViewRepo.findByMobileNo(_) >> Optional.ofNullable(customerActive);
		paymentViewRepo.findByAccountNo(_) >> Optional.ofNullable(customerActive);
		payeeDetailsServiceImpl.paymentViewRepo = paymentViewRepo;
		
		
		List<BeneficiaryDetails> beneficiaryDetailsList = new ArrayList();
		BeneficiaryDetails beneficiaryDetails = new BeneficiaryDetails();
		beneficiaryDetails.setAccountNumber("159357");
		beneficiaryDetails.setCountryCode("NO");
		beneficiaryDetails.setCustomerId(2L);
		beneficiaryDetails.setMobileNumber(mobileNumber);
		beneficiaryDetails.setPayeeId(2L);
		beneficiaryDetails.setPayeeName("Benny Kuriakose");
		beneficiaryDetails.setSwiftCode("1234");
		beneficiaryDetailsList.add(beneficiaryDetails);
		
		def paymentDetailsRepo = Mock(PaymentDetailsRepo.class);
		paymentDetailsRepo.findByCustomerId(_) >> Optional.ofNullable(beneficiaryDetailsList);
		payeeDetailsServiceImpl.paymentDetailsRepo = paymentDetailsRepo;
		
		when:
		BeneficiaryDetailsDtoResult beneficiaryDetailsDtoResult = payeeDetailsServiceImpl.fetchPayeeDetails(mobileNumber);
		then:
		beneficiaryDetailsDtoResult.getAccountNumber()=="8569.32.41";
		beneficiaryDetailsDtoResult.getBalanceAmount()=="10";
		beneficiaryDetailsDtoResult.getBeneficiaryDetails().get(0).getAccountNumber() == "159357";
		beneficiaryDetailsDtoResult.getBeneficiaryDetails().get(0).getMobileNumber() == mobileNumber;
		beneficiaryDetailsDtoResult.getBeneficiaryDetails().get(0).getPayeeName() == "Benny Kuriakose";
		beneficiaryDetailsDtoResult.getBeneficiaryDetails().get(0).getSwiftCode()=="1234";
	}
	
}
