package com.no.mob.payment.service

import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.client.RestTemplate
import com.no.mob.payment.common.GenericResponse
import com.no.mob.payment.entity.MerchantEntity
import com.no.mob.payment.entity.PaymentEntity
import com.no.mob.payment.entity.PaymentView
import com.no.mob.payment.model.InvoicePaymentDto
import com.no.mob.payment.model.InvoicePaymentRequestDto
import com.no.mob.payment.model.InvoiceRequest
import com.no.mob.payment.model.ResponseInfo
import com.no.mob.payment.repo.MerchantRepo
import com.no.mob.payment.repo.PaymentRepo
import com.no.mob.payment.repo.PaymentViewRepo

import spock.lang.Specification

class InvoicePaymentServiceSpec extends Specification {

	def "Invoice Payment Service"() {
		given:
		InvoicePaymentRequestDto invoicePaymentRequestDto = new InvoicePaymentRequestDto();
		invoicePaymentRequestDto.setAmount("123");
		invoicePaymentRequestDto.setDueDate("");
		invoicePaymentRequestDto.setKidNo("12345465");
		invoicePaymentRequestDto.setRecipientName("xyz");
		invoicePaymentRequestDto.setTargetAccountNo("1234566");

		String mobileNumber = "98765432";

		PaymentView sourcePaymentDetails = new PaymentView()
		sourcePaymentDetails.setAccountId(1L)
		sourcePaymentDetails.setAccountNo("1234567")
		sourcePaymentDetails.setAccountStatus('Y' as char)
		sourcePaymentDetails.setBalanceAmount(BigDecimal.TEN)
		sourcePaymentDetails.setCardNo("1234567890123456")
		sourcePaymentDetails.setCountryCd("NO")
		sourcePaymentDetails.setFirstName("first")
		sourcePaymentDetails.setLastName("lastName")
		sourcePaymentDetails.setMobileNo("98765432")
		sourcePaymentDetails.setStatusId("1")
		
		ResponseInfo responseInfo = new ResponseInfo();
		responseInfo.setResponseCode("200")
		InvoicePaymentDto invoicePaymentDto = new InvoicePaymentDto(responseInfo,new BigDecimal("123"),"q3232");
		
		PaymentEntity paymentEntity = new PaymentEntity()
		paymentEntity.setTransactionAmount(BigDecimal.valueOf(20L))
		paymentEntity.setTransactionId(1L)
		paymentEntity.setCreatedDt(new Date())
		
		PaymentViewRepo paymentViewRepo = Mock(PaymentViewRepo.class)
		PaymentRepo paymentRepo = Mock(PaymentRepo.class)
		paymentViewRepo.findByMobileNo(_) >> Optional.ofNullable(sourcePaymentDetails)
		paymentRepo.save(_) >> paymentEntity
		
		InvoiceRequest invoiceRequest =  new InvoiceRequest();
		ResponseEntity<InvoicePaymentDto> result = new ResponseEntity(invoicePaymentDto,HttpStatus.OK)
		result.status(HttpStatus.OK)
		
		 RestTemplate restTemplate = Mock {RestTemplate.class}
         restTemplate.exchange(_,_,_,InvoicePaymentDto.class) >> result
		 restTemplate.exchange(_,_,_,GenericResponse.class) >> result
		 
		 MerchantEntity merchantEntity = new MerchantEntity()
		 merchantEntity.setMerchantId(1L)
		 
		 MerchantRepo merchantRepo = Mock {MerchantRepo.class}
		 merchantRepo.findByAccountNo(_) >> merchantEntity
		 
		 
		 
		
	
		
		InvoicePaymentService invoicePaymentService = new InvoicePaymentServiceImpl();
		invoicePaymentService.restTemplate = restTemplate
		invoicePaymentService.paymentRepo=paymentRepo
		invoicePaymentService.paymentViewRepo=paymentViewRepo
		invoicePaymentService.merchantRepo = merchantRepo;
		
		when:
		invoicePaymentService.makeInvoicePayment(invoicePaymentRequestDto, mobileNumber)
		then:
		HttpStatus.OK
	}
}
