package com.no.mob.payment.service

import com.no.mob.payment.entity.CustomerBeaconOffer
import com.no.mob.payment.entity.MerchantEntity
import com.no.mob.payment.entity.OfferDetails
import com.no.mob.payment.entity.PaymentView
import com.no.mob.payment.model.MerchantAccountDetailsDtoResult
import com.no.mob.payment.model.MerchantDetailsRequestDto
import com.no.mob.payment.repo.CustomerBeaconRepo
import com.no.mob.payment.repo.MerchantRepo
import com.no.mob.payment.repo.PaymentViewRepo
import spock.lang.Specification

class MerchantServiceSpec extends Specification{

    def "Test Success Scenario1 for fetchMerchantDetailsByQrCode method"(){

        given:

        PaymentView paymentView = new PaymentView()
        paymentView.setAccountNo("1")
        paymentView.setAccountStatus('Y' as char)
        paymentView.setBalanceAmount(BigDecimal.TEN)
        //paymentView.setCardNo("1234567890123456")
        //paymentView.setCountryCd("NO")
        paymentView.setFirstName("first")
        paymentView.setLastName("lastName")
        paymentView.setMobileNo("98765432")
        paymentView.setStatusId("1")

        PaymentViewRepo paymentViewRepo = Mock(PaymentViewRepo.class)
        paymentViewRepo.findByMobileNo(_) >> Optional.ofNullable(paymentView)

        MerchantDetailsRequestDto merchantDetailsRequestDto = new MerchantDetailsRequestDto()
        merchantDetailsRequestDto.setBeaconCode("12345")
        merchantDetailsRequestDto.setQrCode("4567")

        MerchantEntity merchant = new MerchantEntity();
        merchant.setAccountNo(987654123L)
        merchant.setLogoUrl("http://sample.com/")
        merchant.setMerchantId(123456L)
        merchant.setMerchantName("Joseph")

        OfferDetails offer = new OfferDetails()
        offer.setRate(BigDecimal.ONE)

        merchant.setOfferDetails(offer)
        MerchantRepo merchantRepo = Mock(MerchantRepo.class)
        merchantRepo.findByQrCodeAndBeaconCode(_) >> merchant

        CustomerBeaconRepo customerBeaconRepo = Mock(CustomerBeaconRepo.class)

        MerchantService service = new MerchantServiceImpl()
        service.paymentViewRepo = paymentViewRepo
        service.merchantRepo = merchantRepo
        service.customerBeaconRepo = customerBeaconRepo

        when:
        MerchantAccountDetailsDtoResult result = service.fetchMerchantDetailsByQrCode(merchantDetailsRequestDto, "98745612")

        then:
        result.getAccountNo() == null
    }

    def "Test Success Scenario2 for fetchMerchantDetailsByQrCode method"(){

        given:

        PaymentView paymentView = new PaymentView()
        paymentView.setAccountNo("1")
        paymentView.setAccountStatus('Y' as char)
        paymentView.setBalanceAmount(BigDecimal.TEN)
        //paymentView.setCardNo("1234567890123456")
        //paymentView.setCountryCd("NO")
        paymentView.setFirstName("first")
        paymentView.setLastName("lastName")
        paymentView.setMobileNo("98765432")
        paymentView.setStatusId("1")

        PaymentViewRepo paymentViewRepo = Mock(PaymentViewRepo.class)
        paymentViewRepo.findByMobileNo(_) >> Optional.ofNullable(paymentView)

        MerchantDetailsRequestDto merchantDetailsRequestDto = new MerchantDetailsRequestDto()
        merchantDetailsRequestDto.setQrCode("4567")

        MerchantEntity merchant = new MerchantEntity();
        merchant.setAccountNo(987654123L)
        merchant.setLogoUrl("http://sample.com/")
        merchant.setMerchantId(123456L)
        merchant.setMerchantName("Joseph")

        OfferDetails offer = new OfferDetails()
        offer.setRate(BigDecimal.ONE)

        merchant.setOfferDetails(offer)
        MerchantRepo merchantRepo = Mock(MerchantRepo.class)
        merchantRepo.findByQrCode(_) >> merchant

        CustomerBeaconOffer beaconOffer = new CustomerBeaconOffer()
        beaconOffer.setStatus(0)

        CustomerBeaconRepo customerBeaconRepo = Mock(CustomerBeaconRepo.class)
        customerBeaconRepo.findByCustomerIdAndAccountNoAndConcent(_) >> beaconOffer

        MerchantService service = new MerchantServiceImpl()
        service.paymentViewRepo = paymentViewRepo
        service.merchantRepo = merchantRepo
        service.customerBeaconRepo = customerBeaconRepo

        when:
        MerchantAccountDetailsDtoResult result = service.fetchMerchantDetailsByQrCode(merchantDetailsRequestDto, "98745612")

        then:
        result.getAccountNo() != null
    }
}
