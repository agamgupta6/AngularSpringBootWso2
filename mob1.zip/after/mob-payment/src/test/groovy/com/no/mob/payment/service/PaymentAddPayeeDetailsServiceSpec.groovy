package com.no.mob.payment.service

import com.no.mob.payment.entity.BeneficiaryDetails
import com.no.mob.payment.entity.PaymentView
import com.no.mob.payment.model.BeneficiaryRequestDto
import com.no.mob.payment.repo.PaymentDetailsRepo
import com.no.mob.payment.repo.PaymentViewRepo

import spock.lang.Specification

class PaymentAddPayeeDetailsServiceSpec extends Specification{
	
	def "Test Success Scenario for addPayeeDetails method"(){
		
		PayeeDetailsServiceImpl payeeDetailsServiceImpl = new PayeeDetailsServiceImpl();
		
		String mobileNumber= "9633999563";
		char accountStatus = 'y';
		
		PaymentView customerActive = new PaymentView();
		customerActive.setAccountId(1L);
		customerActive.setAccountNo("85693241");
		customerActive.setBalanceAmount(BigDecimal.TEN);
		customerActive.setCardNo("7894563333");
		customerActive.setAccountStatus(accountStatus);
		customerActive.setCountryCd("No");
		customerActive.setCustomerId(1L);
		customerActive.setFirstName("Ain");
		customerActive.setLastName("Babu");
		customerActive.setMobileNo("9633999563");
		customerActive.setStatusId("1");
		
		def paymentViewRepo =  Mock(PaymentViewRepo.class);
		paymentViewRepo.findByMobileNo(_) >> Optional.ofNullable(customerActive);
		payeeDetailsServiceImpl.paymentViewRepo =paymentViewRepo;
		
		BeneficiaryRequestDto beneficiaryRequestDto = new BeneficiaryRequestDto();
		beneficiaryRequestDto.setAccountNumber("123456");
		beneficiaryRequestDto.setCountryCode("NO");
		beneficiaryRequestDto.setMobileNumber("9746444745");
		beneficiaryRequestDto.setPayeeName("Ain Babu");
		beneficiaryRequestDto.setSwiftCode("95123");
		
		BeneficiaryDetails beneficiaryDetails = new BeneficiaryDetails();
		beneficiaryDetails.setAccountNumber("123456");
		beneficiaryDetails.setCountryCode("NO");
		beneficiaryDetails.setCustomerId(2L);
		beneficiaryDetails.setMobileNumber("8089456123");
		beneficiaryDetails.setPayeeId(2L);
		beneficiaryDetails.setPayeeName("Benny Kuriakose");
		beneficiaryDetails.setSwiftCode("123");
		
		
		def paymentDetailsRepo = Mock(PaymentDetailsRepo.class);
		paymentDetailsRepo.save(_) >> beneficiaryDetails;
		payeeDetailsServiceImpl.paymentDetailsRepo = paymentDetailsRepo;
		
		when:
		payeeDetailsServiceImpl.addPayeeDetails(
			beneficiaryRequestDto, mobileNumber);
		
		then:
		beneficiaryDetails.getAccountNumber() == "123456";
		beneficiaryDetails.getCountryCode() == "NO";
		beneficiaryDetails.getCustomerId() == 2L;
		beneficiaryDetails.getMobileNumber() == "8089456123";
		beneficiaryDetails.getPayeeId() == 2L;
		beneficiaryDetails.getPayeeName() == "Benny Kuriakose";
		beneficiaryDetails.getSwiftCode() == "123";
	}
	

}
