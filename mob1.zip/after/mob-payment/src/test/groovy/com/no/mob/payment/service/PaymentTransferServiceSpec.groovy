package com.no.mob.payment.service

import com.no.mob.payment.common.GenericResponse
import com.no.mob.payment.entity.BeneficiaryDetails
import com.no.mob.payment.entity.MccCode
import com.no.mob.payment.model.PaymentSourceRequestDto
import com.no.mob.payment.model.PaymentTransferRequestDto
import com.no.mob.payment.model.TransactionHistoryResponseDtoResultTransactions
import com.no.mob.payment.model.TransferServiceResponseDto
import com.no.mob.payment.repo.MccCodeRepo
import com.no.mob.payment.repo.PaymentDetailsRepo
import com.no.mob.payment.repo.PaymentRepo
import com.no.mob.payment.util.CurrencyConverter
import com.no.mob.payment.util.TransactionsUtil
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.client.RestTemplate

import java.text.SimpleDateFormat

import com.no.mob.payment.entity.PaymentEntity
import com.no.mob.payment.entity.PaymentSource
import com.no.mob.payment.entity.PaymentView
import com.no.mob.payment.model.TransactionHistoryResponseDtoResult
import com.no.mob.payment.repo.PaymentSourceRepo
import com.no.mob.payment.repo.PaymentTransactionHistoryRepo
import com.no.mob.payment.repo.PaymentViewRepo

import spock.lang.Specification

class PaymentTransferServiceSpec extends Specification{


	def "Test Success Scenario for getTransactionHistorydetails method"(){
		given:
		GetTransactionsServiceImpl getTransactionsServiceImpl = new GetTransactionsServiceImpl();
		
		String mobileNumber= "9633999563";
		char accountStatus = 'y';
		PaymentView customerActive = new PaymentView();
		customerActive.setAccountId(1L);
		customerActive.setAccountNo("85693241");
		customerActive.setBalanceAmount(BigDecimal.TEN);
		customerActive.setCardNo("7894563333");
		customerActive.setAccountStatus(accountStatus);
		customerActive.setCountryCd("No");
		customerActive.setCustomerId(1L);
		customerActive.setFirstName("Ain");
		customerActive.setLastName("Babu");
		customerActive.setMobileNo("9633999563");
		customerActive.setStatusId("1");


		PaymentView customerActiveSender = new PaymentView();
		customerActiveSender.setAccountId(2L);
		customerActiveSender.setAccountNo("85693241");
		customerActiveSender.setBalanceAmount(BigDecimal.TEN);
		customerActiveSender.setCardNo("7894563333");
		customerActiveSender.setCountryCd("No");
		customerActiveSender.setAccountStatus(accountStatus);
		customerActiveSender.setCustomerId(2L);
		customerActiveSender.setFirstName("Benny");
		customerActiveSender.setLastName("Kuriakose");
		customerActiveSender.setMobileNo("9633999536");
		customerActiveSender.setStatusId("1");
		List<PaymentView> customerActiveSenderList = new ArrayList();
		customerActiveSenderList.add(customerActiveSender);

		def paymentViewRepo =  Mock(PaymentViewRepo.class);
		paymentViewRepo.findByMobileNo(_) >> Optional.ofNullable(customerActive);
		paymentViewRepo.findByCustomerId(_) >> Optional.ofNullable(customerActiveSenderList);
		getTransactionsServiceImpl.paymentViewRepo = paymentViewRepo;

		PaymentEntity paymentEntity = new PaymentEntity();
		paymentEntity.setBankAccountId(1L);
		paymentEntity.setCardId(8L);
		paymentEntity.setCountryCode("NO");
		paymentEntity.setCreatedDt(new Date());
		paymentEntity.setIban("86665");
		paymentEntity.setPaymentStatus(101);
		paymentEntity.setPaymentType("P2P");
		paymentEntity.setReceiverId(1L);
		paymentEntity.setSenderId(2L);
		paymentEntity.setSwift("SWIFT");
		paymentEntity.setTransactionAmount(BigDecimal.TEN);
		paymentEntity.setTransactionId(321654L);
		paymentEntity.setTransactionText("Hai");
		paymentEntity.setTransactionType(1);
		paymentEntity.setUpdatedDt(new SimpleDateFormat("dd/MM/yyyy").parse("17/01/2018"));
		List<PaymentEntity> paymentEntityList = new ArrayList<>();
		paymentEntityList.add(paymentEntity);
		Optional<List<PaymentEntity>> paymentEntityListOptional = Optional.of(paymentEntityList);
		

		def paymentTransactionHistoryRepo = Mock(PaymentTransactionHistoryRepo.class);
		paymentTransactionHistoryRepo.findBySenderIdOrReceiverId(_,_) >>  paymentEntityListOptional
		getTransactionsServiceImpl.paymentTransactionHistoryRepo = paymentTransactionHistoryRepo;
		
		PaymentSource paymentSource = new PaymentSource();
		paymentSource.setPaymentSourceId(123456789)
		paymentSource.setCustomerId(10000000L);
		paymentSource.setActiveIn('Y' as char);
		paymentSource.setCardNumber(1236547895623);
		List<PaymentSource> paymentSourceLists = new ArrayList<>();
		paymentSourceLists.add(paymentSource);
		Optional<List<PaymentEntity>> paymentSourceListOptional = Optional.of(paymentSourceLists);
		
		
		def paymentSourceRepo = Mock(PaymentSourceRepo.class);
		paymentSourceRepo.findByCustomerId(_) >> paymentSourceListOptional;
		getTransactionsServiceImpl.paymentSourceRepo = paymentSourceRepo;
		
		PaymentEntity paymentEntityLoad = new PaymentEntity();
		paymentEntityLoad.setBankAccountId(3L);
		paymentEntityLoad.setCardId(9L);
		paymentEntityLoad.setCountryCode("NO");
		paymentEntityLoad.setCreatedDt(new Date());
		paymentEntityLoad.setIban("86669");
		paymentEntityLoad.setPaymentStatus(101);
		paymentEntityLoad.setPaymentType("P2P");
		paymentEntityLoad.setReceiverId(3L);
		paymentEntityLoad.setSenderId(4L);
		paymentEntityLoad.setSwift("SWIFT");
		paymentEntityLoad.setTransactionAmount(BigDecimal.TEN);
		paymentEntityLoad.setTransactionId(321659L);
		paymentEntityLoad.setTransactionText("Hai");
		paymentEntityLoad.setTransactionType(1);
		paymentEntityLoad.setUpdatedDt(new SimpleDateFormat("dd/MM/yyyy").parse("17/01/2018"));
		
		List<PaymentEntity> paymentEntitys = new ArrayList<PaymentEntity>()
		paymentEntitys.add(paymentEntityLoad)
		
		paymentTransactionHistoryRepo.findBySenderId(_) >> Optional.ofNullable(paymentEntitys)
		
		when:
		TransactionHistoryResponseDtoResult transactionHistoryResponseDtoResult=getTransactionsServiceImpl.getTransactionHistorydetails(mobileNumber);
		then:
		
		transactionHistoryResponseDtoResult.getTransactions().get(1).getAmount() == "10";
		transactionHistoryResponseDtoResult.getTransactions().get(1).getCategory() == "shopping";
		transactionHistoryResponseDtoResult.getTransactions().get(1).getCountryCode() == "NO";
	}

	def "Test Success Scenario for getTransactiondetails method"(){

		String transactionId = "123456"
		String mobileNumber = "9876543210"

		char accountStatus = 'y';
		PaymentView customerActiveSender = new PaymentView();
		customerActiveSender.setAccountId(2L);
		customerActiveSender.setAccountNo("85693241");
		customerActiveSender.setBalanceAmount(BigDecimal.TEN);
		customerActiveSender.setCardNo("7894563333");
		customerActiveSender.setCountryCd("No");
		customerActiveSender.setAccountStatus(accountStatus);
		customerActiveSender.setCustomerId(4L);
		customerActiveSender.setFirstName("Benny");
		customerActiveSender.setLastName("Kuriakose");
		customerActiveSender.setMobileNo("9633999536");
		customerActiveSender.setStatusId("1")

		PaymentViewRepo paymentViewRepo = Mock(PaymentViewRepo.class)
		paymentViewRepo.findByMobileNo(_) >> Optional.ofNullable(customerActiveSender)

		PaymentEntity paymentEntityLoad = new PaymentEntity();
		paymentEntityLoad.setBankAccountId(3L);
		paymentEntityLoad.setCardId(9L);
		paymentEntityLoad.setCountryCode("NO");
		paymentEntityLoad.setCreatedDt(new Date());
		paymentEntityLoad.setIban("86669");
		paymentEntityLoad.setPaymentStatus(101);
		paymentEntityLoad.setPaymentType("P2P");
		paymentEntityLoad.setReceiverId(3L);
		paymentEntityLoad.setSenderId(4L);
		paymentEntityLoad.setSwift("SWIFT");
		paymentEntityLoad.setTransactionAmount(BigDecimal.TEN);
		paymentEntityLoad.setTransactionId(321659L);
		paymentEntityLoad.setTransactionText("Hai");
		paymentEntityLoad.setTransactionType(1);
		paymentEntityLoad.setUpdatedDt(new SimpleDateFormat("dd/MM/yyyy").parse("17/01/2018"));

		PaymentTransactionHistoryRepo paymentTransactionHistoryRepo = Mock(PaymentTransactionHistoryRepo.class)
		paymentTransactionHistoryRepo.findByTransactionId(_) >> Optional.ofNullable(paymentEntityLoad)

		String name = "Joseph"
		String accNo = "123456"
		String paySrc = "Felix"
		TransactionsUtil transactionsUtil = Mock(TransactionsUtil.class)
		transactionsUtil.populateReceiverName(_) >> name
		transactionsUtil.populateAccountNumber(_) >> accNo
		transactionsUtil.populatePaymentSource(_) >> paySrc

		GetTransactionsServiceImpl service = new GetTransactionsServiceImpl()
		service.transactionsUtil = transactionsUtil
		service.paymentViewRepo = paymentViewRepo
		service.paymentTransactionHistoryRepo = paymentTransactionHistoryRepo

		when:
		TransactionHistoryResponseDtoResultTransactions result = service.getTransactionDetails(transactionId, mobileNumber)

		then:
		result.getTransactionId().equals("321659") == true
	}

	def "Test Success Scenario for savePaymentSource method"(){

		given:

		PaymentSourceRequestDto paymentSourceRequestDto = new PaymentSourceRequestDto()
		paymentSourceRequestDto.setCardNumber(9876543212456987L)
		paymentSourceRequestDto.setCustomerId(562314L)

		PaymentSourceRepo paymentSourceRepo = Mock(PaymentSourceRepo.class)
		paymentSourceRepo.save(_) >> null

		PaymentTransferServiceImpl service = new PaymentTransferServiceImpl()
		service.paymentSourceRepo = paymentSourceRepo

		when:
		service.savePaymentSource(paymentSourceRequestDto)

		then:
		true
	}

	def "Test Success Scenario for makePayment method"(){

		given:

		String mobileNo = "9876543210"
		PaymentTransferRequestDto paymentTransferRequestDto = new PaymentTransferRequestDto()
		paymentTransferRequestDto.setAmount(BigDecimal.ONE)
		paymentTransferRequestDto.setCountryCode("56")
		paymentTransferRequestDto.setTargetAccountNo(98654712L)
		paymentTransferRequestDto.setSwiftCode("DNBHGKJ")
		paymentTransferRequestDto.setTransactionTxt("Payed")

		PaymentView paymentView = new PaymentView()
		paymentView.setAccountNo("1")
		paymentView.setAccountStatus('Y' as char)
		paymentView.setBalanceAmount(BigDecimal.TEN)
		//paymentView.setCardNo("1234567890123456")
		//paymentView.setCountryCd("NO")
		paymentView.setFirstName("first")
		paymentView.setLastName("lastName")
		paymentView.setMobileNo("98765432")
		paymentView.setStatusId("1")
		paymentView.setCustomerId(123456L)
		paymentView.setCountryCd("54")

		PaymentViewRepo paymentViewRepo = Mock(PaymentViewRepo.class)
		paymentViewRepo.findByMobileNo(_) >> Optional.ofNullable(paymentView)
		paymentViewRepo.findByAccountNo(_) >> Optional.ofNullable(paymentView)

		BigDecimal amt = BigDecimal.ONE
		CurrencyConverter currencyConverter = Mock(CurrencyConverter.class)
		currencyConverter.convertRequestedAmount(_) >> amt

		GenericResponse response = new GenericResponse();
		response.setResult(BigDecimal.ONE)
		ResponseEntity resp = new ResponseEntity<>(response,HttpStatus.OK)
		RestTemplate restTemplate = Mock(RestTemplate.class)
		restTemplate.exchange(_,_,_,GenericResponse.class) >> resp

		MccCode mccCd = new MccCode();
		mccCd.setMccCd(456789L)

		MccCodeRepo mccCodeRepo = Mock(MccCodeRepo.class)
		mccCodeRepo.findByCategoryType(_) >> mccCd

		PaymentEntity paymentEntity = new PaymentEntity()
		paymentEntity.setMccCode("456789")
		paymentEntity.setTransactionId(123456L)
		paymentEntity.setPaymentStatus(101)
		paymentEntity.setTransactionType(2)
		paymentEntity.setTransactionAmount(BigDecimal.ONE)
		paymentEntity.setCreatedDt(new Date())
		paymentEntity.setReceiverId(564789L)

		PaymentRepo paymentRepo = Mock(PaymentRepo.class)
		paymentRepo.save(_) >> paymentEntity

		BeneficiaryDetails beneficiaryDetails = new BeneficiaryDetails()
		beneficiaryDetails.setPayeeId(456789L)

		PaymentDetailsRepo paymentDetailsRepo = Mock(PaymentDetailsRepo.class)
		paymentDetailsRepo.findByAccountNumber(_) >> beneficiaryDetails

		TransactionsUtil transactionsUtil = Mock(TransactionsUtil.class)
		transactionsUtil.populateNameOrAccountNo(_) >> "Joseph"

		PaymentTransferServiceImpl service = new PaymentTransferServiceImpl()
		service.paymentViewRepo = paymentViewRepo
		service.currencyConverter = currencyConverter
		service.restTemplate = restTemplate
		service.mccCodeRepo = mccCodeRepo
		service.paymentRepo = paymentRepo
		service.paymentDetailsRepo = paymentDetailsRepo
		service.transactionsUtil = transactionsUtil

		when:
		TransferServiceResponseDto resDto = service.makePayment(mobileNo, paymentTransferRequestDto)

		then:
		resDto != null
	}
}
