package com.no.mob.payment.service

import java.text.SimpleDateFormat

import com.no.mob.payment.entity.PaymentSource
import com.no.mob.payment.entity.PaymentView
import com.no.mob.payment.exceptions.BusinessException
import com.no.mob.payment.model.GetCardDetailsResponseDto
import com.no.mob.payment.repo.CardDetailsRepo
import com.no.mob.payment.repo.PaymentViewRepo
import com.no.mob.payment.service.GetCardDetails
import com.no.mob.payment.service.GetCardDetailsImpl

import spock.lang.Specification

class GetCardDetailsImplSpec extends Specification {

	
	def "card details service"() {
		given:
		
		PaymentView paymentView = new PaymentView()
		paymentView.setAccountNo("1")
		paymentView.setAccountStatus('Y' as char)
		paymentView.setBalanceAmount(BigDecimal.TEN)
		//paymentView.setCardNo("1234567890123456")
		//paymentView.setCountryCd("NO")
		paymentView.setFirstName("first")
		paymentView.setLastName("lastName")
		paymentView.setMobileNo("98765432")
		paymentView.setStatusId("1")
		
		PaymentSource paymentSource = new PaymentSource();
		//paymentSource.setActiveIn('Y as char')
		paymentSource.setCardExpiry(new SimpleDateFormat("dd/MM/yyyy").parse("11/01/2022"))
		paymentSource.setCardNumber(1234567890123456L)
		//paymentSource.setCreatedDt(new Timestamp(new Date().getTime()))
		paymentSource.setCustomerId(1L)
		paymentSource.setPaymentSourceId(1)
		//paymentSource.setUpdatedDt(new Timestamp(new Date().getTime()))
		
		List<PaymentSource> cardDetailsList = new ArrayList<>()
		cardDetailsList.add(paymentSource)
		
		
		String mobileNumber = "98765432"
		PaymentViewRepo paymentViewRepo = Mock(PaymentViewRepo.class)
		CardDetailsRepo cardDetailsRepo = Mock(CardDetailsRepo.class)
		paymentViewRepo.findByMobileNo(_) >> Optional.ofNullable(paymentView)
		cardDetailsRepo.findByCustomerId(_) >> cardDetailsList
		
		GetCardDetails getCardDetails = new GetCardDetailsImpl()
		getCardDetails.paymentViewRepo = paymentViewRepo
		getCardDetails.cardDetailsRepo = cardDetailsRepo
		
		when:
		List<GetCardDetailsResponseDto> getCardDetailsResponseDto= getCardDetails.getCardDetails("98765432")

		then:

		getCardDetailsResponseDto.get(0).getCardNumber()=="1234567890123456"

	}
	
	
	def "card details service customer not found"() {
		given:
		
		PaymentView paymentView = new PaymentView()
		paymentView.setAccountNo("1")
		paymentView.setAccountStatus('Y' as char)
		paymentView.setBalanceAmount(BigDecimal.TEN)
		//paymentView.setCardNo("1234567890123456")
		//paymentView.setCountryCd("NO")
		paymentView.setFirstName("first")
		paymentView.setLastName("lastName")
		paymentView.setMobileNo("98765432")
		paymentView.setStatusId("1")
		
		PaymentSource paymentSource = new PaymentSource();
		//paymentSource.setActiveIn('Y as char')
		paymentSource.setCardExpiry(new SimpleDateFormat("dd/MM/yyyy").parse("11/01/2022"))
		paymentSource.setCardNumber(1234567890123456L)
		//paymentSource.setCreatedDt(new Timestamp(new Date().getTime()))
		paymentSource.setCustomerId(1L)
		paymentSource.setPaymentSourceId(1)
		//paymentSource.setUpdatedDt(new Timestamp(new Date().getTime()))
		
		List<PaymentSource> cardDetailsList = new ArrayList<>()
		cardDetailsList.add(paymentSource)
		
		
		String mobileNumber = "98765432"
		PaymentViewRepo paymentViewRepo = Mock(PaymentViewRepo.class)
		CardDetailsRepo cardDetailsRepo = Mock(CardDetailsRepo.class)
		paymentViewRepo.findByMobileNo(_) >> Optional.empty()
		cardDetailsRepo.findByCustomerId(_) >> cardDetailsList
		
		GetCardDetails getCardDetails = new GetCardDetailsImpl()
		getCardDetails.paymentViewRepo = paymentViewRepo
		getCardDetails.cardDetailsRepo = cardDetailsRepo
		
		when:
		List<GetCardDetailsResponseDto> getCardDetailsResponseDto= getCardDetails.getCardDetails("98765432")

		then:

			BusinessException e = thrown()
		e.getErrorDetails().getErrorCode()=="412"
		e.getErrorDetails().getErrorMsgKey()=="Customer not found.!"

	}
	
	
	
}
