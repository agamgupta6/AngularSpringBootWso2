package com.no.mob.payment.controller

import com.no.mob.payment.model.BeaconDetailsResponseDto
import com.no.mob.payment.model.MerchantAccountDetailsDtoResult
import com.no.mob.payment.model.MerchantDetailsRequestDto
import com.no.mob.payment.model.OfferDetailsResponseDto
import com.no.mob.payment.model.PaymentSourceRequestDto
import com.no.mob.payment.model.PfmDetails
import com.no.mob.payment.model.PfmDetailsResponseDto
import com.no.mob.payment.service.MerchantService
import com.no.mob.payment.service.OffersService
import com.no.mob.payment.service.PfmService
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity

import com.no.mob.payment.common.GenericResponse
import com.no.mob.payment.model.BeneficiaryDetailDto
import com.no.mob.payment.model.BeneficiaryDetailsDtoResult
import com.no.mob.payment.model.BeneficiaryRequestDto
import com.no.mob.payment.model.CardDetailsRequestDto
import com.no.mob.payment.model.GetCardDetailsResponseDto
import com.no.mob.payment.model.LoadMoneyRequestDto
import com.no.mob.payment.model.PaymentRequest
import com.no.mob.payment.model.PaymentTransferRequestDto
import com.no.mob.payment.model.ResponseInfo
import com.no.mob.payment.model.TransactionHistoryResponseDtoResult
import com.no.mob.payment.model.TransactionHistoryResponseDtoResultTransactions
import com.no.mob.payment.service.GetCardDetails
import com.no.mob.payment.service.GetTransactions
import com.no.mob.payment.service.LoadMoneyTransactionService
import com.no.mob.payment.service.PayeeDetailsService
import com.no.mob.payment.service.PaymentTransferService

import spock.lang.Specification

class PaymentApiControllerSpec extends Specification{
	
	def "Test Success Scenario for paymentsGetTransactionsGet method"(){
		given:
		PaymentsApiController paymentApiController= new PaymentsApiController(); 
		
		String mobileNumber= "9633999563";
		String accessToken= "abcdefgh";
		
		TransactionHistoryResponseDtoResult transactionHistoryResponseDtoResult = new TransactionHistoryResponseDtoResult();
		TransactionHistoryResponseDtoResultTransactions transactionDetails = new TransactionHistoryResponseDtoResultTransactions();
		transactionDetails.setAmount("300");
		transactionDetails.setCategory("peer");
		transactionDetails.setCountryCode("NO");
		transactionDetails.setDate(new Date().getTime());
		transactionDetails.setName("Benny Kuriakose");
		transactionDetails.setStatus("Success");
		transactionDetails.setTransferType("Cr");
		transactionDetails.setType("MOB");
		transactionHistoryResponseDtoResult.addTransactionsItem(transactionDetails);
		
		def getTransactions = Mock(GetTransactions.class);
		getTransactions.getTransactionHistorydetails(_) >> transactionHistoryResponseDtoResult;
		paymentApiController.getTransactions = getTransactions;
		when:
		ResponseEntity<GenericResponse> response = paymentApiController.paymentsGetTransactionsGet(mobileNumber,accessToken);
		then:
		response.body.getResponseInfo().getResponseCode()=="200";
		response.body.getResponseInfo().getResponseMessage()=="ok";
		
	}
	
	def "Test Success Scenario for transferMoney method"(){
		given:
		
		PaymentsApiController paymentApiController= new PaymentsApiController();
		
		String mobileNumber= "9633999563";
		String accessToken= "abcdefgh";
		
		PaymentTransferRequestDto paymentTransferRequestDto = new PaymentTransferRequestDto();
		paymentTransferRequestDto.setAmount(BigDecimal.TEN);
		paymentTransferRequestDto.setCountryCode("NO");
		paymentTransferRequestDto.setName("Benny");
		paymentTransferRequestDto.setSwiftCode("159753258");
		paymentTransferRequestDto.setTargetAccountNo(1597895123);
		paymentTransferRequestDto.setTransactionTxt("Test Transaction");
		
		def paymentTransferService = Mock(PaymentTransferService.class);
		paymentApiController.paymentTransferService = paymentTransferService;
		when:
		ResponseEntity<GenericResponse> response = paymentApiController.transferMoney(mobileNumber, accessToken, paymentTransferRequestDto);
		then:
		response.body.getResponseInfo().getResponseCode()=="200";
		response.body.getResponseInfo().getResponseMessage()=="ok";
		
	}
	
	def "Test Success Scenario for transferMoneybetweenToOtherAccounts method"(){
		given:
		
		PaymentsApiController paymentApiController= new PaymentsApiController();
		
		PaymentRequest paymentRequest = new PaymentRequest();
		paymentRequest.setAmount(BigDecimal.TEN);
		paymentRequest.setCreated(new Date());
		paymentRequest.setCurrency("100");
		paymentRequest.setIban("8523697110");
		paymentRequest.setId(456789);
		paymentRequest.setReference("789456");
		paymentRequest.setSourceAccount(789456123);
		paymentRequest.setSwift("854697");
		paymentRequest.setTargetAccount(65874123);
		paymentRequest.setTransferRequest("1265987");
		
		
		when:
		ResponseEntity<GenericResponse> response =  paymentApiController.transferMoneybetweenToOtherAccounts(paymentRequest);
		then:
		response.body.getResponseInfo().getResponseCode()=="200";
		response.body.getResponseInfo().getResponseMessage()=="ok";
	}
	
	
	def "Test Success Scenario for paymentGetBeneficiaryDetailsPost method"(){
		given:
		
		PaymentsApiController paymentApiController= new PaymentsApiController();
		
		String mobileNumber= "9633999563";
		String accessToken= "abcdefgh";
		
		BeneficiaryDetailsDtoResult beneficiaryDetailsDtoResult = new BeneficiaryDetailsDtoResult();
		beneficiaryDetailsDtoResult.setAccountNumber("789456123");
		beneficiaryDetailsDtoResult.setBalanceAmount("1000");
		BeneficiaryDetailDto beneficiaryDetailDto = new BeneficiaryDetailDto();
		beneficiaryDetailDto.setAccountNumber("897456321");
		beneficiaryDetailDto.setMobileNumber(mobileNumber);
		beneficiaryDetailDto.setPayeeName("Ain");
		beneficiaryDetailDto.setSwiftCode("785632149");
		List<BeneficiaryDetailDto> beneficiaryDetailDtodetails = new ArrayList<>();
		beneficiaryDetailDtodetails.add(beneficiaryDetailDto);
		beneficiaryDetailsDtoResult.setBeneficiaryDetails(beneficiaryDetailDtodetails);
		
		
		def payeeDetailsService = Mock(PayeeDetailsService.class);
		payeeDetailsService.fetchPayeeDetails(_) >> beneficiaryDetailsDtoResult;
		paymentApiController.payeeDetailsService = payeeDetailsService;
		when:
		ResponseEntity<GenericResponse> response = paymentApiController.paymentGetBeneficiaryDetailsPost(mobileNumber,accessToken);
		then:
		response.body.getResponseInfo().getResponseCode()=="200";
		response.body.getResponseInfo().getResponseMessage()=="ok";
		
	}
	
	
	def "Test Success Scenario for paymentAddPayeeDeatilsPost method"(){
		given:
		
		PaymentsApiController paymentApiController= new PaymentsApiController();
		
		String mobileNumber= "9633999563";
		String accessToken= "abcdefgh";
		
		
		BeneficiaryRequestDto beneficiaryRequestDto = new BeneficiaryRequestDto();
		beneficiaryRequestDto.setAccountNumber("123456");
		beneficiaryRequestDto.setCountryCode("NO");
		beneficiaryRequestDto.setMobileNumber("9746444745");
		beneficiaryRequestDto.setPayeeName("Ain Babu");
		beneficiaryRequestDto.setSwiftCode("95123");
		
		def payeeDetailsService = Mock(PayeeDetailsService.class);
		paymentApiController.payeeDetailsService = payeeDetailsService;
		when:
		ResponseEntity<GenericResponse> response = paymentApiController.paymentAddPayeeDeatilsPost(beneficiaryRequestDto,mobileNumber,accessToken);
		then:
		response.body.getResponseInfo().getResponseCode()=="200";
		response.body.getResponseInfo().getResponseMessage()=="ok";
		
	}
	
	def "Test Success Scenario for loadMoneyToAccount method"() {
		
		given:
		PaymentsApi api = new PaymentsApiController();
		
		String mobileNumber = "971745623";
		String accessToken = "abcd";
		
		LoadMoneyRequestDto dto = new LoadMoneyRequestDto();
		CardDetailsRequestDto cardRequestDto = new CardDetailsRequestDto();
		dto.setAmount(100);
		dto.setCurrency("NOK");
		cardRequestDto.setCardExpiry("01/21");
		cardRequestDto.setCardNumber(12345678910);
		cardRequestDto.setCardType("NEW");
		cardRequestDto.setCvv2(123);
		dto.setCardDetails(cardRequestDto);

		GenericResponse response = new GenericResponse();
		ResponseInfo  responseInfo=new ResponseInfo();
		responseInfo.setResponseCode("200");
		responseInfo.setResponseMessage("Amount Credited");
		response.setResponseInfo(responseInfo);
		
		def	loadMoneyTransactionService = Mock(LoadMoneyTransactionService.class)
		loadMoneyTransactionService.loadMoneyInAccount(_) >> response
		api.loadMoneyTransactionService = loadMoneyTransactionService
		when:
		ResponseEntity<GenericResponse> responseDto = api.loadMoneyToAccount(dto,mobileNumber,accessToken)
		then:
		responseDto.status == HttpStatus.OK
		responseDto.body.getResponseInfo().getResponseCode() == "200"
	}
	
	def "Test Success Scenario for paymentGetCardDetailsGet method"() {
		
		given:
		PaymentsApi api = new PaymentsApiController();
		
		String mobileNumber = "9747561231"
		String token = "abcd"

		List<GetCardDetailsResponseDto> cardDetailsList=new ArrayList<GetCardDetailsResponseDto>();
		GetCardDetailsResponseDto getCardDetailsResponseDto = new GetCardDetailsResponseDto();
		getCardDetailsResponseDto.setCardExpiry("123");
		getCardDetailsResponseDto.setCardNumber("12345678941");
		cardDetailsList.add(getCardDetailsResponseDto);
		
		def	getCardDetails = Mock(GetCardDetails.class)
		getCardDetails.getCardDetails(_) >> cardDetailsList
		api.getCardDetails = getCardDetails
		when:
		ResponseEntity<GenericResponse> response = api.paymentGetCardDetailsGet(mobileNumber,token)
		then:
		response.getBody().getResponseInfo().getResponseCode() == "200";
		cardDetailsList.get(0).getCardNumber() == "12345678941";
	}

	def "Test Success Scenario for getMerchantDetails method"(){
		given:
		PaymentsApiController paymentApiController= new PaymentsApiController();

		String mobileNumber= "9633999563";
		String accessToken= "abcdefgh";
		MerchantDetailsRequestDto merchantDetailsRequestDto = new MerchantDetailsRequestDto()
		merchantDetailsRequestDto.setBeaconCode("12345")
		merchantDetailsRequestDto.setQrCode("4567")

		MerchantAccountDetailsDtoResult merchantAccountDetailsDtoResult = new MerchantAccountDetailsDtoResult();
		merchantAccountDetailsDtoResult.setAccountNo("300");
		merchantAccountDetailsDtoResult.setDiscountRate(BigDecimal.ONE);
		merchantAccountDetailsDtoResult.setMerchantId("123456");
		merchantAccountDetailsDtoResult.setMerchantLogo("ABC");
		merchantAccountDetailsDtoResult.setMerchantNm("Benny Kuriakose");

		MerchantService merchantService = Mock(MerchantService.class);
		merchantService.fetchMerchantDetailsByQrCode(_) >> merchantAccountDetailsDtoResult;
		paymentApiController.merchantService = merchantService;
		when:
		ResponseEntity<GenericResponse> response = paymentApiController.getMerchantDetails(merchantDetailsRequestDto, mobileNumber,accessToken);
		then:
		response.body.getResponseInfo().getResponseCode()=="200";
		response.body.getResponseInfo().getResponseMessage()=="ok";

	}

	def "Test Success Scenario for getTransactiondetails method"(){
		given:
		PaymentsApiController paymentApiController= new PaymentsApiController();

		String mobileNumber= "9633999563";
		String accessToken= "abcdefgh";
		String transactionId = "123456"

		TransactionHistoryResponseDtoResultTransactions transactionDetails = new TransactionHistoryResponseDtoResultTransactions();
		transactionDetails.setAmount("300");
		transactionDetails.setCategory("peer");
		transactionDetails.setCountryCode("NO");
		transactionDetails.setDate(new Date().getTime());
		transactionDetails.setName("Benny Kuriakose");
		transactionDetails.setStatus("Success");
		transactionDetails.setTransferType("Cr");
		transactionDetails.setType("MOB");

		def getTransactions = Mock(GetTransactions.class);
		getTransactions.getTransactionHistorydetails(_) >> transactionDetails;
		paymentApiController.getTransactions = getTransactions;
		when:
		ResponseEntity<GenericResponse> response = paymentApiController.getTransactionDetails(transactionId, mobileNumber,accessToken);
		then:
		response.body.getResponseInfo().getResponseCode()=="200";
		response.body.getResponseInfo().getResponseMessage()=="ok";

	}

	def "Test Success Scenario for getAccountDetails method"(){
		given:
		PaymentsApiController paymentApiController= new PaymentsApiController();

		String mobileNumber= "9633999563";
		String accessToken= "abcdefgh";
		String beaconCode = "123456"

		OfferDetailsResponseDto dto = new OfferDetailsResponseDto();
		dto.setNewData(true);
		BeaconDetailsResponseDto beaconDetailsResponseDto = new BeaconDetailsResponseDto()
		beaconDetailsResponseDto.setCustomerId("300");
		beaconDetailsResponseDto.setMerchantId("peer");
		beaconDetailsResponseDto.setMerchantNm("NO");
		beaconDetailsResponseDto.setMerchantLogo("ABC");
		beaconDetailsResponseDto.setStatus(true);
		beaconDetailsResponseDto.setAccountNo("123456789");
		beaconDetailsResponseDto.setDiscountRate(BigDecimal.ONE);
		beaconDetailsResponseDto.setConcent(true);

		OffersService offersService = Mock(OffersService.class);
		offersService.fetchOfferDetails(_) >> beaconDetailsResponseDto;
		paymentApiController.offersService = offersService;
		when:
		ResponseEntity<GenericResponse> response = paymentApiController.getDetailsByBeaconCode(beaconCode, mobileNumber,accessToken);
		then:
		response.body.getResponseInfo().getResponseCode()=="200";
		response.body.getResponseInfo().getResponseMessage()=="ok";

	}

	def "Test Success Scenario for getpfmTransactions method"(){
		given:
		PaymentsApiController paymentApiController= new PaymentsApiController();

		String mobileNumber= "9633999563";
		String accessToken= "abcdefgh";
		String targetDate = "01/01/2015"

		PfmDetailsResponseDto dto = new PfmDetailsResponseDto();
		PfmDetails pfmDetails = new PfmDetails()
		pfmDetails.setFirstNm("Robert");
		pfmDetails.setAmount("20123");
		pfmDetails.setTransferType("Done");
		List<PfmDetails> list = new ArrayList<PfmDetails>()
		list.add(pfmDetails)

		PfmService pfmService = Mock(PfmService.class);
		pfmService.fetchPfmTransactionDetails(_) >> dto;

		paymentApiController.pfmService = pfmService;
		when:
		ResponseEntity<GenericResponse> response = paymentApiController.getPfmTransactionDetails(mobileNumber, accessToken, targetDate);
		then:
		response.body.getResponseInfo().getResponseCode()=="200";
		response.body.getResponseInfo().getResponseMessage()=="ok";

	}

	def "Test Success Scenario for getpfmDetails method"(){
		given:
		PaymentsApiController paymentApiController= new PaymentsApiController();

		String mobileNumber= "9633999563";
		String accessToken= "abcdefgh";
		String targetDate = "01/01/2015"

		PfmDetailsResponseDto dto = new PfmDetailsResponseDto();
		PfmDetails pfmDetails = new PfmDetails()
		pfmDetails.setFirstNm("Robert");
		pfmDetails.setAmount("20123");
		pfmDetails.setTransferType("Done");
		List<PfmDetails> list = new ArrayList<PfmDetails>()
		list.add(pfmDetails)

		PfmService pfmService = Mock(PfmService.class);
		pfmService.fetchPfmDetails(_) >> dto;

		paymentApiController.pfmService = pfmService;
		when:
		ResponseEntity<GenericResponse> response = paymentApiController.getPfmDetails(mobileNumber, accessToken, targetDate);
		then:
		response.body.getResponseInfo().getResponseCode()=="200";
		response.body.getResponseInfo().getResponseMessage()=="ok";

	}

	def "Test Success Scenario for createPaymentSource method"(){
		given:
		PaymentsApiController paymentApiController= new PaymentsApiController();

		String mobileNumber= "9633999563";
		String accessToken= "abcdefgh";
		PaymentSourceRequestDto paymentSourceRequestDto = new PaymentSourceRequestDto()

		PaymentTransferService paymentTransferService = Mock(PaymentTransferService.class);
		paymentTransferService.savePaymentSource(_) >> null

		paymentApiController.paymentTransferService = paymentTransferService;
		when:
		ResponseEntity<GenericResponse> response = paymentApiController.createPaymentSource(mobileNumber, accessToken, paymentSourceRequestDto);
		then:
		response.body.getResponseInfo().getResponseCode()=="200";
		response.body.getResponseInfo().getResponseMessage()=="ok";

	}

	def "Test Success Scenario for setConcentDetails method"(){
		given:
		PaymentsApiController paymentApiController= new PaymentsApiController();

		String mobileNumber= "9633999563";
		String accessToken= "abcdefgh";
		String merchantId = "123456"

		OfferDetailsResponseDto beaconDetailsResponseDto = new OfferDetailsResponseDto()
		BeaconDetailsResponseDto dto = new BeaconDetailsResponseDto()
		List<BeaconDetailsResponseDto> list = new ArrayList<BeaconDetailsResponseDto>()
		list.add(dto)
		beaconDetailsResponseDto.setOfferDetails(list)

		OffersService offersService = Mock(OffersService.class);
		offersService.setConcentDetails(_) >> beaconDetailsResponseDto;
		paymentApiController.offersService = offersService;

		when:
		ResponseEntity<GenericResponse> response = paymentApiController.setConcentDetails(merchantId, mobileNumber, accessToken);
		then:
		response.body.getResponseInfo().getResponseCode()=="200";
		response.body.getResponseInfo().getResponseMessage()=="ok";

	}

	def "Test Success Scenario for updateConcentDetails method"(){
		given:
		PaymentsApiController paymentApiController= new PaymentsApiController();

		String mobileNumber= "9633999563";
		String accessToken= "abcdefgh";
		String value = "123456"
		String merchantId = "123456"

		OffersService offersService = Mock(OffersService.class);
		offersService.updateConcentValue(_) >> null
		paymentApiController.offersService = offersService;

		when:
		paymentApiController.updateConcentDetails(value, mobileNumber, accessToken, merchantId);
		then:
		true

	}

}
