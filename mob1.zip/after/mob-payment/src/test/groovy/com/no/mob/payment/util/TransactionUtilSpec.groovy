package com.no.mob.payment.util

import com.no.mob.payment.entity.PaymentEntity
import com.no.mob.payment.entity.PaymentView
import com.no.mob.payment.repo.PaymentViewRepo
import spock.lang.Specification

import java.text.SimpleDateFormat

class TransactionUtilSpec extends Specification{

    def "Test Success Scenario for populateReceiverName method"(){

        char accountStatus = 'y'
        PaymentView customerActiveSender = new PaymentView();
        customerActiveSender.setAccountId(2L);
        customerActiveSender.setAccountNo("85693241");
        customerActiveSender.setBalanceAmount(BigDecimal.TEN);
        customerActiveSender.setCardNo("7894563333");
        customerActiveSender.setCountryCd("No");
        customerActiveSender.setAccountStatus(accountStatus);
        customerActiveSender.setCustomerId(4L);
        customerActiveSender.setFirstName("Benny");
        customerActiveSender.setLastName("Kuriakose");
        customerActiveSender.setMobileNo("9633999536");
        customerActiveSender.setStatusId("1")

        PaymentEntity paymentEntityLoad = new PaymentEntity();
        paymentEntityLoad.setBankAccountId(3L);
        paymentEntityLoad.setCardId(9L);
        paymentEntityLoad.setCountryCode("NO");
        paymentEntityLoad.setCreatedDt(new Date());
        paymentEntityLoad.setIban("86669");
        paymentEntityLoad.setPaymentStatus(101);
        paymentEntityLoad.setPaymentType("INVOICE");
        paymentEntityLoad.setReceiverId(3L);
        paymentEntityLoad.setSenderId(4L);
        paymentEntityLoad.setSwift("SWIFT");
        paymentEntityLoad.setTransactionAmount(BigDecimal.TEN);
        paymentEntityLoad.setTransactionId(321659L);
        paymentEntityLoad.setTransactionText("Hai");
        paymentEntityLoad.setTransactionType(1);
        paymentEntityLoad.setUpdatedDt(new SimpleDateFormat("dd/MM/yyyy").parse("17/01/2018"));

        TransactionsUtil util = new TransactionsUtil()

        when:
        String name = util.populateReceiverName(customerActiveSender, paymentEntityLoad)

        then:
        name.equals("3")
    }

    def "Test Success Scenario for populateReceiverName1 method"(){

        char accountStatus = 'y'
        PaymentView customerActiveSender = new PaymentView();
        customerActiveSender.setAccountId(2L);
        customerActiveSender.setAccountNo("85693241");
        customerActiveSender.setBalanceAmount(BigDecimal.TEN);
        customerActiveSender.setCardNo("7894563333");
        customerActiveSender.setCountryCd("No");
        customerActiveSender.setAccountStatus(accountStatus);
        customerActiveSender.setCustomerId(2L);
        customerActiveSender.setFirstName("Benny");
        customerActiveSender.setLastName("Kuriakose");
        customerActiveSender.setMobileNo("9633999536");
        customerActiveSender.setStatusId("1")

        PaymentEntity paymentEntityLoad = new PaymentEntity();
        paymentEntityLoad.setBankAccountId(3L);
        paymentEntityLoad.setCardId(9L);
        paymentEntityLoad.setCountryCode("NO");
        paymentEntityLoad.setCreatedDt(new Date());
        paymentEntityLoad.setIban("86669");
        paymentEntityLoad.setPaymentStatus(101);
        paymentEntityLoad.setPaymentType("P2P");
        paymentEntityLoad.setReceiverId(3L);
        paymentEntityLoad.setSenderId(4L);
        paymentEntityLoad.setSwift("SWIFT");
        paymentEntityLoad.setTransactionAmount(BigDecimal.TEN);
        paymentEntityLoad.setTransactionId(321659L);
        paymentEntityLoad.setTransactionText("Hai");
        paymentEntityLoad.setTransactionType(1);
        paymentEntityLoad.setUpdatedDt(new SimpleDateFormat("dd/MM/yyyy").parse("17/01/2018"));

        TransactionsUtil util = new TransactionsUtil()

        when:
        String name = util.populateReceiverName(customerActiveSender, paymentEntityLoad)

        then:
        name.equals("Benny Kuriakose")
    }

    def "Test Success Scenario for populateReceiverName2 method"(){

        char accountStatus = 'y'
        PaymentView customerActiveSender = new PaymentView();
        customerActiveSender.setAccountId(2L);
        customerActiveSender.setAccountNo("85693241");
        customerActiveSender.setBalanceAmount(BigDecimal.TEN);
        customerActiveSender.setCardNo("7894563333");
        customerActiveSender.setCountryCd("No");
        customerActiveSender.setAccountStatus(accountStatus);
        customerActiveSender.setCustomerId(4L);
        customerActiveSender.setFirstName("Benny");
        customerActiveSender.setLastName("Kuriakose");
        customerActiveSender.setMobileNo("9633999536");
        customerActiveSender.setStatusId("1")

        PaymentEntity paymentEntityLoad = new PaymentEntity();
        paymentEntityLoad.setBankAccountId(3L);
        paymentEntityLoad.setCardId(9L);
        paymentEntityLoad.setCountryCode("NO");
        paymentEntityLoad.setCreatedDt(new Date());
        paymentEntityLoad.setIban("86669");
        paymentEntityLoad.setPaymentStatus(101);
        paymentEntityLoad.setPaymentType("P2P");
        paymentEntityLoad.setReceiverId(3L);
        paymentEntityLoad.setSenderId(4L);
        paymentEntityLoad.setSwift("SWIFT");
        paymentEntityLoad.setTransactionAmount(BigDecimal.TEN);
        paymentEntityLoad.setTransactionId(321659L);
        paymentEntityLoad.setTransactionText("Hai");
        paymentEntityLoad.setTransactionType(1);
        paymentEntityLoad.setUpdatedDt(new SimpleDateFormat("dd/MM/yyyy").parse("17/01/2018"));

        PaymentViewRepo paymentViewRepo = Mock(PaymentViewRepo.class)
        paymentViewRepo.findReceiverByCustomerId(_) >> Optional.ofNullable(customerActiveSender)

        TransactionsUtil util = new TransactionsUtil()
        util.paymentViewRepo = paymentViewRepo

        when:
        String name = util.populateReceiverName(customerActiveSender, paymentEntityLoad)

        then:
        name.equals("Benny Kuriakose")
    }
}
