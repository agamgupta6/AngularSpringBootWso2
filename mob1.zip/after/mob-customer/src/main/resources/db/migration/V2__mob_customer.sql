INSERT INTO cust.tb_customer(
	customer_id, birth_dt, email_id_tx, first_nm, photo_url_tx, last_nm, mobile_no, ssn_no, status_id, touchid_enabled, country_cd)
	VALUES ('9999',null,'mobdevkochi@gmail.com','Initial Credit From MOB',null,' ',null,null,1,null,'NO');