ALTER TABLE cust.tb_customer ADD COLUMN device_id character varying(255);
