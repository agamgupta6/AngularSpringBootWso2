set client_encoding to 'UTF8';

DROP SCHEMA IF EXISTS cust CASCADE;

CREATE SCHEMA cust
    AUTHORIZATION ${db.objects.owner};
-- Table: cust.tb_customer

-- DROP TABLE cust.tb_customer;

CREATE SEQUENCE cust.tb_customer_customer_id_seq
    INCREMENT 1
    START ${db.customer.sequence.start}
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE cust.tb_customer_customer_id_seq
    OWNER TO ${db.objects.owner};


CREATE TABLE cust.tb_customer
(
    customer_id numeric(12,0) NOT NULL DEFAULT nextval('cust.tb_customer_customer_id_seq'::regclass),
    birth_dt character varying(255) COLLATE pg_catalog."default",
    email_id_tx character varying(255) COLLATE pg_catalog."default",
    first_nm character varying(255) COLLATE pg_catalog."default",
    photo_url_tx character varying(255) COLLATE pg_catalog."default",
    last_nm character varying(255) COLLATE pg_catalog."default",
    mobile_no character varying(255) COLLATE pg_catalog."default",
    ssn_no character varying(255) COLLATE pg_catalog."default",
    status_id integer,
    touchid_enabled character varying(255) COLLATE pg_catalog."default",
    COUNTRY_CD character varying(5) COLLATE pg_catalog."default",
    CONSTRAINT tb_customer_pkey PRIMARY KEY (customer_id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE cust.tb_customer
    OWNER to ${db.objects.owner};


--sample entry in customer table
INSERT INTO cust.tb_customer(
  birth_dt, email_id_tx, first_nm, photo_url_tx, last_nm, mobile_no, ssn_no, status_id, touchid_enabled, country_cd)
  VALUES ('25-03-1993','benny.kuriakose@tcs.com','Benny','image uri','Kuriakose','9400956457','44424544544556374412',3,'true','IN');
	
-- Table: cust.customer_auth

-- DROP TABLE cust.customer_auth;

CREATE TABLE cust.TB_customer_auth
(
    customer_id bigint NOT NULL,
    auth_token character varying(255) COLLATE pg_catalog."default",
    login_failed_ct bigint,
    pin character varying(255) COLLATE pg_catalog."default"
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE cust.TB_customer_auth
    OWNER to ${db.objects.owner};

	-- Table: cust.customer_details

-- DROP TABLE cust.customer_details;

CREATE SEQUENCE cust.customer_details_customer_detail_id_seq
    INCREMENT 1
    START ${db.customer.details.sequence.start}
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE cust.customer_details_customer_detail_id_seq
    OWNER TO ${db.objects.owner};

CREATE TABLE cust.TB_customer_details
(
    customer_detail_id numeric(12,0) NOT NULL DEFAULT nextval('cust.customer_details_customer_detail_id_seq'::regclass),
    customer_id numeric(12,0),
    is_norwegianspassport boolean,
    is_norwegiansrs character varying(255) COLLATE pg_catalog."default",
    passport_image_uri character varying(255) COLLATE pg_catalog."default",
    passport_number character varying(255) COLLATE pg_catalog."default",
    passport_validfrom timestamp without time zone,
    passport_validto timestamp without time zone,
    personal_number character varying(255) COLLATE pg_catalog."default",
    rp_number character varying(255) COLLATE pg_catalog."default",
    rs_image_uri character varying(255) COLLATE pg_catalog."default",
    rs_validfrom timestamp without time zone,
    rs_validto timestamp without time zone,
    CONSTRAINT customer_details_pkey PRIMARY KEY (customer_detail_id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE cust.TB_customer_details
    OWNER to ${db.objects.owner};
	
-- dialing code table create script    
CREATE TABLE CUST.TB_DIALING_CODE
(
	COUNTRY_NM            VARCHAR(255),
	DIAL_IN_CD            VARCHAR(10),
	COUNTRY_CD            VARCHAR(15) ,
	CURRENCY              VARCHAR(10)
);

-- insert script
-- dialing code table insert script
insert into cust.tb_dialing_code (country_nm, country_cd, currency, dial_in_cd) 
values ('India', 'IN', 'INR', '+91');
insert into cust.tb_dialing_code (country_nm, country_cd, currency, dial_in_cd) 
values ('Norway', 'NO', 'NOK', '+47');
insert into cust.tb_dialing_code (country_nm, country_cd, currency, dial_in_cd) 
select * from  json_populate_recordset(null::cust.tb_dialing_code, 
('[
  {
  "country_nm":"Afghanistan",
  "country_cd":"AF",
  "currency":"AFN",
  "dial_in_cd":"+93"
  },
  {
  "country_nm":"Aland Islands",
  "country_cd":"AX",
  "currency":"EUR",
  "dial_in_cd":"+358"
  },
  {
  "country_nm":"Albania",
  "country_cd":"AL",
  "currency":"ALL",
  "dial_in_cd":"+355"
  },
  {
  "country_nm":"Algeria",
  "country_cd":"DZ",
  "currency":"DZD",
  "dial_in_cd":"+213"
  },
  {
  "country_nm":"American Samoa",
  "country_cd":"AS",
  "currency":"USD",
  "dial_in_cd":"+1684"
  },
  {
  "country_nm":"Andorra",
  "country_cd":"AD",
  "currency":"EUR",
  "dial_in_cd":"+376"
  },
  {
  "country_nm":"Angola",
  "country_cd":"AO",
  "currency":"AOA",
  "dial_in_cd":"+244"
  },
  {
  "country_nm":"Anguilla",
  "country_cd":"AI",
  "currency":"XCD",
  "dial_in_cd":"+1264"
  },
  {
  "country_nm":"Antarctica",
  "country_cd":"AQ",
  "currency":"XCD",
  "dial_in_cd":"+672"
  },
  {
  "country_nm":"Antigua and Barbuda",
  "country_cd":"AG",
  "currency":"XCD",
  "dial_in_cd":"+1268"
  },
  {
  "country_nm":"Argentina",
  "country_cd":"AR",
  "currency":"ARS",
  "dial_in_cd":"+54"
  },
  {
  "country_nm":"Armenia",
  "country_cd":"AM",
  "currency":"AMD",
  "dial_in_cd":"+374"
  },
  {
  "country_nm":"Aruba",
  "country_cd":"AW",
  "currency":"AWG",
  "dial_in_cd":"+297"
  },
  {
  "country_nm":"Australia",
  "country_cd":"AU",
  "currency":"AUD",
  "dial_in_cd":"+61"
  },
  {
  "country_nm":"Austria",
  "country_cd":"AT",
  "currency":"EUR",
  "dial_in_cd":"+43"
  },
  {
  "country_nm":"Azerbaijan",
  "country_cd":"AZ",
  "currency":"AZN",
  "dial_in_cd":"+994"
  },
  {
  "country_nm":"Bahamas",
  "country_cd":"BS",
  "currency":"BSD",
  "dial_in_cd":"+1242"
  },
  {
  "country_nm":"Bahrain",
  "country_cd":"BH",
  "currency":"BHD",
  "dial_in_cd":"+973"
  },
  {
  "country_nm":"Bangladesh",
  "country_cd":"BD",
  "currency":"BDT",
  "dial_in_cd":"+880"
  },
  {
  "country_nm":"Barbados",
  "country_cd":"BB",
  "currency":"BBD",
  "dial_in_cd":"+1246"
  },
  {
  "country_nm":"Belarus",
  "country_cd":"BY",
  "currency":"BYR",
  "dial_in_cd":"+375"
  },
  {
  "country_nm":"Belgium",
  "country_cd":"BE",
  "currency":"EUR",
  "dial_in_cd":"+32"
  },
  {
  "country_nm":"Belize",
  "country_cd":"BZ",
  "currency":"BZD",
  "dial_in_cd":"+501"
  },
  {
  "country_nm":"Benin",
  "country_cd":"BJ",
  "currency":"XOF",
  "dial_in_cd":"+229"
  },
  {
  "country_nm":"Bermuda",
  "country_cd":"BM",
  "currency":"BMD",
  "dial_in_cd":"+1441"
  },
  {
  "country_nm":"Bhutan",
  "country_cd":"BT",
  "currency":"BTN",
  "dial_in_cd":"+975"
  },
  {
  "country_nm":"Bolivia, Plurinational State of bolivia",
  "country_cd":"BO",
  "currency":"BOB",
  "dial_in_cd":"+591"
  },
  {
  "country_nm":"Bosnia and Herzegovina",
  "country_cd":"BA",
  "currency":"BAM",
  "dial_in_cd":"+387"
  },
  {
  "country_nm":"Botswana",
  "country_cd":"BW",
  "currency":"BWP",
  "dial_in_cd":"+267"
  },
  {
  "country_nm":"Bouvet Island",
  "country_cd":"BV",
  "currency":"NOK",
  "dial_in_cd":"+47"
  },
  {
  "country_nm":"Brazil",
  "country_cd":"BR",
  "currency":"BRL",
  "dial_in_cd":"+55"
  },
  {
  "country_nm":"British Indian Ocean Territory",
  "country_cd":"IO",
  "currency":"USD",
  "dial_in_cd":"+246"
  },
  {
  "country_nm":"Brunei Darussalam",
  "country_cd":"BN",
  "currency":"BND",
  "dial_in_cd":"+673"
  },
  {
  "country_nm":"Bulgaria",
  "country_cd":"BG",
  "currency":"BGN",
  "dial_in_cd":"+359"
  },
  {
  "country_nm":"Burkina Faso",
  "country_cd":"BF",
  "currency":"XOF",
  "dial_in_cd":"+226"
  },
  {
  "country_nm":"Burundi",
  "country_cd":"BI",
  "currency":"BIF",
  "dial_in_cd":"+257"
  },
  {
  "country_nm":"Cambodia",
  "country_cd":"KH",
  "currency":"KHR",
  "dial_in_cd":"+855"
  },
  {
  "country_nm":"Cameroon",
  "country_cd":"CM",
  "currency":"XAF",
  "dial_in_cd":"+237"
  },
  {
  "country_nm":"Canada",
  "country_cd":"CA",
  "currency":"CAD",
  "dial_in_cd":"+1"
  },
  {
  "country_nm":"Cape Verde",
  "country_cd":"CV",
  "currency":"CVE",
  "dial_in_cd":"+238"
  },
  {
  "country_nm":"Cayman Islands",
  "country_cd":"KY",
  "currency":"KYD",
  "dial_in_cd":"+ 345"
  },
  {
  "country_nm":"Central African Republic",
  "country_cd":"CF",
  "currency":"XAF",
  "dial_in_cd":"+236"
  },
  {
  "country_nm":"Chad",
  "country_cd":"TD",
  "currency":"XAF",
  "dial_in_cd":"+235"
  },
  {
  "country_nm":"Chile",
  "country_cd":"CL",
  "currency":"CLP",
  "dial_in_cd":"+56"
  },
  {
  "country_nm":"China",
  "country_cd":"CN",
  "currency":"CNY",
  "dial_in_cd":"+86"
  },
  {
  "country_nm":"Christmas Island",
  "country_cd":"CX",
  "currency":"AUD",
  "dial_in_cd":"+61"
  },
  {
  "country_nm":"Cocos (Keeling) Islands",
  "country_cd":"CC",
  "currency":"AUD",
  "dial_in_cd":"+61"
  },
  {
  "country_nm":"Colombia",
  "country_cd":"CO",
  "currency":"COP",
  "dial_in_cd":"+57"
  },
  {
  "country_nm":"Comoros",
  "country_cd":"KM",
  "currency":"KMF",
  "dial_in_cd":"+269"
  },
  {
  "country_nm":"Congo",
  "country_cd":"CG",
  "currency":"XAF",
  "dial_in_cd":"+242"
  },
  {
  "country_nm":"Congo, The Democratic Republic of the Congo",
  "country_cd":"CD",
  "currency":"CDF",
  "dial_in_cd":"+243"
  },
  {
  "country_nm":"Cook Islands",
  "country_cd":"CK",
  "currency":"NZD",
  "dial_in_cd":"+682"
  },
  {
  "country_nm":"Costa Rica",
  "country_cd":"CR",
  "currency":"CRC",
  "dial_in_cd":"+506"
  },
  {
  "country_nm":"Cote d''Ivoire",
  "country_cd":"CI",
  "currency":"XOF",
  "dial_in_cd":"+225"
  },
  {
  "country_nm":"Croatia",
  "country_cd":"HR",
  "currency":"HRK",
  "dial_in_cd":"+385"
  },
  {
  "country_nm":"Cuba",
  "country_cd":"CU",
  "currency":"CUP",
  "dial_in_cd":"+53"
  },
  {
  "country_nm":"Cyprus",
  "country_cd":"CY",
  "currency":"EUR",
  "dial_in_cd":"+357"
  },
  {
  "country_nm":"Czech Republic",
  "country_cd":"CZ",
  "currency":"CZK",
  "dial_in_cd":"+420"
  },
  {
  "country_nm":"Denmark",
  "country_cd":"DK",
  "currency":"DKK",
  "dial_in_cd":"+45"
  },
  {
  "country_nm":"Djibouti",
  "country_cd":"DJ",
  "currency":"DJF",
  "dial_in_cd":"+253"
  },
  {
  "country_nm":"Dominica",
  "country_cd":"DM",
  "currency":"XCD",
  "dial_in_cd":"+1767"
  },
  {
  "country_nm":"Dominican Republic",
  "country_cd":"DO",
  "currency":"DOP",
  "dial_in_cd":"+1849"
  },
  {
  "country_nm":"Ecuador",
  "country_cd":"EC",
  "currency":"USD",
  "dial_in_cd":"+593"
  },
  {
  "country_nm":"Egypt",
  "country_cd":"EG",
  "currency":"EGP",
  "dial_in_cd":"+20"
  },
  {
  "country_nm":"El Salvador",
  "country_cd":"SV",
  "currency":"USD",
  "dial_in_cd":"+503"
  },
  {
  "country_nm":"Equatorial Guinea",
  "country_cd":"GQ",
  "currency":"XAF",
  "dial_in_cd":"+240"
  },
  {
  "country_nm":"Eritrea",
  "country_cd":"ER",
  "currency":"ERN",
  "dial_in_cd":"+291"
  },
  {
  "country_nm":"Estonia",
  "country_cd":"EE",
  "currency":"EUR",
  "dial_in_cd":"+372"
  },
  {
  "country_nm":"Ethiopia",
  "country_cd":"ET",
  "currency":"ETB",
  "dial_in_cd":"+251"
  },
  {
  "country_nm":"Falkland Islands (Malvinas)",
  "country_cd":"FK",
  "currency":"FKP",
  "dial_in_cd":"+500"
  },
  {
  "country_nm":"Faroe Islands",
  "country_cd":"FO",
  "currency":"DKK",
  "dial_in_cd":"+298"
  },
  {
  "country_nm":"Fiji",
  "country_cd":"FJ",
  "currency":"FJD",
  "dial_in_cd":"+679"
  },
  {
  "country_nm":"Finland",
  "country_cd":"FI",
  "currency":"EUR",
  "dial_in_cd":"+358"
  },
  {
  "country_nm":"France",
  "country_cd":"FR",
  "currency":"EUR",
  "dial_in_cd":"+33"
  },
  {
  "country_nm":"French Guiana",
  "country_cd":"GF",
  "currency":"EUR",
  "dial_in_cd":"+594"
  },
  {
  "country_nm":"French Polynesia",
  "country_cd":"PF",
  "currency":"XPF",
  "dial_in_cd":"+689"
  },
  {
  "country_nm":"French Southern Territories",
  "country_cd":"TF",
  "currency":"EUR",
  "dial_in_cd":"+262"
  },
  {
  "country_nm":"Gabon",
  "country_cd":"GA",
  "currency":"XAF",
  "dial_in_cd":"+241"
  },
  {
  "country_nm":"Gambia",
  "country_cd":"GM",
  "currency":"GMD",
  "dial_in_cd":"+220"
  },
  {
  "country_nm":"Georgia",
  "country_cd":"GE",
  "currency":"GEL",
  "dial_in_cd":"+995"
  },
  {
  "country_nm":"Germany",
  "country_cd":"DE",
  "currency":"EUR",
  "dial_in_cd":"+49"
  },
  {
  "country_nm":"Ghana",
  "country_cd":"GH",
  "currency":"GHS",
  "dial_in_cd":"+233"
  },
  {
  "country_nm":"Gibraltar",
  "country_cd":"GI",
  "currency":"GIP",
  "dial_in_cd":"+350"
  },
  {
  "country_nm":"Greece",
  "country_cd":"GR",
  "currency":"EUR",
  "dial_in_cd":"+30"
  },
  {
  "country_nm":"Greenland",
  "country_cd":"GL",
  "currency":"DKK",
  "dial_in_cd":"+299"
  },
  {
  "country_nm":"Grenada",
  "country_cd":"GD",
  "currency":"XCD",
  "dial_in_cd":"+1473"
  },
  {
  "country_nm":"Guadeloupe",
  "country_cd":"GP",
  "currency":"EUR",
  "dial_in_cd":"+590"
  },
  {
  "country_nm":"Guam",
  "country_cd":"GU",
  "currency":"USD",
  "dial_in_cd":"+1671"
  },
  {
  "country_nm":"Guatemala",
  "country_cd":"GT",
  "currency":"GTQ",
  "dial_in_cd":"+502"
  },
  {
  "country_nm":"Guernsey",
  "country_cd":"GG",
  "currency":"GBP",
  "dial_in_cd":"+44"
  },
  {
  "country_nm":"Guinea",
  "country_cd":"GN",
  "currency":"GNF",
  "dial_in_cd":"+224"
  },
  {
  "country_nm":"Guinea-Bissau",
  "country_cd":"GW",
  "currency":"XOF",
  "dial_in_cd":"+245"
  },
  {
  "country_nm":"Guyana",
  "country_cd":"GY",
  "currency":"GYD",
  "dial_in_cd":"+592"
  },
  {
  "country_nm":"Haiti",
  "country_cd":"HT",
  "currency":"HTG",
  "dial_in_cd":"+509"
  },
  {
  "country_nm":"Heard Island and Mcdonald Islands",
  "country_cd":"HM",
  "currency":"AUD",
  "dial_in_cd":"+0"
  },
  {
  "country_nm":"Holy See (Vatican City State)",
  "country_cd":"VA",
  "currency":"EUR",
  "dial_in_cd":"+379"
  },
  {
  "country_nm":"Honduras",
  "country_cd":"HN",
  "currency":"HNL",
  "dial_in_cd":"+504"
  },
  {
  "country_nm":"Hong Kong",
  "country_cd":"HK",
  "currency":"HKD",
  "dial_in_cd":"+852"
  },
  {
  "country_nm":"Hungary",
  "country_cd":"HU",
  "currency":"HUF",
  "dial_in_cd":"+36"
  },
  {
  "country_nm":"Iceland",
  "country_cd":"IS",
  "currency":"ISK",
  "dial_in_cd":"+354"
  },
  {
  "country_nm":"India",
  "country_cd":"IN",
  "currency":"INR",
  "dial_in_cd":"+91"
  },
  {
  "country_nm":"Indonesia",
  "country_cd":"ID",
  "currency":"IDR",
  "dial_in_cd":"+62"
  },
  {
  "country_nm":"Iran, Islamic Republic of Persian Gulf",
  "country_cd":"IR",
  "currency":"IRR",
  "dial_in_cd":"+98"
  },
  {
  "country_nm":"Iraq",
  "country_cd":"IQ",
  "currency":"IQD",
  "dial_in_cd":"+964"
  },
  {
  "country_nm":"Ireland",
  "country_cd":"IE",
  "currency":"EUR",
  "dial_in_cd":"+353"
  },
  {
  "country_nm":"Isle of Man",
  "country_cd":"IM",
  "currency":"GBP",
  "dial_in_cd":"+44"
  },
  {
  "country_nm":"Israel",
  "country_cd":"IL",
  "currency":"ILS",
  "dial_in_cd":"+972"
  },
  {
  "country_nm":"Italy",
  "country_cd":"IT",
  "currency":"EUR",
  "dial_in_cd":"+39"
  },
  {
  "country_nm":"Jamaica",
  "country_cd":"JM",
  "currency":"JMD",
  "dial_in_cd":"+1876"
  },
  {
  "country_nm":"Japan",
  "country_cd":"JP",
  "currency":"JPY",
  "dial_in_cd":"+81"
  },
  {
  "country_nm":"Jersey",
  "country_cd":"JE",
  "currency":"GBP",
  "dial_in_cd":"+44"
  },
  {
  "country_nm":"Jordan",
  "country_cd":"JO",
  "currency":"JOD",
  "dial_in_cd":"+962"
  },
  {
  "country_nm":"Kazakhstan",
  "country_cd":"KZ",
  "currency":"KZT",
  "dial_in_cd":"+7"
  },
  {
  "country_nm":"Kenya",
  "country_cd":"KE",
  "currency":"KES",
  "dial_in_cd":"+254"
  },
  {
  "country_nm":"Kiribati",
  "country_cd":"KI",
  "currency":"AUD",
  "dial_in_cd":"+686"
  },
  {
  "country_nm":"Korea, Democratic People''s Republic of Korea",
  "country_cd":"KP",
  "currency":"KPW",
  "dial_in_cd":"+850"
  },
  {
  "country_nm":"Korea, Republic of South Korea",
  "country_cd":"KR",
  "currency":"KRW",
  "dial_in_cd":"+82"
  },
  {
  "country_nm":"Kosovo",
  "country_cd":"XK",
  "currency":"EUR",
  "dial_in_cd":"+383"
  },
  {
  "country_nm":"Kuwait",
  "country_cd":"KW",
  "currency":"KWD",
  "dial_in_cd":"+965"
  },
  {
  "country_nm":"Kyrgyzstan",
  "country_cd":"KG",
  "currency":"KGS",
  "dial_in_cd":"+996"
  },
  {
  "country_nm":"Laos",
  "country_cd":"LA",
  "currency":"LAK",
  "dial_in_cd":"+856"
  },
  {
  "country_nm":"Latvia",
  "country_cd":"LV",
  "currency":"EUR",
  "dial_in_cd":"+371"
  },
  {
  "country_nm":"Lebanon",
  "country_cd":"LB",
  "currency":"LBP",
  "dial_in_cd":"+961"
  },
  {
  "country_nm":"Lesotho",
  "country_cd":"LS",
  "currency":"LSL",
  "dial_in_cd":"+266"
  },
  {
  "country_nm":"Liberia",
  "country_cd":"LR",
  "currency":"LRD",
  "dial_in_cd":"+231"
  },
  {
  "country_nm":"Libyan Arab Jamahiriya",
  "country_cd":"LY",
  "currency":"LYD",
  "dial_in_cd":"+218"
  },
  {
  "country_nm":"Liechtenstein",
  "country_cd":"LI",
  "currency":"CHF",
  "dial_in_cd":"+423"
  },
  {
  "country_nm":"Lithuania",
  "country_cd":"LT",
  "currency":"LTL",
  "dial_in_cd":"+370"
  },
  {
  "country_nm":"Luxembourg",
  "country_cd":"LU",
  "currency":"EUR",
  "dial_in_cd":"+352"
  },
  {
  "country_nm":"Macao",
  "country_cd":"MO",
  "currency":"MOP",
  "dial_in_cd":"+853"
  },
  {
  "country_nm":"Macedonia",
  "country_cd":"MK",
  "currency":"MKD",
  "dial_in_cd":"+389"
  },
  {
  "country_nm":"Madagascar",
  "country_cd":"MG",
  "currency":"MGA",
  "dial_in_cd":"+261"
  },
  {
  "country_nm":"Malawi",
  "country_cd":"MW",
  "currency":"MWK",
  "dial_in_cd":"+265"
  },
  {
  "country_nm":"Malaysia",
  "country_cd":"MY",
  "currency":"MYR",
  "dial_in_cd":"+60"
  },
  {
  "country_nm":"Maldives",
  "country_cd":"MV",
  "currency":"MVR",
  "dial_in_cd":"+960"
  },
  {
  "country_nm":"Mali",
  "country_cd":"ML",
  "currency":"XOF",
  "dial_in_cd":"+223"
  },
  {
  "country_nm":"Malta",
  "country_cd":"MT",
  "currency":"EUR",
  "dial_in_cd":"+356"
  },
  {
  "country_nm":"Marshall Islands",
  "country_cd":"MH",
  "currency":"USD",
  "dial_in_cd":"+692"
  },
  {
  "country_nm":"Martinique",
  "country_cd":"MQ",
  "currency":"EUR",
  "dial_in_cd":"+596"
  },
  {
  "country_nm":"Mauritania",
  "country_cd":"MR",
  "currency":"MRO",
  "dial_in_cd":"+222"
  },
  {
  "country_nm":"Mauritius",
  "country_cd":"MU",
  "currency":"MUR",
  "dial_in_cd":"+230"
  },
  {
  "country_nm":"Mayotte",
  "country_cd":"YT",
  "currency":"EUR",
  "dial_in_cd":"+262"
  },
  {
  "country_nm":"Mexico",
  "country_cd":"MX",
  "currency":"MXN",
  "dial_in_cd":"+52"
  },
  {
  "country_nm":"Micronesia, Federated States of Micronesia",
  "country_cd":"FM",
  "currency":"USD",
  "dial_in_cd":"+691"
  },
  {
  "country_nm":"Moldova",
  "country_cd":"MD",
  "currency":"MDL",
  "dial_in_cd":"+373"
  },
  {
  "country_nm":"Monaco",
  "country_cd":"MC",
  "currency":"EUR",
  "dial_in_cd":"+377"
  },
  {
  "country_nm":"Mongolia",
  "country_cd":"MN",
  "currency":"MNT",
  "dial_in_cd":"+976"
  },
  {
  "country_nm":"Montenegro",
  "country_cd":"ME",
  "currency":"EUR",
  "dial_in_cd":"+382"
  },
  {
  "country_nm":"Montserrat",
  "country_cd":"MS",
  "currency":"XCD",
  "dial_in_cd":"+1664"
  },
  {
  "country_nm":"Morocco",
  "country_cd":"MA",
  "currency":"MAD",
  "dial_in_cd":"+212"
  },
  {
  "country_nm":"Mozambique",
  "country_cd":"MZ",
  "currency":"MZN",
  "dial_in_cd":"+258"
  },
  {
  "country_nm":"Myanmar",
  "country_cd":"MM",
  "currency":"MMK",
  "dial_in_cd":"+95"
  },
  {
  "country_nm":"Namibia",
  "country_cd":"NA",
  "currency":"NAD",
  "dial_in_cd":"+264"
  },
  {
  "country_nm":"Nauru",
  "country_cd":"NR",
  "currency":"AUD",
  "dial_in_cd":"+674"
  },
  {
  "country_nm":"Nepal",
  "country_cd":"NP",
  "currency":"NPR",
  "dial_in_cd":"+977"
  },
  {
  "country_nm":"Netherlands",
  "country_cd":"NL",
  "currency":"EUR",
  "dial_in_cd":"+31"
  },
  {
  "country_nm":"Netherlands Antilles",
  "country_cd":"AN",
  "currency":"ANG",
  "dial_in_cd":"+599"
  },
  {
  "country_nm":"New Caledonia",
  "country_cd":"NC",
  "currency":"XPF",
  "dial_in_cd":"+687"
  },
  {
  "country_nm":"New Zealand",
  "country_cd":"NZ",
  "currency":"NZD",
  "dial_in_cd":"+64"
  },
  {
  "country_nm":"Nicaragua",
  "country_cd":"NI",
  "currency":"NIO",
  "dial_in_cd":"+505"
  },
  {
  "country_nm":"Niger",
  "country_cd":"NE",
  "currency":"XOF",
  "dial_in_cd":"+227"
  },
  {
  "country_nm":"Nigeria",
  "country_cd":"NG",
  "currency":"NGN",
  "dial_in_cd":"+234"
  },
  {
  "country_nm":"Niue",
  "country_cd":"NU",
  "currency":"NZD",
  "dial_in_cd":"+683"
  },
  {
  "country_nm":"Norfolk Island",
  "country_cd":"NF",
  "currency":"AUD",
  "dial_in_cd":"+672"
  },
  {
  "country_nm":"Northern Mariana Islands",
  "country_cd":"MP",
  "currency":"USD",
  "dial_in_cd":"+1670"
  },
  {
  "country_nm":"Norway",
  "country_cd":"NO",
  "currency":"NOK",
  "dial_in_cd":"+47"
  },
  {
  "country_nm":"Oman",
  "country_cd":"OM",
  "currency":"OMR",
  "dial_in_cd":"+968"
  },
  {
  "country_nm":"Pakistan",
  "country_cd":"PK",
  "currency":"PKR",
  "dial_in_cd":"+92"
  },
  {
  "country_nm":"Palau",
  "country_cd":"PW",
  "currency":"USD",
  "dial_in_cd":"+680"
  },
  {
  "country_nm":"Palestinian Territory, Occupied",
  "country_cd":"PS",
  "currency":"ILS",
  "dial_in_cd":"+970"
  },
  {
  "country_nm":"Panama",
  "country_cd":"PA",
  "currency":"PAB",
  "dial_in_cd":"+507"
  },
  {
  "country_nm":"Papua New Guinea",
  "country_cd":"PG",
  "currency":"PGK",
  "dial_in_cd":"+675"
  },
  {
  "country_nm":"Paraguay",
  "country_cd":"PY",
  "currency":"PYG",
  "dial_in_cd":"+595"
  },
  {
  "country_nm":"Peru",
  "country_cd":"PE",
  "currency":"PEN",
  "dial_in_cd":"+51"
  },
  {
  "country_nm":"Philippines",
  "country_cd":"PH",
  "currency":"PHP",
  "dial_in_cd":"+63"
  },
  {
  "country_nm":"Pitcairn",
  "country_cd":"PN",
  "currency":"NZD",
  "dial_in_cd":"+64"
  },
  {
  "country_nm":"Poland",
  "country_cd":"PL",
  "currency":"PLN",
  "dial_in_cd":"+48"
  },
  {
  "country_nm":"Portugal",
  "country_cd":"PT",
  "currency":"EUR",
  "dial_in_cd":"+351"
  },
  {
  "country_nm":"Puerto Rico",
  "country_cd":"PR",
  "currency":"USD",
  "dial_in_cd":"+1939"
  },
  {
  "country_nm":"Qatar",
  "country_cd":"QA",
  "currency":"QAR",
  "dial_in_cd":"+974"
  },
  {
  "country_nm":"Romania",
  "country_cd":"RO",
  "currency":"RON",
  "dial_in_cd":"+40"
  },
  {
  "country_nm":"Russia",
  "country_cd":"RU",
  "currency":"RUB",
  "dial_in_cd":"+7"
  },
  {
  "country_nm":"Rwanda",
  "country_cd":"RW",
  "currency":"RWF",
  "dial_in_cd":"+250"
  },
  {
  "country_nm":"Reunion",
  "country_cd":"RE",
  "currency":"EUR",
  "dial_in_cd":"+262"
  },
  {
  "country_nm":"Saint Barthelemy",
  "country_cd":"BL",
  "currency":"EUR",
  "dial_in_cd":"+590"
  },
  {
  "country_nm":"Saint Helena, Ascension and Tristan Da Cunha",
  "country_cd":"SH",
  "currency":"SHP",
  "dial_in_cd":"+290"
  },
  {
  "country_nm":"Saint Kitts and Nevis",
  "country_cd":"KN",
  "currency":"XCD",
  "dial_in_cd":"+1869"
  },
  {
  "country_nm":"Saint Lucia",
  "country_cd":"LC",
  "currency":"XCD",
  "dial_in_cd":"+1758"
  },
  {
  "country_nm":"Saint Martin",
  "country_cd":"MF",
  "currency":"EUR",
  "dial_in_cd":"+590"
  },
  {
  "country_nm":"Saint Pierre and Miquelon",
  "country_cd":"PM",
  "currency":"EUR",
  "dial_in_cd":"+508"
  },
  {
  "country_nm":"Saint Vincent and the Grenadines",
  "country_cd":"VC",
  "currency":"XCD",
  "dial_in_cd":"+1784"
  },
  {
  "country_nm":"Samoa",
  "country_cd":"WS",
  "currency":"WST",
  "dial_in_cd":"+685"
  },
  {
  "country_nm":"San Marino",
  "country_cd":"SM",
  "currency":"EUR",
  "dial_in_cd":"+378"
  },
  {
  "country_nm":"Sao Tome and Principe",
  "country_cd":"ST",
  "currency":"STD",
  "dial_in_cd":"+239"
  },
  {
  "country_nm":"Saudi Arabia",
  "country_cd":"SA",
  "currency":"SAR",
  "dial_in_cd":"+966"
  },
  {
  "country_nm":"Senegal",
  "country_cd":"SN",
  "currency":"XOF",
  "dial_in_cd":"+221"
  },
  {
  "country_nm":"Serbia",
  "country_cd":"RS",
  "currency":"RSD",
  "dial_in_cd":"+381"
  },
  {
  "country_nm":"Seychelles",
  "country_cd":"SC",
  "currency":"SCR",
  "dial_in_cd":"+248"
  },
  {
  "country_nm":"Sierra Leone",
  "country_cd":"SL",
  "currency":"SLL",
  "dial_in_cd":"+232"
  },
  {
  "country_nm":"Singapore",
  "country_cd":"SG",
  "currency":"SGD",
  "dial_in_cd":"+65"
  },
  {
  "country_nm":"Slovakia",
  "country_cd":"SK",
  "currency":"EUR",
  "dial_in_cd":"+421"
  },
  {
  "country_nm":"Slovenia",
  "country_cd":"SI",
  "currency":"EUR",
  "dial_in_cd":"+386"
  },
  {
  "country_nm":"Solomon Islands",
  "country_cd":"SB",
  "currency":"SBD",
  "dial_in_cd":"+677"
  },
  {
  "country_nm":"Somalia",
  "country_cd":"SO",
  "currency":"SOS",
  "dial_in_cd":"+252"
  },
  {
  "country_nm":"South Africa",
  "country_cd":"ZA",
  "currency":"ZAR",
  "dial_in_cd":"+27"
  },
  {
  "country_nm":"South Sudan",
  "country_cd":"SS",
  "currency":"SSP",
  "dial_in_cd":"+211"
  },
  {
  "country_nm":"South Georgia and the South Sandwich Islands",
  "country_cd":"GS",
  "currency":"GBP",
  "dial_in_cd":"+500"
  },
  {
  "country_nm":"Spain",
  "country_cd":"ES",
  "currency":"EUR",
  "dial_in_cd":"+34"
  },
  {
  "country_nm":"Sri Lanka",
  "country_cd":"LK",
  "currency":"LKR",
  "dial_in_cd":"+94"
  },
  {
  "country_nm":"Sudan",
  "country_cd":"SD",
  "currency":"SDG",
  "dial_in_cd":"+249"
  },
  {
  "country_nm":"Suricountry_nm",
  "country_cd":"SR",
  "currency":"SRD",
  "dial_in_cd":"+597"
  },
  {
  "country_nm":"Svalbard and Jan Mayen",
  "country_cd":"SJ",
  "currency":"NOK",
  "dial_in_cd":"+47"
  },
  {
  "country_nm":"Swaziland",
  "country_cd":"SZ",
  "currency":"SZL",
  "dial_in_cd":"+268"
  },
  {
  "country_nm":"Sweden",
  "country_cd":"SE",
  "currency":"SEK",
  "dial_in_cd":"+46"
  },
  {
  "country_nm":"Switzerland",
  "country_cd":"CH",
  "currency":"CHF",
  "dial_in_cd":"+41"
  },
  {
  "country_nm":"Syrian Arab Republic",
  "country_cd":"SY",
  "currency":"SYP",
  "dial_in_cd":"+963"
  },
  {
  "country_nm":"Taiwan",
  "country_cd":"TW",
  "currency":"TWD",
  "dial_in_cd":"+886"
  },
  {
  "country_nm":"Tajikistan",
  "country_cd":"TJ",
  "currency":"TJS",
  "dial_in_cd":"+992"
  },
  {
  "country_nm":"Tanzania, United Republic of Tanzania",
  "country_cd":"TZ",
  "currency":"TZS",
  "dial_in_cd":"+255"
  },
  {
  "country_nm":"Thailand",
  "country_cd":"TH",
  "currency":"THB",
  "dial_in_cd":"+66"
  },
  {
  "country_nm":"Timor-Leste",
  "country_cd":"TL",
  "currency":"USD",
  "dial_in_cd":"+670"
  },
  {
  "country_nm":"Togo",
  "country_cd":"TG",
  "currency":"XOF",
  "dial_in_cd":"+228"
  },
  {
  "country_nm":"Tokelau",
  "country_cd":"TK",
  "currency":"NZD",
  "dial_in_cd":"+690"
  },
  {
  "country_nm":"Tonga",
  "country_cd":"TO",
  "currency":"TOP",
  "dial_in_cd":"+676"
  },
  {
  "country_nm":"Trinidad and Tobago",
  "country_cd":"TT",
  "currency":"TTD",
  "dial_in_cd":"+1868"
  },
  {
  "country_nm":"Tunisia",
  "country_cd":"TN",
  "currency":"TND",
  "dial_in_cd":"+216"
  },
  {
  "country_nm":"Turkey",
  "country_cd":"TR",
  "currency":"TRY",
  "dial_in_cd":"+90"
  },
  {
  "country_nm":"Turkmenistan",
  "country_cd":"TM",
  "currency":"TMT",
  "dial_in_cd":"+993"
  },
  {
  "country_nm":"Turks and Caicos Islands",
  "country_cd":"TC",
  "currency":"USD",
  "dial_in_cd":"+1649"
  },
  {
  "country_nm":"Tuvalu",
  "country_cd":"TV",
  "currency":"AUD",
  "dial_in_cd":"+688"
  },
  {
  "country_nm":"Uganda",
  "country_cd":"UG",
  "currency":"UGX",
  "dial_in_cd":"+256"
  },
  {
  "country_nm":"Ukraine",
  "country_cd":"UA",
  "currency":"UAH",
  "dial_in_cd":"+380"
  },
  {
  "country_nm":"United Arab Emirates",
  "country_cd":"AE",
  "currency":"AED",
  "dial_in_cd":"+971"
  },
  {
  "country_nm":"United Kingdom",
  "country_cd":"GB",
  "currency":"GBP",
  "dial_in_cd":"+44"
  },
  {
  "country_nm":"United States",
  "country_cd":"US",
  "currency":"USD",
  "dial_in_cd":"+1"
  },
  {
  "country_nm":"Uruguay",
  "country_cd":"UY",
  "currency":"UYU",
  "dial_in_cd":"+598"
  },
  {
  "country_nm":"Uzbekistan",
  "country_cd":"UZ",
  "currency":"UZS",
  "dial_in_cd":"+998"
  },
  {
  "country_nm":"Vanuatu",
  "country_cd":"VU",
  "currency":"VUV",
  "dial_in_cd":"+678"
  },
  {
  "country_nm":"Venezuela, Bolivarian Republic of Venezuela",
  "country_cd":"VE",
  "currency":"VEF",
  "dial_in_cd":"+58"
  },
  {
  "country_nm":"Vietnam",
  "country_cd":"VN",
  "currency":"VND",
  "dial_in_cd":"+84"
  },
  {
  "country_nm":"Virgin Islands, British",
  "country_cd":"VG",
  "currency":"USD",
  "dial_in_cd":"+1284"
  },
  {
  "country_nm":"Virgin Islands, U.S.",
  "country_cd":"VI",
  "currency":"USD",
  "dial_in_cd":"+1340"
  },
  {
  "country_nm":"Wallis and Futuna",
  "country_cd":"WF",
  "currency":"XPF",
  "dial_in_cd":"+681"
  },
  {
  "country_nm":"Yemen",
  "country_cd":"YE",
  "currency":"YER",
  "dial_in_cd":"+967"
  },
  {
  "country_nm":"Zambia",
  "country_cd":"ZM",
  "currency":"ZMK",
  "dial_in_cd":"+260"
  },
  {
  "country_nm":"Zimbabwe",
  "country_cd":"ZW",
  "currency":"ZWL",
  "dial_in_cd":"+263"
  }
 ]'::json)) ;
