package com.no.mob.common;

import java.io.Serializable;




import lombok.Getter;
import lombok.Setter;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;


/**
 * This dto contains the details of an error or exception occurs, the error code
 * and error message is wrapped using this class.
 * 
 * @author AB04529
 *
 */
@Setter
@Getter
public class ErrorDetails implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 6737063923611306600L;

    @JsonInclude
    private String errorCode;

    @JsonIgnore
    private String errorMsgKey;

    @JsonInclude
    private String errorMessage;

    @JsonInclude
    private String errorField;

    @JsonInclude
    private String developerMsg;

    @JsonInclude
    private BaseErrorResult errorResult;

    public ErrorDetails(ErrorCode errorCode) {
        this.errorCode = errorCode.getCode();
        this.errorMsgKey = errorCode.getErrorKey();
    }

    public ErrorDetails(ErrorCode errorCode, BaseErrorResult result) {
        this.errorCode = errorCode.getCode();
        this.errorMsgKey = errorCode.getErrorKey();
        this.errorResult = result;
    }

    public ErrorDetails(ErrorCode errorCode, String developerMsg) {
        this.errorCode = errorCode.getCode();
        this.errorMsgKey = errorCode.getErrorKey();
        this.developerMsg = developerMsg;
    }

    public ErrorDetails(ErrorCode errorCode, String developerMsg, BaseErrorResult result) {
        this.errorCode = errorCode.getCode();
        this.errorMsgKey = errorCode.getErrorKey();
        this.developerMsg = developerMsg;
        this.errorResult = result;
    }

    public ErrorDetails(String errorCode, String errorMessage, String developerMsg) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
        this.developerMsg = developerMsg;
    }

    public ErrorDetails(String errorCode, String errorMessageKey) {
        this.errorCode = errorCode;
        this.errorMsgKey = errorMessageKey;
    }

    public ErrorDetails(String errorCode) {
        this.errorCode = errorCode;
    }

    public ErrorDetails(String errorCode, String errorMessageKey, BaseErrorResult result) {
        this.errorCode = errorCode;
        this.errorMsgKey = errorMessageKey;
        this.errorResult = result;

    }

    public ErrorDetails() {

    }

    public String getErrorCode() {
        return errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public void setErrorField(String errorField) {
        this.errorField = errorField;
    }

    public String getErrorField() {
        return errorField;
    }

    public String getDeveloperMsg() {
        return developerMsg;
    }

    public String getErrorKey() {
        return errorMsgKey;
    }
}
