package com.no.mob.customer.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.no.mob.common.BusinessException;
import com.no.mob.common.ErrorDetails;
import com.no.mob.common.GenericResponse;
import com.no.mob.common.ResponseConverter;
import com.no.mob.customer.api.CustomerApi;
import com.no.mob.customer.dto.CommonSuccessResponseDto;
import com.no.mob.customer.dto.CreateProfileRequestDto;
import com.no.mob.customer.dto.LoginRequestDto;
import com.no.mob.customer.dto.LogoutRequestDto;
import com.no.mob.customer.dto.OtpGenerateRequestDto;
import com.no.mob.customer.dto.OtpGenerateResponseDtoResult;
import com.no.mob.customer.service.CustomerEmailVerificationService;
import com.no.mob.customer.service.CustomerLoginApplicationService;
import com.no.mob.customer.service.CustomerProfileService;
import com.no.mob.customer.service.OtpGenerationService;

import io.swagger.annotations.ApiParam;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2017-12-12T05:11:49.791Z")
@RestController
public class CustomerApiController implements CustomerApi {

	@Autowired
	CustomerProfileService customerProfileService;
	
	@Autowired
	OtpGenerationService otpGenerationService;

	@Autowired
	private CustomerEmailVerificationService customerEmailVerificationService;

	@Autowired
	CustomerLoginApplicationService customerLoginApplicationService;

	private static final Logger logger = LoggerFactory
			.getLogger(CustomerApiController.class);

	public ResponseEntity<GenericResponse> customerCreateProfilePost(
			@ApiParam(value = "customer details", required = true) @Valid @RequestBody CreateProfileRequestDto createProfileRequestDto) {
		
			GenericResponse responce = new GenericResponse();
			responce.setResult(customerProfileService
					.createProfile(createProfileRequestDto));
			return new ResponseEntity<>(responce, HttpStatus.OK);
		
	}

	public ResponseEntity<GenericResponse> customerGenerateOtpPost(
			@ApiParam(value = "OTP Generation", required = true) @Valid @RequestBody OtpGenerateRequestDto otpGenerateRequestDto) {
		// do some magic!
		
			logger.info("Entering customerGenerateOtpPost Method for OTP Generation={}", otpGenerateRequestDto);
	    	OtpGenerateResponseDtoResult otpGenerateResponseDtoResult=otpGenerationService.getOtpGeneration(otpGenerateRequestDto);
	    	otpGenerationService.smsOtpProcess(otpGenerateRequestDto,otpGenerateResponseDtoResult.getOtp());
	        logger.info("OTP Generated for Mobile Number");
	        
	       /* return ResponseConverter.formResponse(otpGenerateResponseDtoResult);
			return new ResponseEntity<OtpGenerateResponseDto>(HttpStatus.OK);*/
	        GenericResponse response=new GenericResponse();
	        response.setResult(otpGenerateResponseDtoResult);
	        return new ResponseEntity<>(response, HttpStatus.OK);
	
	}

	public ResponseEntity<GenericResponse> customerLoginPost(
			@ApiParam(value = "customer credentials", required = true) @Valid @RequestBody LoginRequestDto loginRequestDto) {
		GenericResponse responce = new GenericResponse();
		responce.setResult(customerLoginApplicationService
				.validateCustomerLogin(loginRequestDto));
		return new ResponseEntity<>(responce, HttpStatus.OK);
	}

	public ResponseEntity<CommonSuccessResponseDto> customerLogoutPost(
			@ApiParam(value = "", required = true) @Valid @RequestBody LogoutRequestDto logoutRequestDto) {
		customerProfileService.testAWS();
		return new ResponseEntity<CommonSuccessResponseDto>(HttpStatus.OK);
	}

	public ResponseEntity<CommonSuccessResponseDto> customerValidateEmailKeyTokenPost(
			@ApiParam(value = "Encrypted mobile number", required = true) @PathVariable("key") String key,
			@ApiParam(value = "Hashed email", required = true) @PathVariable("token") String token) {
		logger.info("Encrypted mobile number {} and Hashed email received {} ",
				key, token);
		boolean verificationStatus = customerEmailVerificationService
				.verifyEmail(key, token);
		if (verificationStatus) {
			return new ResponseEntity<CommonSuccessResponseDto>(HttpStatus.OK);
		} else {
			return new ResponseEntity<CommonSuccessResponseDto>(
					HttpStatus.UNAUTHORIZED);
		}

	}
	@ExceptionHandler(BusinessException.class)
	public ResponseEntity<GenericResponse> defaultErrorHandler(BusinessException e) {
		ErrorDetails errorDetails=e.getErrorDetails();
		return new ResponseEntity<>(ResponseConverter.formGenericErrorResponse(errorDetails),(HttpStatus.valueOf(Integer.valueOf(errorDetails.getErrorCode()))));
		
	}

	
}
