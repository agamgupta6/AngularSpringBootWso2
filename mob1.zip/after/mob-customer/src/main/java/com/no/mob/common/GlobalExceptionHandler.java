/**
 * 
 */
package com.no.mob.common;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author AB31666
 *
 */
@ControllerAdvice
@RestController
public class GlobalExceptionHandler {

	public static final String DEFAULT_ERROR_VIEW = "error";

	@ExceptionHandler(BusinessException.class)
	public Object defaultErrorHandler(BusinessException e) {
		return ResponseConverter.formGenericErrorResponse(e.getErrorDetails());
	}

}
