package com.no.mob.common;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
/**
 * This exception is a base class for all types of business validations and
 * other business function failures etc. Specific business exceptions can be created
 * by extending this exception.
 * 
 *
 */
@Getter
@Setter
public class BusinessException extends RuntimeException implements Serializable  {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1944619304085033320L;
	
	private final ErrorDetails errorDetails;

	public BusinessException(String errorCode , String errorMsgKey) {
		super(errorCode);
		errorDetails = new ErrorDetails(errorCode, errorMsgKey);	}

}
