/**
 * 
 */
package com.no.mob.customer.repo;

import org.springframework.data.repository.CrudRepository;

import com.no.mob.customer.entity.CustomerDetailsEntity;

/**
 * @author AB31666
 *
 */
public interface CustomerDetailsRepoService extends CrudRepository<CustomerDetailsEntity, Long> {

}
