/**
 * 
 */
package com.no.mob.customer.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

/**
 * @author AB31666
 *
 */

@Entity
@Table(name = "tb_customer_details")
@Getter
@Builder
@AllArgsConstructor
public class CustomerDetailsEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "CUSTOMER_DETAIL_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long customerdetailId;

	@Column(name = "CUSTOMER_ID")
	@JsonProperty("customerId")
	private Long customerId = null;

	@Column(name = "PERSONAL_NUMBER")
	private String personalNumber = null;

	@Column(name = "PASSPORT_NUMBER")
	private String passportNumber = null;

	@Column(name = "PASSPORT_VALIDFROM")
	private Date passportValidFrom = null;

	@Column(name = "PASSPORT_VALIDTO")
	private Date passportValidto = null;

	@Column(name = "IS_NORWEGIANSPASSPORT")
	private Boolean isItNorwegianPassport = null;

	@Column(name = "RP_NUMBER")
	private String rpNumber = null;

	@Column(name = "RS_VALIDFROM")
	private Date rsValidFrom = null;

	@Column(name = "RS_VALIDTO")
	private Date rsValidto = null;

	@Column(name = "IS_NORWEGIANSRS")
	private String isItNorwegianrs = null;

	@Column(name = "PASSPORT_IMAGE_URI")
	private String passportImage = null;

	@Column(name = "RS_IMAGE_URI")
	private String rsImage = null;

}
