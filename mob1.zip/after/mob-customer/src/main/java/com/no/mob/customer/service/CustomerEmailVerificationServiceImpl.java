package com.no.mob.customer.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.no.mob.common.EncriptUtils;
import com.no.mob.common.CommonUtils;
import com.no.mob.customer.constants.CustomerEnums;
import com.no.mob.customer.entity.CustomerEntity;
import com.no.mob.customer.repo.CustomerRepoService;
/**
 * @author ab04529
 * Email verification service implementation
 */
@Service
public class CustomerEmailVerificationServiceImpl implements CustomerEmailVerificationService {
	
	@Autowired
	private CustomerRepoService customerRepoService;

	private static final Logger logger = LoggerFactory.getLogger(CustomerEmailVerificationService.class);
	
	@Override
	public boolean verifyEmail(String key, String token) {
		// get the decryped phone number form key 
		String mobileNumber = getDecryptedPhoneNumber(key);
		// get hashed email from token
		//get customer entity from phone number
		CustomerEntity customerEntity = getCustomerByPhoneNumber(mobileNumber);
		// Checking email id isvalid
		if(null!= customerEntity && isEmailValid(customerEntity,token)){
			// if valid, update custom status as active
			logger.info("Email id is validated and updating status of customer as active");
			updateCustomerStatus(customerEntity);
			return true;
		} 
		// if it is not valid, it will return false.
		return false;
	}

	private void updateCustomerStatus(CustomerEntity customerEntity) {
		customerEntity.setStatusId(CustomerEnums.ACTIVE.getstatus());
		customerRepoService.save(customerEntity);
	}

	private boolean isEmailValid(CustomerEntity customerEntity, String emailId) {
		logger.info("comparing email id of customer entity ({} ,{})", customerEntity.getEmailId(), emailId);
		return (customerEntity.getEmailId() != null && getHashedEmail(customerEntity.getEmailId()).equals(emailId));
	}

	private CustomerEntity getCustomerByPhoneNumber(String mobileNumber) {

		logger.info("Getting customer entity from mobile number {}",mobileNumber);
		List<CustomerEntity>  customerEntityList = customerRepoService.findByMobileNumber(mobileNumber);
	
		if(!CollectionUtils.isEmpty(customerEntityList)){
			logger.info("Got customer entity from mobile number {}",customerEntityList.get(0));
			return customerEntityList.get(0);
		}
		return null;
	}

	private String getHashedEmail(String token) {
		return CommonUtils.hashEmail(token, "1234");
	}

	private String getDecryptedPhoneNumber(String key) {
		return EncriptUtils.decode(key, "1234");
	}

}
