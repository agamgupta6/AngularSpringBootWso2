package com.no.mob.customer.infrautils;

import java.io.InputStream;

import org.springframework.stereotype.Service;

@Service
public interface AwsS3Service {
	public String uploadFile(InputStream uploadFile, Long contentLength, String fileName,String type);
}
