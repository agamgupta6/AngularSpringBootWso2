package com.no.mob.customer.service;

import com.no.mob.customer.dto.CustomerResponceDto;
import com.no.mob.customer.dto.LoginRequestDto;


public interface CustomerLoginApplicationService{
	
	/**
	 * This method will validate the user login credentials,
	 * against the credentials stored in DB
	 * 
	 * @param loginRequestDto
	 * @return
	 */
	CustomerResponceDto validateCustomerLogin(LoginRequestDto loginRequestDto);
	
}