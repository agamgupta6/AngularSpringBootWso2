package com.no.mob.customer.repo;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.no.mob.customer.entity.CustomerAuthEntity;

@Repository
public interface CustomerLoginRepository extends
		CrudRepository<CustomerAuthEntity, Long> {

	//@Query("select c from CustomerAuthEntity c where c.customer.mobileNumber=?1 ")
	CustomerAuthEntity findByCustomerMobileNumber(String mobileNumber);
	
	//@Query("select count(c) from CustomerAuthEntity c where c.customer.customerId=?1 ")
	int findByCustomerCustomerId(Long customerId);
}
