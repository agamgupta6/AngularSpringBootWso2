package com.no.mob.customer.service;

/**
 * @author ab04529
 * This service class is to verify the email when the profile is created
 */
public interface CustomerEmailVerificationService {

	/**
	 * @param key - encrypted mobileNumber
	 * @param token - hashed email
	 * @return
	 */
	public boolean verifyEmail(String key, String token); 
	
}
