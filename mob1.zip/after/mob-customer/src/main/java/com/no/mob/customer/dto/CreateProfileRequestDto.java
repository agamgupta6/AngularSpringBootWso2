package com.no.mob.customer.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * CreateProfileRequestDto
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2017-12-11T11:11:01.424Z")
public class CreateProfileRequestDto {
	@JsonProperty("first_name")
	private String firstName = null;

	@JsonProperty("last_name")
	private String lastName = null;

	@JsonProperty("ssn")
	private String ssn = null;

	@JsonProperty("mobile_number")
	private String mobileNumber = null;

	@JsonProperty("email_id")
	private String emailId = null;

	@JsonProperty("dob")
	private String dob = null;
	
	@JsonProperty("is_kyc_enabled")
	private boolean isKycEnabled = false;

	@JsonProperty("device_id")
	private String deviceId = null;



	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}


	public boolean getIsKYcEnabled(){
		return isKycEnabled;
	}
	
	public void setIsKycEnabled(boolean isKycEnabled){
		this.isKycEnabled = isKycEnabled;
	}

	/**
	 * @return the mobileCode
	 */
	public String getMobileCode() {
		return mobileCode;
	}

	/**
	 * @param mobileCode
	 *            the mobileCode to set
	 */
	public void setMobileCode(String mobileCode) {
		this.mobileCode = mobileCode;
	}

	/**
	 * @param country_code
	 *            the country_code to set
	 */

	@JsonProperty("mobile_code")
	private String mobileCode = null;

	/**
	 * @return the touchidEnabled
	 */
	public String getTouchidEnabled() {
		return touchidEnabled;
	}

	/**
	 * @param touchidEnabled
	 *            the touchidEnabled to set
	 */
	public void setTouchidEnabled(String touchidEnabled) {
		this.touchidEnabled = touchidEnabled;
	}

	/**
	 * @return the passportImage
	 */
	public String getPassportImage() {
		return passportImage;
	}

	/**
	 * @param passportImage
	 *            the passportImage to set
	 */
	public void setPassportImage(String passportImage) {
		this.passportImage = passportImage;
	}

	/**
	 * @return the rsImage
	 */
	public String getRsImage() {
		return rsImage;
	}

	/**
	 * @param rsImage
	 *            the rsImage to set
	 */
	public void setRsImage(String rsImage) {
		this.rsImage = rsImage;
	}

	@JsonProperty("touchId_enabled")
	private String touchidEnabled = null;

	@JsonProperty("country_code")
	private String countryCode = null;

	@JsonProperty("image")
	private String image = null;

	@JsonProperty("pin")
	private String pin = null;

	/**
	 * @return the personalNumber
	 */
	public String getPersonalNumber() {
		return personalNumber;
	}

	/**
	 * @param personalNumber
	 *            the personalNumber to set
	 */
	public void setPersonalNumber(String personalNumber) {
		this.personalNumber = personalNumber;
	}

	/**
	 * @return the passportNumber
	 */
	public String getPassportNumber() {
		return passportNumber;
	}

	/**
	 * @param passportNumber
	 *            the passportNumber to set
	 */
	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	/**
	 * @return the passportValidFrom
	 */
	public String getPassportValidFrom() {
		return passportValidFrom;
	}

	/**
	 * @param passportValidFrom
	 *            the passportValidFrom to set
	 */
	public void setPassportValidFrom(String passportValidFrom) {
		this.passportValidFrom = passportValidFrom;
	}

	/**
	 * @return the passportValidto
	 */
	public String getPassportValidto() {
		return passportValidto;
	}

	/**
	 * @param passportValidto
	 *            the passportValidto to set
	 */
	public void setPassportValidto(String passportValidto) {
		this.passportValidto = passportValidto;
	}

	/**
	 * @return the isItNorwegianPassport
	 */
	public String getIsItNorwegianPassport() {
		return isItNorwegianPassport;
	}

	/**
	 * @param isItNorwegianPassport
	 *            the isItNorwegianPassport to set
	 */
	public void setIsItNorwegianPassport(String isItNorwegianPassport) {
		this.isItNorwegianPassport = isItNorwegianPassport;
	}

	/**
	 * @return the rpNumber
	 */
	public String getRpNumber() {
		return rpNumber;
	}

	/**
	 * @param rpNumber
	 *            the rpNumber to set
	 */
	public void setRpNumber(String rpNumber) {
		this.rpNumber = rpNumber;
	}

	/**
	 * @return the rsValidFrom
	 */
	public String getRsValidFrom() {
		return rsValidFrom;
	}

	/**
	 * @param rsValidFrom
	 *            the rsValidFrom to set
	 */
	public void setRsValidFrom(String rsValidFrom) {
		this.rsValidFrom = rsValidFrom;
	}

	/**
	 * @return the rsValidto
	 */
	public String getRsValidto() {
		return rsValidto;
	}

	/**
	 * @param rsValidto
	 *            the rsValidto to set
	 */
	public void setRsValidto(String rsValidto) {
		this.rsValidto = rsValidto;
	}

	/**
	 * @return the isItNorwegianrs
	 */
	public String getIsItNorwegianrs() {
		return isItNorwegianrs;
	}

	/**
	 * @param isItNorwegianrs
	 *            the isItNorwegianrs to set
	 */
	public void setIsItNorwegianrs(String isItNorwegianrs) {
		this.isItNorwegianrs = isItNorwegianrs;
	}

	@JsonProperty("personalnumber")
	private String personalNumber = null;

	@JsonProperty("passportnumber")
	private String passportNumber = null;

	@JsonProperty("passportvalidfrom")
	private String passportValidFrom = null;

	@JsonProperty("passportvalidto")
	private String passportValidto = null;

	@JsonProperty("is_it_norwegian_passport")
	private String isItNorwegianPassport = null;

	@JsonProperty("rp_number")
	private String rpNumber = null;

	@JsonProperty("rsvalidfrom")
	private String rsValidFrom = null;

	@JsonProperty("rsvalidto")
	private String rsValidto = null;

	@JsonProperty("is_it_norwegian_rs")
	private String isItNorwegianrs = null;

	@JsonProperty("passsport_image")
	private String passportImage = null;

	@JsonProperty("rs_image")
	private String rsImage = null;

	/**
	 * @return the pin
	 */
	public String getPin() {
		return pin;
	}

	/**
	 * @param pin
	 *            the pin to set
	 */
	public void setPin(String pin) {
		this.pin = pin;
	}

	public CreateProfileRequestDto firstName(String firstName) {
		this.firstName = firstName;
		return this;
	}

	/**
	 * Get firstName
	 * 
	 * @return firstName
	 **/
	@ApiModelProperty(value = "")
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public CreateProfileRequestDto lastName(String lastName) {
		this.lastName = lastName;
		return this;
	}

	/**
	 * Get lastName
	 * 
	 * @return lastName
	 **/
	@ApiModelProperty(value = "")
	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public CreateProfileRequestDto ssn(String ssn) {
		this.ssn = ssn;
		return this;
	}

	/**
	 * Get ssn
	 * 
	 * @return ssn
	 **/
	@ApiModelProperty(value = "")
	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public CreateProfileRequestDto mobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
		return this;
	}

	/**
	 * Get mobileNumber
	 * 
	 * @return mobileNumber
	 **/
	@ApiModelProperty(value = "")
	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public CreateProfileRequestDto emailId(String emailId) {
		this.emailId = emailId;
		return this;
	}

	/**
	 * Get emailId
	 * 
	 * @return emailId
	 **/
	@ApiModelProperty(value = "")
	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public CreateProfileRequestDto dob(String dob) {
		this.dob = dob;
		return this;
	}

	/**
	 * Get dob
	 * 
	 * @return dob
	 **/
	@ApiModelProperty(value = "")
	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public CreateProfileRequestDto countryCode(String countryCode) {
		this.countryCode = countryCode;
		return this;
	}

	/**
	 * Get countryCode
	 * 
	 * @return countryCode
	 **/
	@ApiModelProperty(value = "")
	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public CreateProfileRequestDto image(String image) {
		this.image = image;
		return this;
	}

	/**
	 * Get image
	 * 
	 * @return image
	 **/
	@ApiModelProperty(value = "")
	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

}
