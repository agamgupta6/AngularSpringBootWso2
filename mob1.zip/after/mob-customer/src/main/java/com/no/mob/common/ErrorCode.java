package com.no.mob.common;


public interface ErrorCode {

	
	String getCode();
	
	String getErrorKey();
}
