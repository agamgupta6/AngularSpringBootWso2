/**
 * 
 */
package com.no.mob.customer.infrautils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.no.mob.common.BusinessException;

/**
 * @author AB31666
 *
 */
@Service
public class InfraUtilServiceImpl {

	@Autowired
	AwsS3Service awsS3Service;
	@Value("${create.s3.flag}")
	private boolean s3flag ;

	public String writeToStorage(String content, String folder, String type) {
		byte[] imageByte = Base64.getDecoder().decode(content);
		try (InputStream is = new ByteArrayInputStream(imageByte);) {			
			if(s3flag)
			{
			return awsS3Service.uploadFile(is, Long.valueOf(imageByte.length), folder, type);
			} else {
				return "notsavedinS3-dummypath";
			}
		} catch (IOException e) {
			throw new BusinessException("500", "Exception in Inputstream!");
		}
		
	}
}
