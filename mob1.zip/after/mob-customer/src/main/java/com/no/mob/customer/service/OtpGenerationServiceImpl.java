package com.no.mob.customer.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.model.MessageAttributeValue;
import com.amazonaws.services.sns.model.PublishRequest;
import com.amazonaws.services.sns.model.PublishResult;
import com.no.mob.common.BusinessException;
import com.no.mob.common.PasswordGenerator;
import com.no.mob.customer.dto.OtpGenerateRequestDto;
import com.no.mob.customer.dto.OtpGenerateResponseDtoResult;
import com.no.mob.customer.entity.CustomerEntity;
import com.no.mob.customer.repo.CustomerRepoService;
import com.no.mob.customer.repo.DialingCodeRepoService;

@Service
public class OtpGenerationServiceImpl implements OtpGenerationService {

	@Autowired
	CustomerRepoService customerRepoService;
	
	@Autowired
	DialingCodeRepoService dialingCodeRepoService;

	// Set OTP length
	private static final int OTP_LENGTH = 6;

	private Logger log = LoggerFactory.getLogger(this.getClass());

	@Value("${aws.otp.enabled}")
	private boolean isOtpEnabled;
	
	@Value("${otp.message.body}")
	private String message;
	
	@Value("${otp.message.senderID}")
	private String otpSenderID;
	
	@Autowired
	AmazonSNS snsClient;

	@Override
	public OtpGenerateResponseDtoResult getOtpGeneration(
			OtpGenerateRequestDto otpGenerateRequestDto) {

		log.info("Entering getOtpGeneration Method for OTP Generation={}",
				otpGenerateRequestDto);

		inputValidations(otpGenerateRequestDto);
		Boolean isMobileNumberExist = mobileNumberValidation(otpGenerateRequestDto
				.getMobileNo());
		String otpCode = generateOneTimePassword();

		OtpGenerateResponseDtoResult otpGenerateResponseDtoResult = new OtpGenerateResponseDtoResult();
		otpGenerateResponseDtoResult.setIsAccountExist(isMobileNumberExist);
		otpGenerateResponseDtoResult.setOtp(otpCode);

		log.info("getOtpGeneration Method for OTP Generation Ends");
		return otpGenerateResponseDtoResult;

	}

	private String generateOneTimePassword() {
		log.info("Entering into generateOtp Method for OTP Generation");
		return PasswordGenerator.generateRandomString(OTP_LENGTH, OTP_LENGTH,
				0, 0, OTP_LENGTH, 0);
	}

	private Boolean mobileNumberValidation(String mobileNo) {

		log.info(
				"Entering into mobileNumberValidation Method for OTP Generation={}",
				mobileNo);

		List<CustomerEntity> customer = customerRepoService
				.findByMobileNumber(mobileNo);

		if (!CollectionUtils.isEmpty(customer)) {
			log.info(
					"customer information for corresponding mobile_number = {}, = {} ",
					mobileNo, customer.get(0));
			return true;
		}
		return false;
	}

	private void inputValidations(OtpGenerateRequestDto otpGenerateRequestDto) {
		if (null == otpGenerateRequestDto.getCountryCode()
				|| "" == otpGenerateRequestDto.getCountryCode()
				|| null == otpGenerateRequestDto.getMobileNo()
				|| "" == otpGenerateRequestDto.getMobileNo()) {
			throw new BusinessException("400","country code or Mobile number is having null value");

		}

	}

	@Override
	public void smsOtpProcess(OtpGenerateRequestDto otpGenerateRequestDto,String otp) {
		if (isOtpEnabled) {
			String msg = message;
			msg += otp;
			String phoneNumber = dialingCodeRepoService.findByCountryCode(otpGenerateRequestDto.getCountryCode()).getDialingCd()
					+ otpGenerateRequestDto.getMobileNo();
			Map<String, MessageAttributeValue> smsAttributes = new HashMap<>();
			smsAttributes.put("AWS.SNS.SMS.SMSType",new MessageAttributeValue().withStringValue("Transactional").withDataType("String"));
			smsAttributes.put("AWS.SNS.SMS.SenderID",new MessageAttributeValue().withStringValue(otpSenderID).withDataType("String"));
			sendSMSMessage(msg, phoneNumber, smsAttributes);
		}
	}

	private void sendSMSMessage(String message, String phoneNumber,Map<String, MessageAttributeValue> smsAttributes) {
		log.info("Sending sms to Customer from {}", smsAttributes.get("AWS.SNS.SMS.SenderID"));
		PublishResult result = snsClient.publish((new PublishRequest().withMessage(message)).withPhoneNumber(phoneNumber).withMessageAttributes(smsAttributes));
		log.info("{} sent!", result.getMessageId());
		
	}
}