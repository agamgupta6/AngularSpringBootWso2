/**
 * 
 */
package com.no.mob.customer.constants;

/**
 * @author AB31666
 *
 */
public class CustomerConstants {
	
	private CustomerConstants(){
		// private constructor
	}

	public static final String ERRORCODES="DOBA";
	public static final String PROFILE="Profile";

	public static final String PASSPORT="Passport";

	public static final String RES="Res";


}
