package com.no.mob.customer.repo;

import org.springframework.data.repository.CrudRepository;

import com.no.mob.customer.entity.DialingCode;

public interface DialingCodeRepoService extends CrudRepository<DialingCode, Long> {
	
	DialingCode findByCountryCode(String countryCode);

}
