package com.no.mob.customer.dto;

import java.util.Objects;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * CommonSuccessResponseDto
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2017-12-12T05:11:49.791Z")

public class CommonSuccessResponseDto   {
  @JsonProperty("responseInfo")
  private CommonSuccessResponseDtoResponseInfo responseInfo = null;

  public CommonSuccessResponseDto responseInfo(CommonSuccessResponseDtoResponseInfo responseInfo) {
    this.responseInfo = responseInfo;
    return this;
  }

   /**
   * Get responseInfo
   * @return responseInfo
  **/
  @ApiModelProperty(value = "")

  @Valid

  public CommonSuccessResponseDtoResponseInfo getResponseInfo() {
    return responseInfo;
  }

  public void setResponseInfo(CommonSuccessResponseDtoResponseInfo responseInfo) {
    this.responseInfo = responseInfo;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CommonSuccessResponseDto commonSuccessResponseDto = (CommonSuccessResponseDto) o;
    return Objects.equals(this.responseInfo, commonSuccessResponseDto.responseInfo);
  }

  @Override
  public int hashCode() {
    return Objects.hash(responseInfo);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CommonSuccessResponseDto {\n");
    
    sb.append("    responseInfo: ").append(toIndentedString(responseInfo)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

