/**
 * 
 */
package com.no.mob.customer.converter;

import java.util.function.Function;

import com.no.mob.common.CommonUtils;
import com.no.mob.customer.dto.CreateProfileRequestDto;
import com.no.mob.customer.entity.CustomerDetailsEntity;

/**
 * @author AB31666
 *
 */
public class CustomerConverter {

	private CustomerConverter() {
		// private constructor
	}

	public static final Function<CreateProfileRequestDto, CustomerDetailsEntity> CREATE_CUSTOMER_DETAILS = CustomerConverter::convertCreateCustomerDetails;

	/**
	 * Convert create business person profile to vo.
	 *
	 * @param businessPersonEventDTO
	 *            the business person event DTO
	 * @return the business person profile VO
	 */

	private static CustomerDetailsEntity convertCreateCustomerDetails(CreateProfileRequestDto createProfileRequestDto) {
		return CustomerDetailsEntity.builder().passportImage(createProfileRequestDto.getImage())
				.passportNumber(createProfileRequestDto.getPassportNumber())
				.passportValidFrom(CommonUtils.dateFormater(createProfileRequestDto.getPassportValidFrom()))
				.passportValidto(CommonUtils.dateFormater(createProfileRequestDto.getPassportValidto()))
				.isItNorwegianPassport(Boolean.valueOf(createProfileRequestDto.getIsItNorwegianPassport()))
				.rpNumber(createProfileRequestDto.getRpNumber()).rsImage(createProfileRequestDto.getImage())
				.rsValidFrom(CommonUtils.dateFormater(createProfileRequestDto.getRsValidFrom()))
				.rsValidto(CommonUtils.dateFormater(createProfileRequestDto.getRsValidto())).build();
	}
}
