package com.no.mob.common;

import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import lombok.extern.slf4j.Slf4j;
/**
 * interface used for Generating Random String. To generate OTP of 4 digits
 * PasswordGenerator.GenerateRandomString(4, 4, 0, 0, 4, 0) To generate OTP of 4
 * char PasswordGenerator.GenerateRandomString(4, 4, 4, 0, 0, 0)
 * 
 * @version 1.0
 * @author Shrey Khandelwal
 */
@Slf4j
public final class PasswordGenerator {

	private PasswordGenerator() {
		// private constructor to hide implicit public one
	}

	public static final String LCASE = "lcase";
	public static final String UCASE = "ucase";
	public static final String NUM = "num";
	public static final String SPECIAL = "special";
	public static final int NUMB_FOUR = 4;
	public static final int NUMB_TWENTY_FOUR = 24;
	public static final int NUMB_EIGHT = 8;
	public static final int NUMB_TWO = 2;
	public static final int NUMB_SIXTEEN = 16;
	public static final int NUMB_THREE = 3;

	/**
	 * @param minLength
	 * @param maxLength
	 * @param minLCaseCount
	 * @param minUCaseCount
	 * @param minNumCount
	 * @param minSpecialCount
	 * @return
	 */
	public static String generateRandomString(int minLength, int maxLength, int minLCaseCount, int minUCaseCount,
			int minNumCount, int minSpecialCount) {
		char[] randomString;

		String lCaseChars = "abcdefgijkmnopqrstwxyz";
		String uCaseChars = "ABCDEFGHJKLMNPQRSTWXYZ";
		String numericChars = "23456789";
		String specialChars = "*$-+?_&=!%{}/";

		Map<String, Integer> charGroupsUsed = new HashMap<>();
		charGroupsUsed.put(LCASE, minLCaseCount);
		charGroupsUsed.put(UCASE, minUCaseCount);
		charGroupsUsed.put(NUM, minNumCount);
		charGroupsUsed.put(SPECIAL, minSpecialCount);

		// Because we cannot use the default randomizer, which is based on the
		// current time (it will produce the same "random" number within a
		// second), we will use a random number generator to seed the
		// randomizer.

		// Use a 4-byte array to fill it with random bytes and convert it then
		// to an integer value.
		byte[] randomBytes = new byte[NUMB_FOUR];

		// inorder to use a cryptographically strong random number generator
		// (RNG) like "java.security.SecureRandom" in place of this PRNG

		SecureRandom randomizer = new SecureRandom();
		// Generate 4 random bytes.
		randomizer.nextBytes(randomBytes);

		// Convert 4 bytes into a 32-bit integer value.
		int seed = ((randomBytes[0] & 0x7f) << NUMB_TWENTY_FOUR) | (randomBytes[1] << NUMB_SIXTEEN)
				| (randomBytes[NUMB_TWO] << NUMB_TWENTY_FOUR) | (randomBytes[NUMB_THREE]);

		// Create a randomizer from the seed.
		SecureRandom random = new SecureRandom();
		random.setSeed(seed);

		// Allocate appropriate memory for the password.
		int randomIndex;
		if (minLength < maxLength) {
			randomIndex = random.nextInt((maxLength - minLength) + 1) + minLength;
			randomString = new char[randomIndex];
		} else {
			randomString = new char[minLength];
		}

		int requiredCharactersLeft = minLCaseCount + minUCaseCount + minNumCount + minSpecialCount;

		// Build the password.
		for (int i = 0; i < randomString.length; i++) {
			String selectableChars = "";

			// if we still have plenty of characters left to acheive our minimum
			// requirements.
			if (requiredCharactersLeft < randomString.length - i) {
				// choose from any group at random
				selectableChars = lCaseChars + uCaseChars + numericChars + specialChars;

			} else
			// we are out of wiggle room, choose from a random group that
			// still needs to have a minimum required.
			{
				// choose only from a group that we need to satisfy a minimum
				// for.
				selectableChars = populateSelectableChars(lCaseChars, uCaseChars, numericChars, specialChars,
						charGroupsUsed, selectableChars);
			}

			// Now that the string is built, get the next random character.
			if (selectableChars != null) {
				randomIndex = random.nextInt((selectableChars.length()) - 1);
				char nextChar = selectableChars.charAt(randomIndex);

				// Tac it onto our password.
				randomString[i] = nextChar;

				// Now figure out where it came from, and decrement the
				// appropriate
				// minimum value.
				requiredCharactersLeft = populateReqCharLeft(lCaseChars, uCaseChars, numericChars, specialChars,
						charGroupsUsed, requiredCharactersLeft, nextChar);
			} else {

				log.info("selectableChars is having null value");
				return null;
			}

		}
		return new String(randomString);
	}

	private static String populateSelectableChars(String lCaseChars, String uCaseChars, String numericChars,
			String specialChars, Map<String, Integer> charGroupsUsed, String selectableChars) {
		String modifiedSelectableChars = null;
		for (Map.Entry<String, Integer> charGroup : charGroupsUsed.entrySet()) {
			if ((int) charGroup.getValue() > 0) {
				if (LCASE.equals(charGroup.getKey())) {
					modifiedSelectableChars = selectableChars + lCaseChars;
				} else if (UCASE.equals(charGroup.getKey())) {
					modifiedSelectableChars = selectableChars + uCaseChars;
				} else if (NUM.equals(charGroup.getKey())) {
					modifiedSelectableChars = selectableChars + numericChars;
				} else if (SPECIAL.equals(charGroup.getKey())) {
					modifiedSelectableChars = selectableChars + specialChars;
				}
			}
		}
		return modifiedSelectableChars;
	}

	private static int populateReqCharLeft(String lCaseChars, String uCaseChars, String numericChars,
			String specialChars, Map<String, Integer> charGroupsUsed, int requiredCharactersLeft, char nextChar) {
		int modifiedRequiredCharactersLeft = 0;
		if (lCaseChars.indexOf(nextChar) > -1) {
			charGroupsUsed.put(LCASE, charGroupsUsed.get(LCASE) - 1);
			if (charGroupsUsed.get(LCASE) >= 0) {
				modifiedRequiredCharactersLeft = (requiredCharactersLeft - 1);
			}
		} else if (uCaseChars.indexOf(nextChar) > -1) {
			charGroupsUsed.put(UCASE, charGroupsUsed.get(UCASE) - 1);
			if (charGroupsUsed.get(UCASE) >= 0) {
				modifiedRequiredCharactersLeft = (requiredCharactersLeft - 1);
			}
		} else if (numericChars.indexOf(nextChar) > -1) {
			charGroupsUsed.put(NUM, charGroupsUsed.get(NUM) - 1);
			if (charGroupsUsed.get(NUM) >= 0) {
				modifiedRequiredCharactersLeft = (requiredCharactersLeft - 1);
			}
		} else if (specialChars.indexOf(nextChar) > -1) {
			charGroupsUsed.put(SPECIAL, charGroupsUsed.get(SPECIAL) - 1);
			if (charGroupsUsed.get(SPECIAL) >= 0) {
				modifiedRequiredCharactersLeft = (requiredCharactersLeft - 1);
			}
		}
		return modifiedRequiredCharactersLeft;
	}

	/**
	 * @return randomUUID value
	 */
	public static String generateUniqueKeyUsingUUID() {
		return UUID.randomUUID().toString();
	}

}