package com.no.mob.common;

import java.io.Serializable;

public interface BaseErrorResult extends Serializable {
}
