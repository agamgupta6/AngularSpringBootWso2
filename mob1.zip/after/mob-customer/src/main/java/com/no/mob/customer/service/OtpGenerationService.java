package com.no.mob.customer.service;

import org.springframework.stereotype.Service;

import com.no.mob.customer.dto.OtpGenerateRequestDto;
import com.no.mob.customer.dto.OtpGenerateResponseDtoResult;

@Service
public interface OtpGenerationService {
	
	public OtpGenerateResponseDtoResult getOtpGeneration(OtpGenerateRequestDto otpGenerateRequestDto);
	
	public void smsOtpProcess(OtpGenerateRequestDto otpGenerateRequestDto, String otp);

}
