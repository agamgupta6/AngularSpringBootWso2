package com.no.mob.customer.service;


import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.no.mob.common.BusinessException;
import com.no.mob.common.CommonUtils;
import com.no.mob.customer.dto.CustomerResponceDto;
import com.no.mob.customer.dto.LoginRequestDto;
import com.no.mob.customer.dto.MobAuthTokenGenerator;
import com.no.mob.customer.entity.CustomerAuthEntity;
import com.no.mob.customer.entity.CustomerEntity;
import com.no.mob.customer.repo.CustomerLoginRepository;
import com.no.mob.customer.repo.CustomerRepoService;
import com.no.mob.customer.security.JWTAuthenticationFilter;

@Service
public class CustomerLoginApplicationServiceImpl implements
		CustomerLoginApplicationService {
	@Autowired
	CustomerRepoService customerRepoService;

	@Autowired
	private CustomerLoginRepository customerLoginRepository;
	
	@Autowired
	private JWTAuthenticationFilter jwtAutnetication;
	
	@Value("${mob.create.token.expiry}")
	private int tokenExpiry;

	public CustomerResponceDto validateCustomerLogin(
			LoginRequestDto loginRequestDto) {
		CustomerAuthEntity credentialsDto = customerLoginRepository
				.findByCustomerMobileNumber(loginRequestDto.getMobileNo());
		if(credentialsDto!=null){
		if ((!CommonUtils.hashEmail(loginRequestDto.getPin().toString(),
				loginRequestDto.getMobileNo()).equals(credentialsDto.getPin()))) {
			throw new BusinessException("403", "Invalid Pin");
		}
		}else{
			throw new BusinessException("412", "User does not exist");
		}
		CustomerEntity customerEntity=customerRepoService.findByMobileNumber(loginRequestDto
				.getMobileNo()).get(0);
		customerEntity.setDeviceId(loginRequestDto.getDeviceId());
		CustomerResponceDto customerResponceDto= new CustomerResponceDto();
		BeanUtils.copyProperties(customerEntity, customerResponceDto);
		MobAuthTokenGenerator mobAuthTokenGenerator = new MobAuthTokenGenerator();
		mobAuthTokenGenerator.setMobIdentifier(loginRequestDto.getMobileNo());
		mobAuthTokenGenerator.setExpirationTime(tokenExpiry);
		customerRepoService.save(customerEntity);
		customerResponceDto.setAuthToken(jwtAutnetication.mobAuthenticationTokenGenerator(mobAuthTokenGenerator));
		 return customerResponceDto;
	}



}
