package com.no.mob.customer.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;


@Entity
@Table(name = "TB_DIALING_CODE")
@Getter
@Setter
public class DialingCode implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name="COUNTRY_CD")
	private String countryCode;
	@Column(name="COUNTRY_NM")
	private String countryName;
	@Column(name="DIAL_IN_CD")	
	private String dialingCd;

}
