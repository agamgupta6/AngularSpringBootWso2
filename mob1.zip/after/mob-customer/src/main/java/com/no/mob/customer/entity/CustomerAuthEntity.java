/**
 * 
 */
package com.no.mob.customer.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

/**
 * @author AB31666
 *
 */

@Entity
@Table(name = "tb_customer_auth")
@Getter
@Setter
public class CustomerAuthEntity implements Serializable {
	/**
	* 
	*/
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "CUSTOMER_ID")
	@JsonProperty("customerId")
	private Long customerId = null;
	@Column(name = "PIN")
	@JsonProperty("pin")
	private String pin = null;
	@Column(name = "LOGIN_FAILED_CT")
	@JsonProperty("loginFailedCount")
	private Long loginFailedCount = null;
	@Column(name = "AUTH_TOKEN")
	@JsonProperty("authToken")
	private String authToken = null;
	@OneToOne
	@PrimaryKeyJoinColumn
	private CustomerEntity customer;
}
