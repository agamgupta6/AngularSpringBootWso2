/**
 * 
 */
package com.no.mob.customer.dto;

import java.io.Serializable;

import javax.persistence.Column;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author AB31666
 *
 */


@Getter
@Setter
@NoArgsConstructor
public class CustomerResponceDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("mobile_number")
	private String mobileNumber = null;

	@JsonProperty("last_name")
	private String lastName = null;
	
	@JsonProperty("ssn")
	private String ssn = null;
	
	@JsonProperty("first_name")
	private String firstName = null;
	
	@JsonProperty("image")
	private String image = null;
	
	@Column(name = "TOUCHID_ENABLED")
	@JsonProperty("touchid_Enabled")
	private Boolean touchidEnabled = null;
	
	
	@JsonProperty("dob")
	private String dob = null;
	
	@JsonProperty("auth_token")
	private String authToken;
	

	@JsonProperty("email_id")
	private String emailId = null;
	

	@JsonProperty("statusId")
	private int statusId = 0;
	
	
	
}
