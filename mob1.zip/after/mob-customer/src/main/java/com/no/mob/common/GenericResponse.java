/**
 * 
 */
package com.no.mob.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

/**
 * Generic response structure
 *
 */
@Getter
@Setter
@JsonInclude(value=Include.NON_NULL)
public class GenericResponse
{
    
    public GenericResponse() {
        this.responseInfo = new ResponseInfo();
    }
    private ResponseInfo responseInfo;
    
    private Object result;
    
}
