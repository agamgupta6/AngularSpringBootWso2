/**
 * 
 */
package com.no.mob.customer.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author AB31666
 *
 */

@Entity
@Table(name = "tb_customer")
@Getter
@Setter
public class CustomerEntity implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Column(name = "FIRST_NM")
	@JsonProperty("first_name")
	private String firstName = null;
	@Column(name = "LAST_NM")
	@JsonProperty("last_name")
	private String lastName = null;
	@Column(name = "SSN_NO")
	@JsonProperty("ssn")
	private String ssn = null;
	@Column(name = "MOBILE_NO")
	@JsonProperty("mobile_number")
	private String mobileNumber = null;
	@Column(name = "EMAIL_ID_TX")
	@JsonProperty("email_id")
	private String emailId = null;
	@Column(name = "BIRTH_DT")
	@JsonProperty("dob")
	private String dob = null;
	@Column(name = "DEVICE_ID")
	@JsonProperty("device_id")
	private String deviceId = null;
	@Column(name = "PHOTO_URL_TX")
	@JsonProperty("image")
	private String image = null;
	@Column(name = "STATUS_ID")
	@JsonProperty("statusId")
	private int statusId = 0;
	@Column(name = "touchid_enabled")
	@JsonProperty("touchIdEnabled")
	private String touchIdEnabled;
	@Column(name = "COUNTRY_CD")
	@JsonProperty("country_code")
	private String countryCode = null;
	@Id
	@SequenceGenerator(name = "seq", sequenceName = "tb_customer_customer_id_seq")
	@GeneratedValue(generator = "seq", strategy = GenerationType.SEQUENCE)
	@Column(name = "CUSTOMER_ID", columnDefinition = "NUMERIC(12,0)", nullable = false)
	private Long customerId;
	@JsonIgnore
	@OneToOne(mappedBy = "customer", cascade = CascadeType.ALL)
	private CustomerAuthEntity customerAuth;

}
