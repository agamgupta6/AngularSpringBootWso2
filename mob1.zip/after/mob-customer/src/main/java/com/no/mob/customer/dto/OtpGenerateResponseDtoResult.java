package com.no.mob.customer.dto;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * OtpGenerateResponseDtoResult
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2017-12-12T05:11:49.791Z")

public class OtpGenerateResponseDtoResult   {
  @JsonProperty("otp")
  private String otp = null;

  @JsonProperty("isAccountExist")
  private Boolean isAccountExist = null;

  public OtpGenerateResponseDtoResult otp(String otp) {
    this.otp = otp;
    return this;
  }

   /**
   * Get otp
   * @return otp
  **/
  @ApiModelProperty(value = "")


  public String getOtp() {
    return otp;
  }

  public void setOtp(String otp) {
    this.otp = otp;
  }

  public OtpGenerateResponseDtoResult isAccountExist(Boolean isAccountExist) {
    this.isAccountExist = isAccountExist;
    return this;
  }

   /**
   * Get isAccountExist
   * @return isAccountExist
  **/
  @ApiModelProperty(value = "")


  public Boolean getIsAccountExist() {
    return isAccountExist;
  }

  public void setIsAccountExist(Boolean isAccountExist) {
    this.isAccountExist = isAccountExist;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OtpGenerateResponseDtoResult otpGenerateResponseDtoResult = (OtpGenerateResponseDtoResult) o;
    return Objects.equals(this.otp, otpGenerateResponseDtoResult.otp) &&
        Objects.equals(this.isAccountExist, otpGenerateResponseDtoResult.isAccountExist);
  }

  @Override
  public int hashCode() {
    return Objects.hash(otp, isAccountExist);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OtpGenerateResponseDtoResult {\n");
    
    sb.append("    otp: ").append(toIndentedString(otp)).append("\n");
    sb.append("    isAccountExist: ").append(toIndentedString(isAccountExist)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

