package com.no.mob.customer.config;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import io.swagger.annotations.Api;

/**
 * Home redirection to swagger api documentation 
 */
@Controller
@Api(value = "home-controller", hidden = true)
public class HomeController {
    @RequestMapping(value = "/")
    public String index() {
        return "redirect:swagger-ui.html";
    }
}
