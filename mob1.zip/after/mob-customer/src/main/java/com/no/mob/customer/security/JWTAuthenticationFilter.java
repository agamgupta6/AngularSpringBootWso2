package com.no.mob.customer.security;

import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.no.mob.common.CommonUtils;
import com.no.mob.customer.dto.MobAuthTokenGenerator;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
@Component
public class JWTAuthenticationFilter {
	
	@Value("${mob.create.token.code}")
	private String tokenCode;
	
	public String genetareSecret(String key){
		return CommonUtils.hashEmail(key, tokenCode);
	}

	public String mobAuthenticationTokenGenerator(MobAuthTokenGenerator mobAuthTokenGenerator){
		@SuppressWarnings("deprecation")
		String token = Jwts.builder()
                .setSubject(mobAuthTokenGenerator.getMobIdentifier())
                .setExpiration(new Date(System.currentTimeMillis() + mobAuthTokenGenerator.getExpirationTime()))
                .signWith(SignatureAlgorithm.HS512, genetareSecret(mobAuthTokenGenerator.getMobIdentifier()).getBytes())
                .compact();
       return token;
		
	}
	
	public boolean  validateToken(String jwt, String identifier) {
		
		Boolean isValid = false;
		
		Claims claim = Jwts.parser()
				.setSigningKey(genetareSecret(identifier).getBytes())
				.parseClaimsJws(jwt).getBody();
		if((claim.getExpiration().compareTo(new Date(System.currentTimeMillis()))) == 1 &&
				claim.getSubject().equalsIgnoreCase(identifier)) {
				 isValid = true;
		}
		return isValid;
	}
}
