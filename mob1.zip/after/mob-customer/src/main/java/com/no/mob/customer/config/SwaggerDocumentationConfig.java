package com.no.mob.customer.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.AmazonSNSClientBuilder;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

@Configuration
public class SwaggerDocumentationConfig {
	@Value("${aws_access_key_id}")
	private String awsId;

	@Value("${aws_secret_access_key}")
	private String awsKey;

	ApiInfo apiInfo() {
		return new ApiInfoBuilder().title("DNB Mobile Only Banking")
				.description(
						"Mobile only Bank will be an exclusive offering from Banks which will have access only through Mobile App")
				.license("TODO").licenseUrl("http://unlicense.org").termsOfServiceUrl("").version("1.0.0")
				.contact(new Contact("", "", "DNBMobileOnlyBank.Offshore@tcs.com")).build();
	}

	@Bean
	public Docket customImplementation() {
		return new Docket(DocumentationType.SWAGGER_2).select()
				.apis(RequestHandlerSelectors.basePackage("com.no.mob.customer.controller")).build()
				.directModelSubstitute(org.joda.time.LocalDate.class, java.sql.Date.class)
				.directModelSubstitute(org.joda.time.DateTime.class, java.util.Date.class).apiInfo(apiInfo());
	}

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

	@Bean
	public AWSCredentials credential() {
		return new BasicAWSCredentials("AKIAJONLDPIKYFNXC52Q", "N/9Q2VcElhfOgln/jFNCJ3d08I5Ed03cSuqzTvUR");
	}

	@Bean
	public AmazonS3 s3client() {
		return AmazonS3ClientBuilder.standard().withRegion("eu-west-1")
				.withCredentials(new AWSStaticCredentialsProvider(credential()))
				.build();
	}

	@Bean
	public AmazonSNS snsClient() {
		return AmazonSNSClientBuilder.standard().withRegion("eu-west-1")
				.withCredentials(new AWSStaticCredentialsProvider(credential())).build();
	}

}
