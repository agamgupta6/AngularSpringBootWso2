/**
 * 
 */
package com.no.mob.customer.service;

import com.no.mob.customer.dto.CreateProfileRequestDto;
import com.no.mob.customer.dto.CustomerResponceDto;

/**
 * @author AB31666
 *
 */
public interface CustomerProfileService {
	/**
	 * @param createProfileRequestDto
	 */
	public CustomerResponceDto createProfile(CreateProfileRequestDto createProfileRequestDto);
	
	public void testAWS();

}
