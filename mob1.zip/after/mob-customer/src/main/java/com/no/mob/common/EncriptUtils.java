/**
 * 
 */
package com.no.mob.common;

import org.jasypt.util.text.BasicTextEncryptor;

/**
 * @author AB31666
 *
 */
public class EncriptUtils {
	
	private EncriptUtils(){
		// private constructor
	}
	
	    public  static String encode(String text,String password) {
	        try {
			 BasicTextEncryptor textEncryptor = new BasicTextEncryptor();
	        	textEncryptor.setPassword(password);
	            return textEncryptor.encrypt(text);
	        } catch (Exception e) {
	            return null;
	        }
	    }

	    public static  String  decode(String text,String password) {
	        try {
				 BasicTextEncryptor textEncryptor = new BasicTextEncryptor();
	        	textEncryptor.setPassword(password);
	            return textEncryptor.decrypt(text);
	        } catch (Exception e) {
	            return null;
	        }
	    }
}
