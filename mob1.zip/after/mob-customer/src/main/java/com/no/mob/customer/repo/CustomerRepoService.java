/**
 * 
 */
package com.no.mob.customer.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.no.mob.customer.entity.CustomerEntity;

/**
 * @author AB31666
 *
 */
@Repository
public interface CustomerRepoService extends CrudRepository<CustomerEntity, Long>{

	  public  List<CustomerEntity>findBySsn(String ssn);
	  public List<CustomerEntity> findByMobileNumber(String mobileNumber);
}
