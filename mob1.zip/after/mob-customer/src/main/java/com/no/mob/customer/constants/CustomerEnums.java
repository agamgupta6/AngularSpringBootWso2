package com.no.mob.customer.constants;

public enum CustomerEnums {

	ACTIVE(1),INACTIVE(2),PENDINGVERIFICATION(3);
	
	private CustomerEnums(int status) {
		this.status = status;
	}

	private int status;
	
	public int getstatus()
	{
		return status;
	}
}
