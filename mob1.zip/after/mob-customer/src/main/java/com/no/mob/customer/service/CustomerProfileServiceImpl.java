/**
 * 
 */
package com.no.mob.customer.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.Base64;
import java.util.regex.Pattern;

import org.apache.commons.io.IOUtil;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.no.mob.common.BusinessException;
import com.no.mob.common.CommonUtils;
import com.no.mob.common.EncriptUtils;
import com.no.mob.customer.constants.CustomerConstants;
import com.no.mob.customer.constants.CustomerEnums;
import com.no.mob.customer.dto.CreateProfileRequestDto;
import com.no.mob.customer.dto.CustomerResponceDto;
import com.no.mob.customer.dto.MobAuthTokenGenerator;
import com.no.mob.customer.entity.CustomerAuthEntity;
import com.no.mob.customer.entity.CustomerEntity;
import com.no.mob.customer.infrautils.InfraUtilServiceImpl;
import com.no.mob.customer.repo.CustomerAuthRepoService;
import com.no.mob.customer.repo.CustomerDetailsRepoService;
import com.no.mob.customer.repo.CustomerRepoService;
import com.no.mob.customer.security.JWTAuthenticationFilter;

import lombok.extern.slf4j.Slf4j;

/**
 * @author AB31666
 *
 */
@Service
@Slf4j
public class CustomerProfileServiceImpl implements CustomerProfileService {

	private static final String TOKEN = "token";
	private static final Pattern VALID_EMAIL_ADDRESS_REGEX = Pattern
			.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);
	@Value("${emailVerification.link}")
	private String uriLink;
	@Value("${aws_customer_folder}")
	private String customerFolder;
	@Autowired
	CustomerRepoService customerRepoService;

	@Autowired
	CustomerAuthRepoService customerAuthRepoService;

	@Autowired
	CustomerDetailsRepoService customerDetailsRepoService;

	@Autowired
	InfraUtilServiceImpl infraUtil;

	@Autowired
	private JWTAuthenticationFilter jwtAutnetication;

	@Value("${mob.create.token.expiry}")
	private int tokenExpiry;
	@Value("${create.account.uri}")
	private String uricreateALink = null;

	@Autowired
	private RestTemplate restTemplate;

	@Override
	public CustomerResponceDto createProfile(CreateProfileRequestDto createProfileRequestDto) {

		bussinesValidate(createProfileRequestDto);
		verifyMail(createProfileRequestDto.getEmailId(), createProfileRequestDto.getMobileNumber());
		CustomerEntity customerEntity = new CustomerEntity();
		BeanUtils.copyProperties(createProfileRequestDto, customerEntity);

		customerEntity.setStatusId(CustomerEnums.ACTIVE.getstatus());

		customerEntity.setImage(infraUtil.writeToStorage(createProfileRequestDto.getImage(),
				customerFolder + "/" + createProfileRequestDto.getMobileNumber(), CustomerConstants.PROFILE));

		log.info("writing customer details to customer table for mobile number{}"
				+ createProfileRequestDto.getMobileNumber());
		Long custid = customerRepoService.save(customerEntity).getCustomerId();
		CustomerAuthEntity authEntity = new CustomerAuthEntity();
		authEntity.setPin(
				CommonUtils.hashEmail(createProfileRequestDto.getPin(), createProfileRequestDto.getMobileNumber()));
		authEntity.setCustomerId(custid);
		setCustomerAuthDetails(authEntity);
		log.info("writing customer details to customer details table for mobile number{}"
				+ createProfileRequestDto.getMobileNumber());
		CustomerResponceDto customerResponceDto = new CustomerResponceDto();
		BeanUtils.copyProperties(customerEntity, customerResponceDto);
		customerResponceDto.setTouchidEnabled(Boolean.valueOf(customerEntity.getTouchIdEnabled()));
		MobAuthTokenGenerator mobAuthTokenGenerator = new MobAuthTokenGenerator();
		mobAuthTokenGenerator.setMobIdentifier(customerEntity.getMobileNumber());
		mobAuthTokenGenerator.setExpirationTime(tokenExpiry);
		String token = jwtAutnetication.mobAuthenticationTokenGenerator(mobAuthTokenGenerator);
		createAccountNumber(restTemplate, uricreateALink, customerEntity.getMobileNumber(),
				createProfileRequestDto.getCountryCode(), createProfileRequestDto.getIsKYcEnabled(), token);

		customerResponceDto.setAuthToken(token);
		return customerResponceDto;

	}

	private void createAccountNumber(RestTemplate restTemplate, String uricreatevLink, String mobileNumber,
			String countryCode, boolean isKycEnabled, String token) {

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.set("Content-Type", "application/json");
		httpHeaders.set("Authorization", token);
		httpHeaders.set("mobile_number", mobileNumber);

		JSONObject json = new JSONObject();
		try {
			json.put("country_code", countryCode);
			json.put("mobile_number", mobileNumber);
			json.put("is_kyc_enabled", isKycEnabled);
		} catch (JSONException e) {

			log.error(
					"Jsonexception occured at createAccountNumber Service with country code {}, mobileNumber {} , is_kyc_enabled {}",
					countryCode, mobileNumber, isKycEnabled);
		}

		HttpEntity<String> httpEntity = new HttpEntity<>(json.toString(), httpHeaders);
		try {
			restTemplate.postForObject(uricreatevLink, httpEntity, String.class);
		} catch (Exception e) {
			log.error("Exception occured at create account service with exception : {}", e.getMessage());
			throw new BusinessException("412", "Customer Creation failed");
		}

	}

	/**
	 * @param authEntity
	 */
	private void setCustomerAuthDetails(CustomerAuthEntity authEntity) {
		// Saving customer auth details to tb customer auth
		authEntity.setLoginFailedCount(Long.valueOf(0));
		authEntity.setAuthToken(TOKEN);
		log.info("writing customer details to customer auth table for cust id}" + authEntity.getCustomerId());
		customerAuthRepoService.save(authEntity);
	}


	private void verifyMail(String emailId, String mobileNo) {
		String messageText = "Your account has been made, <br /> please verify it by clicking the activation link that has been send to your email";

		String vLink = uriLink + "/" + EncriptUtils.encode(mobileNo, "1234") + "/"
				+ CommonUtils.hashEmail(emailId, "1234");
		log.debug(messageText);
		log.debug(vLink);

	}

	private void bussinesValidate(CreateProfileRequestDto createProfileRequestDto) {

		if (!(VALID_EMAIL_ADDRESS_REGEX.matcher(createProfileRequestDto.getEmailId())).find()) {
			throw new BusinessException("422", "invalid mail Id");
		}

	}

	public void testAWS() {
		try (InputStream is = new ClassPathResource("/images/Penguins.jpg").getInputStream()) {
			byte[] bytes = IOUtil.toByteArray(is);
			String imageStr = Base64.getEncoder().encodeToString(bytes);
			infraUtil.writeToStorage(imageStr, "test-id", "test-type");
		} catch (IOException e) {
			log.error("IOException occured while uploading to S3 with exception {}", e.getMessage());
		}
	}

}
