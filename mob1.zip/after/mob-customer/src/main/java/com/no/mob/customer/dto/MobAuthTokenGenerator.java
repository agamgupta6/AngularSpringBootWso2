package com.no.mob.customer.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class MobAuthTokenGenerator {

	private String mobIdentifier;
	private int expirationTime;
}
