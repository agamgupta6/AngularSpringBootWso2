package com.no.mob.customer.infrautils;

import java.io.InputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;

@Service
public class AwsS3ServiceImpl implements AwsS3Service {

	private static final Logger logger = LoggerFactory.getLogger(AwsS3ServiceImpl.class);

	@Value("${aws_bucket_name}")
	private String bucketName;
	@Value("${aws_image_uri}")
	private String imageUri;
	@Autowired
	private AmazonS3 amazonS3;

	public String uploadFile(InputStream uploadFile, Long contentLength, String folder, String fileName) {

		// Request server-side encryption.
		ObjectMetadata objectMetadata = new ObjectMetadata();
		objectMetadata.setSSEAlgorithm(ObjectMetadata.AES_256_SERVER_SIDE_ENCRYPTION);
		objectMetadata.setContentLength(contentLength);
		logger.info("inside uploadFile");
		PutObjectRequest putRequest = new PutObjectRequest(bucketName, folder + "/" + fileName + ".jpg", uploadFile,
				objectMetadata);
		putRequest.getRequestClientOptions().setReadLimit(10000000);

		amazonS3.putObject(putRequest.withCannedAcl(CannedAccessControlList.PublicRead));

		return imageUri + "/" + bucketName + "/" + folder + "/" + fileName + ".jpg";
	}

}
