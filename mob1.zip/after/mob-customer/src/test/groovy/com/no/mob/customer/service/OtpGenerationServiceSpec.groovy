package com.no.mob.customer.service

import com.amazonaws.services.sns.AmazonSNSClient
import com.amazonaws.services.sns.model.PublishResult
import com.no.mob.common.BusinessException
import com.no.mob.common.CommonUtils
import com.no.mob.customer.dto.OtpGenerateRequestDto
import com.no.mob.customer.dto.OtpGenerateResponseDtoResult
import com.no.mob.customer.entity.CustomerAuthEntity
import com.no.mob.customer.entity.CustomerEntity
import com.no.mob.customer.entity.DialingCode
import com.no.mob.customer.repo.CustomerRepoService
import com.no.mob.customer.repo.DialingCodeRepoService

import spock.lang.Specification

class OtpGenerationServiceSpec extends Specification{

	def "Test Succes scenario for getOtpGeneration method"(){
		given:
		
		def OtpGenerationServiceImpl otpGenerationService = new OtpGenerationServiceImpl();
		
		OtpGenerateRequestDto dto = new OtpGenerateRequestDto();
		dto.setCountryCode("NO")
		dto.setMobileNo("98765432")
		
		OtpGenerateResponseDtoResult otpResult = new OtpGenerateResponseDtoResult();
		otpResult.setOtp("123456");
		otpResult.setIsAccountExist(true)
		
		CustomerAuthEntity customerAuthEntity = new CustomerAuthEntity();
		customerAuthEntity.setPin(CommonUtils.hashEmail("1234","98765432"));
		customerAuthEntity.setCustomerId(12345678);
		customerAuthEntity.setLoginFailedCount(5L)
		customerAuthEntity.setAuthToken("abcd");
		
		CustomerEntity customerEntity = new CustomerEntity();
		customerEntity.setFirstName("Kamal")
		customerEntity.setLastName("Kannan")
		customerEntity.setSsn("12345678901")
		customerEntity.setMobileNumber("98765432")
		customerEntity.setEmailId("kamal.kannan@dnb.no")
		customerEntity.setDob("12122017")
		customerEntity.setImage("abcd")
		customerEntity.setStatusId(1)
		customerEntity.setTouchIdEnabled("Y")
		customerEntity.setCustomerId(12345678)
		customerEntity.setCustomerAuth(customerAuthEntity)
		
		List<CustomerEntity> customerEntityList = new ArrayList()
		customerEntityList.add(customerEntity)
		
		def customerRepoService = Mock(CustomerRepoService.class)
		customerRepoService.findByMobileNumber(_) >> customerEntityList
		otpGenerationService.customerRepoService = customerRepoService
		
		when:
		OtpGenerateResponseDtoResult response = otpGenerationService.getOtpGeneration(dto)
		
		then:
		response.getIsAccountExist() == true
		//response.otp == "123456"
	}
	
	def "Test Failure scenario Incorrect Input for getOtpGeneration method"(){
		given:
		
		def OtpGenerationServiceImpl otpGenerationService = new OtpGenerationServiceImpl();
		
		OtpGenerateRequestDto dto = new OtpGenerateRequestDto();
		dto.setCountryCode("")
		dto.setMobileNo("98765432")
		
		when:
		OtpGenerateResponseDtoResult response = otpGenerationService.getOtpGeneration(dto)
		
		then:
		BusinessException e = thrown()
		e.getErrorDetails().getErrorCode() == "400"
		e.getErrorDetails().getErrorMsgKey() == "country code or Mobile number is having null value"
	}
	
	def "Test Succes scenario for smsOtpProcess method"(){
		given:
		def OtpGenerationServiceImpl otpGenerationService = new OtpGenerationServiceImpl();
		
		otpGenerationService.isOtpEnabled = true
		
		OtpGenerateRequestDto dto = new OtpGenerateRequestDto();
		dto.setCountryCode("NO")
		dto.setMobileNo("98765432")
		
		DialingCode dialingcode =  new DialingCode()
		dialingcode.setCountryCode("91")
		dialingcode.setCountryName("India")
		dialingcode.setDialingCd("91")
		
		def dialingCodeRepoService = Mock(DialingCodeRepoService.class)
		dialingCodeRepoService.findByCountryCode(_) >> dialingcode
		otpGenerationService.dialingCodeRepoService = dialingCodeRepoService
		
		def snsClient = Mock(AmazonSNSClient.class)
		snsClient.publish(_) >> new PublishResult()
		
		otpGenerationService.snsClient = snsClient
		
		when:
		otpGenerationService.smsOtpProcess(dto, "123456")
		then:
		true
	}

	def "Test Failure scenario for smsOtpProcess method"(){
	
	}
}
