package com.no.mob.customer.service

import com.no.mob.common.CommonUtils
import com.no.mob.customer.dto.CustomerResponceDto
import com.no.mob.customer.dto.MobAuthTokenGenerator
import com.no.mob.customer.entity.CustomerAuthEntity
import com.no.mob.customer.entity.CustomerEntity
import com.no.mob.customer.repo.CustomerLoginRepository
import com.no.mob.customer.repo.CustomerRepoService
import com.no.mob.customer.security.JWTAuthenticationFilter

import spock.lang.Specification

class CustomerEmailVerificationServiceSpec extends Specification{
	
	def "Test Success Scenario for verifyEmail method"(){
		given:
		CustomerEmailVerificationServiceImpl emailVerificationService =  new CustomerEmailVerificationServiceImpl()
		
		CustomerAuthEntity customerAuthEntity = new CustomerAuthEntity();
		customerAuthEntity.setPin(CommonUtils.hashEmail("1234","98765432"));
		customerAuthEntity.setCustomerId(12345678);
		customerAuthEntity.setLoginFailedCount(5L)
		customerAuthEntity.setAuthToken("abcd");
		
		CustomerEntity customerEntity = new CustomerEntity();
		customerEntity.setFirstName("Kamal")
		customerEntity.setLastName("Kannan")
		customerEntity.setSsn("12345678901")
		customerEntity.setMobileNumber("98765432")
		customerEntity.setEmailId("kamal.kannan@dnb.no")
		customerEntity.setDob("12122017")
		customerEntity.setImage("abcd")
		customerEntity.setStatusId(1)
		customerEntity.setTouchIdEnabled("Y")
		customerEntity.setCustomerId(12345678)
		customerEntity.setCustomerAuth(customerAuthEntity)
		
		List<CustomerEntity> customerEntityList = new ArrayList()
		customerEntityList.add(customerEntity)
		
		def customerRepoService = Mock(CustomerRepoService.class)
		customerRepoService.findByMobileNumber(_) >> customerEntityList
		//customerRepoService.save() >> "Repo save mocked"
		emailVerificationService.customerRepoService = customerRepoService
		
		when:
		Boolean response = emailVerificationService.verifyEmail("98765432", "D8A2598971D92B9FD8605609E79BEAAFF417CA4A")
		then:
		response == true
	}
	
	def "Test Failure Scenario for verifyEmail method"(){
		given:
		CustomerEmailVerificationServiceImpl emailVerificationService =  new CustomerEmailVerificationServiceImpl()
		
		CustomerAuthEntity customerAuthEntity = new CustomerAuthEntity();
		customerAuthEntity.setPin(CommonUtils.hashEmail("1234","98765432"));
		customerAuthEntity.setCustomerId(12345678);
		customerAuthEntity.setLoginFailedCount(5L)
		customerAuthEntity.setAuthToken("abcd");
		
		CustomerEntity customerEntity = new CustomerEntity();
		customerEntity.setFirstName("Kamal")
		customerEntity.setLastName("Kannan")
		customerEntity.setSsn("12345678901")
		customerEntity.setMobileNumber("98765432")
		customerEntity.setEmailId("kamal.kannan1@dnb.no")
		customerEntity.setDob("12122017")
		customerEntity.setImage("abcd")
		customerEntity.setStatusId(1)
		customerEntity.setTouchIdEnabled("Y")
		customerEntity.setCustomerId(12345678)
		customerEntity.setCustomerAuth(customerAuthEntity)
		
		List<CustomerEntity> customerEntityList = new ArrayList()
		customerEntityList.add(customerEntity)
		
		def customerRepoService = Mock(CustomerRepoService.class)
		customerRepoService.findByMobileNumber(_) >> customerEntityList
		customerRepoService.save() >> "Repo save mocked"
		emailVerificationService.customerRepoService = customerRepoService
		
		when:
		Boolean response = emailVerificationService.verifyEmail("98765432", "D8A2598971D92B9FD8605609E79BEAAFF417CA4A")
		then:
		response == false
	}

}
