package com.no.mob.customer.service

import org.springframework.web.client.RestTemplate

import com.no.mob.common.CommonUtils
import com.no.mob.customer.dto.CreateProfileRequestDto
import com.no.mob.customer.dto.CustomerResponceDto
import com.no.mob.customer.entity.CustomerAuthEntity
import com.no.mob.customer.entity.CustomerEntity
import com.no.mob.customer.infrautils.InfraUtilServiceImpl
import com.no.mob.customer.repo.CustomerAuthRepoService
import com.no.mob.customer.repo.CustomerRepoService
import com.no.mob.customer.security.JWTAuthenticationFilter

import spock.lang.Specification

class CustomerProfileServiceSpec extends Specification{
	
	def "Test Success Scenario for createProfile method"(){
		
		CustomerProfileServiceImpl customerProfileService = new CustomerProfileServiceImpl();
		
		given:
		customerProfileService.customerFolder = "mockFolder"
		customerProfileService.uricreateALink = "http://localhost:8080/mob-rest-service-mock"
		
		CreateProfileRequestDto createProfileRequestDto = new CreateProfileRequestDto();
		createProfileRequestDto.setFirstName("Kamal")
		createProfileRequestDto.setLastName("Kannan")
		createProfileRequestDto.setSsn("12345678901")
		createProfileRequestDto.setEmailId("kamal.kannan@dnb.no")
		createProfileRequestDto.setMobileNumber("98765432")
		createProfileRequestDto.setDob("12121990")
		createProfileRequestDto.setTouchidEnabled("Y")
		createProfileRequestDto.setPassportImage("12345")
		createProfileRequestDto.setRsImage("1234abcd")
		createProfileRequestDto.setPersonalNumber("98765432")
		createProfileRequestDto.setPassportValidFrom("12122017")
		createProfileRequestDto.setPassportValidto("12122018")
		createProfileRequestDto.setIsItNorwegianPassport("Y")
		createProfileRequestDto.setRpNumber("1234")
		createProfileRequestDto.setRsValidFrom("12122017")
		createProfileRequestDto.setRsValidto("12122018")
		createProfileRequestDto.setIsItNorwegianrs("Y")
		createProfileRequestDto.setPin("1234")
		createProfileRequestDto.setCountryCode("47")
		createProfileRequestDto.setImage("abcd")
		
		CustomerAuthEntity customerAuthEntity = new CustomerAuthEntity();
		customerAuthEntity.setPin(CommonUtils.hashEmail(createProfileRequestDto.getPin().toString(),
				createProfileRequestDto.getMobileNumber()));
		customerAuthEntity.setCustomerId(12345678);
		customerAuthEntity.setLoginFailedCount(5L)
		customerAuthEntity.setAuthToken("abcd");
		
		CustomerEntity customerEntity = new CustomerEntity();
		customerEntity.setFirstName("Kamal")
		customerEntity.setLastName("Kannan")
		customerEntity.setSsn("12345678901")
		customerEntity.setMobileNumber("98765432")
		customerEntity.setEmailId("kamal.kannan@dnb.no")
		customerEntity.setDob("12121990")
		customerEntity.setImage("abcd")
		customerEntity.setStatusId(3)
		customerEntity.setTouchIdEnabled("Y")
		customerEntity.setCustomerId(12345678)
		customerEntity.setCustomerAuth(customerAuthEntity)
		
		def customerRepo = Mock(CustomerRepoService.class)
		customerRepo.save(_) >> customerEntity
		customerProfileService.customerRepoService = customerRepo
		
		def CustomerAuthRepoService customerAuthRepo = Mock(CustomerAuthRepoService.class)
		customerAuthRepo.save() >> "CustomerAuthRepoService Mocked"
		customerProfileService.customerAuthRepoService = customerAuthRepo
		
		def jwtAuthenticationFilter = Mock(JWTAuthenticationFilter.class)
		jwtAuthenticationFilter.mobAuthenticationTokenGenerator(_) >> "abcd"
		customerProfileService.jwtAutnetication = jwtAuthenticationFilter
		
		def infraUtil = Mock(InfraUtilServiceImpl.class)
		infraUtil.writeToStorage(_,_,_) >> "abcd"
		customerProfileService.infraUtil = infraUtil
		
		def restTemplate = Mock(RestTemplate.class)
		restTemplate.postForObject(_, _, String.class) >> "{responseInfo:Success}"
		customerProfileService.restTemplate = restTemplate
		
		when:
		CustomerResponceDto response = customerProfileService.createProfile(createProfileRequestDto)
		then:
		response.getFirstName() == "Kamal"
		response.getLastName() == "Kannan"
		response.getSsn() == "12345678901"
		response.getMobileNumber() == "98765432"
		response.getEmailId() == "kamal.kannan@dnb.no"
		response.getDob() == "12121990"
		response.getImage() == "abcd"
		response.getStatusId() == 1
		response.getAuthToken() == "abcd"
	}
}
