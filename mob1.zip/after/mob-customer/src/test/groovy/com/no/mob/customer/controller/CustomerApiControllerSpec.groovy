package com.no.mob.customer.controller

import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity

import spock.lang.Specification

import com.no.mob.customer.api.CustomerApi
import com.no.mob.customer.dto.CommonSuccessResponseDto
import com.no.mob.customer.dto.CreateProfileRequestDto
import com.no.mob.customer.dto.CustomerResponceDto
import com.no.mob.customer.dto.LoginRequestDto
import com.no.mob.customer.dto.LogoutRequestDto
import com.no.mob.customer.dto.OtpGenerateRequestDto
import com.no.mob.customer.dto.OtpGenerateResponseDtoResult
import com.no.mob.common.GenericResponse
import com.no.mob.customer.service.OtpGenerationService
import com.no.mob.customer.service.CustomerProfileService
import com.no.mob.customer.service.CustomerLoginApplicationService
import com.no.mob.customer.service.CustomerEmailVerificationService;



class CustomerApiControllerSpec extends Specification {
	
	def "Test Success Scenario for customerGenerateOtpPost method"() {
		given:
		CustomerApi api = new CustomerApiController();
		OtpGenerateRequestDto dto = new OtpGenerateRequestDto();
		dto.setCountryCode("NO")
		dto.setMobileNo("123456789")
		OtpGenerateResponseDtoResult otpResult = new OtpGenerateResponseDtoResult();
		otpResult.setOtp("123456");
		otpResult.setIsAccountExist(true)
		
		def	otpGenerationService = Mock(OtpGenerationService.class)
		otpGenerationService.getOtpGeneration(_) >> otpResult
		otpGenerationService.smsOtpProcess() >> {println "Executed mocked method"}
		api.otpGenerationService = otpGenerationService
		when:
		ResponseEntity<GenericResponse> response = api.customerGenerateOtpPost(dto)
		then:
		response.status == HttpStatus.OK
		response.body.getResponseInfo().getResponseCode() == "200"
	}
	
	def "Test Success Scenario for customerCreateProfilePost method"() {
		given:
		CustomerApi api = new CustomerApiController();
		
		CreateProfileRequestDto dto = new CreateProfileRequestDto();
		dto.setFirstName("Kmal")
		dto.setLastName("KAnna")
		dto.setSsn("12345678901")
		dto.setEmailId("kamal.kannan@dnb.no")
		dto.setMobileNumber("98765432")
		dto.setDob("12122017")
		dto.setTouchidEnabled("Y")
		dto.setPassportImage("12345")
		dto.setRsImage("1234abcd")
		dto.setPersonalNumber("98456123")
		dto.setPassportValidFrom("12122017")
		dto.setPassportValidto("12122018")
		dto.setIsItNorwegianPassport("Y")
		dto.setRpNumber("1234")
		dto.setRsValidFrom("12122017")
		dto.setRsValidto("12122018")
		dto.setIsItNorwegianrs("Y")
		dto.setPin("1234")
		dto.setCountryCode("47")
		dto.setImage("abcd")
		
		CustomerResponceDto responseDto = new CustomerResponceDto();
		responseDto.setFirstName("Karan")
		responseDto.setLastName("Kajetan")
		responseDto.setSsn("12345678901")
		responseDto.setMobileNumber("923456789")
		responseDto.setEmailId("karan.k@dnb.no")
		responseDto.setDob("12122017")
		responseDto.setImage("abcd")
		responseDto.setStatusId(1)
		responseDto.setAuthToken("abcd")
		responseDto.setTouchidEnabled(true)
		
		def	customerProfileService = Mock(CustomerProfileService.class)
		customerProfileService.createProfile(_) >> responseDto
		api.customerProfileService = customerProfileService
		when:
		ResponseEntity<GenericResponse> response = api.customerCreateProfilePost(dto)
		then:
		response.status == HttpStatus.OK
		response.body.getResponseInfo().getResponseCode() == "200"
	}

	def "Test Success Scenario for customerLoginPost method"() {
		given:
		CustomerApi api = new CustomerApiController();
		
		LoginRequestDto dto = new LoginRequestDto();
		dto.setMobileNo("98563214")
		dto.setPin(1234)
		
		CustomerResponceDto responseDto = new CustomerResponceDto();
		responseDto.setFirstName("Karan")
		responseDto.setLastName("Kajetan")
		responseDto.setSsn("12345678901")
		responseDto.setMobileNumber("923456789")
		responseDto.setEmailId("karan.k@dnb.no")
		responseDto.setDob("12122017")
		responseDto.setImage("abcd")
		responseDto.setStatusId(1)
		responseDto.setAuthToken("abcd")
		responseDto.setTouchidEnabled(true)
		
		def	customerLoginApplicationService = Mock(CustomerLoginApplicationService.class);
		customerLoginApplicationService.validateCustomerLogin(_) >> responseDto
		api.customerLoginApplicationService = customerLoginApplicationService
		when:
		ResponseEntity<GenericResponse> response = api.customerLoginPost(dto)
		then:
		response.status == HttpStatus.OK
		response.body.getResponseInfo().getResponseCode() == "200"
	}
	
	def "Test Success Scenario for customerLogoutPost method"() {
		given:
		CustomerApi api = new CustomerApiController();
		
		LogoutRequestDto dto = new LogoutRequestDto();
		dto.setMobileNumber("923456789")
		dto.setAuthToken("abcd")
		
		def	customerProfileService = Mock(CustomerProfileService.class)
		customerProfileService.testAWS() >> {println "Executed mocked method"}
		api.customerProfileService = customerProfileService
		when:
		ResponseEntity<CommonSuccessResponseDto> response = api.customerLogoutPost(dto)
		then:
		response.status == HttpStatus.OK
	}
	
	def "Test Success Scenario for customerValidateEmailKeyTokenPost method"() {
		given:
		CustomerApi api = new CustomerApiController();
		
		String key = "1234"
		String token = "abcd"
		
		Boolean responseValue = true
		
		def	customerEmailVerificationService = Mock(CustomerEmailVerificationService.class)
		customerEmailVerificationService.verifyEmail() >> responseValue
		api.customerEmailVerificationService = customerEmailVerificationService
		when:
		ResponseEntity<CommonSuccessResponseDto> response = api.customerValidateEmailKeyTokenPost(key, token)
		then:
		response.status == HttpStatus.UNAUTHORIZED
	}
}
