package com.no.mob.customer.service

import org.springframework.http.ResponseEntity
import org.springframework.web.client.RestTemplate

import com.no.mob.common.BusinessException
import com.no.mob.common.CommonUtils
import com.no.mob.customer.dto.CustomerResponceDto
import com.no.mob.customer.dto.LoginRequestDto
import com.no.mob.customer.dto.MobAuthTokenGenerator
import com.no.mob.customer.entity.CustomerAuthEntity
import com.no.mob.customer.entity.CustomerEntity
import com.no.mob.customer.repo.CustomerLoginRepository;
import com.no.mob.customer.repo.CustomerRepoService;
import com.no.mob.customer.security.JWTAuthenticationFilter;

import spock.lang.Specification

class CustomerLoginApplicationServiceSpec extends Specification{
	
	def "Test Success Scenario for validateCustomerLogin method"(){
		given:
		CustomerLoginApplicationServiceImpl loginService =  new CustomerLoginApplicationServiceImpl()
		
		LoginRequestDto loginRequestDto = new LoginRequestDto();
		loginRequestDto.setMobileNo("98765432")
		loginRequestDto.setPin(123456)

				
		CustomerAuthEntity customerAuthEntity = new CustomerAuthEntity();
		customerAuthEntity.setPin(CommonUtils.hashEmail(loginRequestDto.getPin().toString(),
				loginRequestDto.getMobileNo()));
		customerAuthEntity.setCustomerId(12345678);
		customerAuthEntity.setLoginFailedCount(5L)
		customerAuthEntity.setAuthToken("abcd");
		
		CustomerEntity customerEntity = new CustomerEntity();
		customerEntity.setFirstName("Kamal")
		customerEntity.setLastName("Kannan")
		customerEntity.setSsn("12345678901")
		customerEntity.setMobileNumber("98765432")
		customerEntity.setEmailId("kamal.kannan@dnb.no")
		customerEntity.setDob("12122017")
		customerEntity.setImage("abcd")
		customerEntity.setStatusId(1)
		customerEntity.setTouchIdEnabled("Y")
		customerEntity.setCustomerId(12345678)
		customerEntity.setCustomerAuth(customerAuthEntity)
		
		List<CustomerEntity> customerEntityList = new ArrayList()
		customerEntityList.add(customerEntity)
		
		MobAuthTokenGenerator mobAuthTokenGenerator = new MobAuthTokenGenerator();
		mobAuthTokenGenerator.setMobIdentifier(loginRequestDto.getMobileNo());
		mobAuthTokenGenerator.setExpirationTime(10);
		
		def customerLoginRepository = Mock(CustomerLoginRepository.class)
		customerLoginRepository.findByCustomerMobileNumber(_) >> customerAuthEntity
		loginService.customerLoginRepository = customerLoginRepository
		
		def customerRepoService = Mock(CustomerRepoService.class)
		customerRepoService.findByMobileNumber(_) >> customerEntityList
		loginService.customerRepoService = customerRepoService
		
		def jwtAutnetication = Mock(JWTAuthenticationFilter.class)
		jwtAutnetication.mobAuthenticationTokenGenerator(_) >> "abcd"
		loginService.jwtAutnetication = jwtAutnetication
		when:
		CustomerResponceDto response = loginService.validateCustomerLogin(loginRequestDto)
		then:
		response.getFirstName() == "Kamal"
		response.getLastName() == "Kannan"
		response.getSsn() == "12345678901"
		response.getMobileNumber() == "98765432"
		response.getEmailId() == "kamal.kannan@dnb.no"
		response.getDob() == "12122017"
		response.getImage() == "abcd"
		response.getStatusId() == 1
		response.getAuthToken() == "abcd"
	}
	
	def "Test Failure Scenario Invalid Pin for validateCustomerLogin method"(){
		given:
		CustomerLoginApplicationServiceImpl loginService =  new CustomerLoginApplicationServiceImpl()

		LoginRequestDto loginRequestDto = new LoginRequestDto();
		loginRequestDto.setMobileNo("98765432")
		loginRequestDto.setPin(123456)


		CustomerAuthEntity customerAuthEntity = new CustomerAuthEntity();
		customerAuthEntity.setPin("123456");
		customerAuthEntity.setCustomerId(12345678);
		customerAuthEntity.setLoginFailedCount(5L)
		customerAuthEntity.setAuthToken("abcd");

		def customerLoginRepository = Mock(CustomerLoginRepository.class)
		customerLoginRepository.findByCustomerMobileNumber(_) >> customerAuthEntity
		loginService.customerLoginRepository = customerLoginRepository

		when:
		CustomerResponceDto response = loginService.validateCustomerLogin(loginRequestDto)
		then:
		BusinessException e = thrown()
		e.getErrorDetails().getErrorCode() == "403"
		e.getErrorDetails().getErrorMsgKey() == "Invalid Pin"
	}
	
	def "Test Failure Scenario Invalid User for validateCustomerLogin method"(){
		given:
		CustomerLoginApplicationServiceImpl loginService =  new CustomerLoginApplicationServiceImpl()

		LoginRequestDto loginRequestDto = new LoginRequestDto();
		loginRequestDto.setMobileNo("98765432")
		loginRequestDto.setPin(123456)

		def customerLoginRepository = Mock(CustomerLoginRepository.class)
		customerLoginRepository.findByCustomerMobileNumber(_) >> null
		loginService.customerLoginRepository = customerLoginRepository

		when:
		CustomerResponceDto response = loginService.validateCustomerLogin(loginRequestDto)
		then:
		BusinessException e = thrown()
		e.getErrorDetails().getErrorCode() == "412"
		e.getErrorDetails().getErrorMsgKey() == "User does not exist"
	}

}
